import React, { useState, useEffect, useRef } from 'react';
import { useGame } from '../context/GameContext';
import { Link } from 'react-router-dom';
import { TrendingUp, Award, History, ArrowRight, Target, Crown, Clock, CheckCircle2, Zap, Lock, Star, ChevronLeft, ChevronRight, PlayCircle, X, Tv } from 'lucide-react';
import { Mission } from '../types';
import { showRewardedVideo, registerAdEventListener, unregisterAdEventListener, AdEventType, isUnityEnvironment } from '../services/unityBridge';

// Componente AdSense Seguro para React - Atualizado para o bloco mobplay (350x90)
const AdSenseBlock: React.FC = () => {
  useEffect(() => {
    // Pequeno delay para garantir que o modal já renderizou no DOM e tem largura calculada
    const timeout = setTimeout(() => {
        try {
            // @ts-ignore
            if (window.adsbygoogle) {
                // @ts-ignore
                window.adsbygoogle.push({});
                console.log('[AdSenseBlock] ✅ Anúncio carregado');
            }
        } catch (e) {
            console.error("AdSense Trigger Error:", e);
        }
    }, 200);

    return () => clearTimeout(timeout);
  }, []);

  return (
    <div className="w-full bg-gray-50 flex items-center justify-center min-h-[110px] overflow-hidden rounded-lg border border-gray-100 relative">
        <div className="w-full flex justify-center items-center">
            {/* Código do Anúncio fornecido pelo usuário */}
            <ins className="adsbygoogle"
                style={{ display: 'inline-block', width: '350px', height: '90px' }}
                data-ad-client="ca-pub-8733260701845866"
                data-ad-slot="5949469204"></ins>
        </div>
        
        {/* Elemento visual de fundo caso o anúncio demore ou não carregue (ex: localhost) */}
        <div className="absolute inset-0 flex flex-col items-center justify-center -z-10 text-gray-300 pointer-events-none">
            <Tv size={24} className="mb-1 opacity-20" />
            <span className="text-[10px] font-bold uppercase tracking-widest opacity-50">Publicidade</span>
        </div>
    </div>
  );
};

// Componente individual do Card de Missão para gerenciar seu próprio timer
const MissionCard: React.FC<{ mission: Mission }> = ({ mission }) => {
  const { executeMissionClick } = useGame();
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [isAnimate, setIsAnimate] = useState(false);
  const [isLoadingRewarded, setIsLoadingRewarded] = useState(false);

  // Calcula o tempo restante baseado no timestamp salvo
  useEffect(() => {
    if (mission.isLocked) {
      setTimeLeft(0);
      return;
    }

    const calculateTimeLeft = () => {
      if (!mission.lastClickTimestamp) return 0;
      const now = Date.now();
      const elapsed = (now - mission.lastClickTimestamp) / 1000;
      const remaining = Math.ceil(mission.cooldownSeconds - elapsed);
      return remaining > 0 ? remaining : 0;
    };

    setTimeLeft(calculateTimeLeft());

    const interval = setInterval(() => {
      const remaining = calculateTimeLeft();
      setTimeLeft(remaining);
      if (remaining <= 0) clearInterval(interval);
    }, 1000);

    return () => {
      clearInterval(interval);
      // Limpar listener de anúncios ao desmontar
      unregisterAdEventListener();
    };
  }, [mission.lastClickTimestamp, mission.cooldownSeconds, mission.isLocked]);

  const handleClick = () => {
    if (timeLeft > 0 || mission.isLocked || isLoadingRewarded) return;
    
    // Verificar se está em ambiente Unity
    if (isUnityEnvironment()) {
      // Em Unity: mostrar rewarded video primeiro
      handleRewardedVideoClick();
    } else {
      // Em navegador: comportamento normal (missão)
      setIsAnimate(true);
      setTimeout(() => setIsAnimate(false), 300);
      executeMissionClick(mission.id);
    }
  };

  const handleRewardedVideoClick = () => {
    setIsLoadingRewarded(true);
    
    // Registrar listener para eventos do anúncio
    const adEventListener = (eventType: string, adType: string) => {
      if (eventType === AdEventType.REWARDED) {
        // Vídeo completado com sucesso
        console.log('[MissionCard] ✅ Rewarded video completado!');
        
        // REMOVIDO: React não deve gerar pontos
        // Unity já envia pontos automaticamente quando vídeo é completado
        // Unity envia: 10 pontos principais + 2 pontos de missão = 12 pontos totais
        
        // Executar a missão normalmente
        setIsAnimate(true);
        setTimeout(() => setIsAnimate(false), 300);
        executeMissionClick(mission.id);
        
        setIsLoadingRewarded(false);
        unregisterAdEventListener();
      } else if (eventType === AdEventType.FAILED || eventType === AdEventType.CANCELED) {
        // Vídeo falhou ou foi cancelado
        console.log('[MissionCard] ❌ Rewarded video falhou ou foi cancelado');
        setIsLoadingRewarded(false);
        unregisterAdEventListener();
      }
    };
    
    registerAdEventListener(adEventListener);
    
    // Solicitar rewarded video ao Unity
    const success = showRewardedVideo('max'); // Usar MAX por padrão
    
    if (!success) {
      console.warn('[MissionCard] ⚠️ Não foi possível enviar comando para Unity');
      setIsLoadingRewarded(false);
      unregisterAdEventListener();
      
      // Fallback: executar missão normalmente
      setIsAnimate(true);
      setTimeout(() => setIsAnimate(false), 300);
      executeMissionClick(mission.id);
    }
  };

  const progress = (mission.currentClicks / mission.requiredClicks) * 100;

  return (
    <div className={`bg-white rounded-2xl p-4 border shadow-sm flex flex-col justify-between min-w-[240px] w-[240px] snap-center relative overflow-hidden transition-all duration-300 ${mission.isLocked ? 'border-gray-200 opacity-60 grayscale' : 'border-blue-100 hover:shadow-md hover:border-blue-200'}`}>
      
      {/* Locked Overlay */}
      {mission.isLocked && (
        <div className="absolute inset-0 bg-gray-50/40 z-20 flex flex-col items-center justify-center backdrop-blur-[1px]">
           <div className="bg-white p-3 rounded-full shadow-lg mb-2">
             <Lock className="text-gray-400" size={20} />
           </div>
           <span className="text-[10px] font-bold text-gray-500 bg-white px-3 py-1 rounded-full shadow-sm border border-gray-100 uppercase tracking-wide">
             Bloqueado
           </span>
        </div>
      )}

      {/* Background Decor */}
      <div className={`absolute top-0 right-0 w-24 h-24 rounded-bl-full -mr-6 -mt-6 z-0 ${mission.isLocked ? 'bg-gray-100' : 'bg-blue-50'}`}></div>
      
      <div className="z-10 relative">
        <div className="flex justify-between items-start mb-3">
          <div className={`${mission.isLocked ? 'bg-gray-100 text-gray-400' : 'bg-blue-50 text-blue-600'} p-2 rounded-xl shadow-sm`}>
            <Target size={18} />
          </div>
          <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${mission.isLocked ? 'text-gray-400 bg-gray-50 border-gray-200' : 'text-green-700 bg-green-50 border-green-200 shadow-sm'}`}>
            +{mission.reward} pts
          </span>
        </div>
        
        <h4 className="font-bold text-gray-800 text-sm leading-tight">{mission.title}</h4>
        <p className="text-[11px] text-gray-500 mt-1">
          Clique {mission.requiredClicks} vezes
        </p>

        {/* Progress Bar */}
        <div className="mt-4 mb-2">
           <div className="flex justify-between text-[10px] text-gray-400 font-bold mb-1.5 uppercase tracking-wide">
              <span>Progresso</span>
              <span>{mission.currentClicks}/{mission.requiredClicks}</span>
           </div>
           <div className="h-2 bg-gray-100 rounded-full overflow-hidden border border-gray-50">
             <div 
               className={`h-full rounded-full transition-all duration-500 ease-out ${mission.isLocked ? 'bg-gray-300' : 'bg-gradient-to-r from-blue-400 to-blue-600'}`}
               style={{ width: `${progress}%` }}
             ></div>
           </div>
        </div>
      </div>

      <button
        onClick={handleClick}
        disabled={timeLeft > 0 || mission.isLocked || isLoadingRewarded}
        className={`
          mt-2 w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all duration-200 z-10
          ${(timeLeft > 0 || mission.isLocked || isLoadingRewarded)
            ? 'bg-gray-100 text-gray-400 cursor-not-allowed border border-gray-200' 
            : 'bg-blue-600 text-white hover:bg-blue-700 shadow-blue-200 shadow-md active:scale-95'
          }
          ${isAnimate ? 'scale-95' : ''}
        `}
      >
        {mission.isLocked ? (
           <>
            <Lock size={14} />
            BLOQUEADO
           </>
        ) : timeLeft > 0 ? (
          <>
            <Clock size={14} className="animate-pulse" />
            {timeLeft}s
          </>
        ) : isLoadingRewarded ? (
          <>
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            CARREGANDO...
          </>
        ) : (
          <>
            <Zap size={14} className="fill-current" />
            RECEBER
          </>
        )}
      </button>
    </div>
  );
};

export const Home: React.FC = () => {
  const { points, transactions, currentLevelConfig, userProfile, missions, refreshProfile } = useGame();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // States for Ad Popup
  const [showAdPopup, setShowAdPopup] = useState(false);
  const [adTimer, setAdTimer] = useState(35);
  const [canCloseAd, setCanCloseAd] = useState(false);
  const [adCooldown, setAdCooldown] = useState(0); // Cooldown de 15 segundos após fechar
  const [adKey, setAdKey] = useState(0); // Key para forçar reload do AdSense
  const [bonusProgress, setBonusProgress] = useState(0); // Progresso das bolinhas (0-3)
  const adCooldownRef = useRef<NodeJS.Timeout | null>(null);
  
  // Carregar progresso do Super Bônus do localStorage
  useEffect(() => {
    const SUPER_BONUS_COUNTER_KEY = 'pix_super_bonus_counter';
    const savedCount = parseInt(localStorage.getItem(SUPER_BONUS_COUNTER_KEY) || '0', 10);
    setBonusProgress(savedCount % 3); // Mostrar progresso atual (0, 1 ou 2)
  }, []);
  
  // Cálculo do progresso baseado na meta do nível atual
  const progress = Math.min((points / currentLevelConfig.requiredPoints) * 100, 100);
  const pointsNeeded = Math.max(0, currentLevelConfig.requiredPoints - points);

  // Atualizar pontos do backend quando a página Home carregar
  useEffect(() => {
    const loadPointsOnMount = async () => {
      console.log('[Home] 🔄 Carregando pontos do backend ao abrir página...');
      
      // Verificar se temos guest_id
      const guestId = localStorage.getItem('guest_id');
      const isGuest = localStorage.getItem('is_guest') === 'true';
      
      if (!isGuest || !guestId) {
        console.warn('[Home] ⚠️ Guest não autenticado. guest_id:', guestId, 'is_guest:', isGuest);
        // Tentar novamente após um delay
        setTimeout(() => {
          const retryGuestId = localStorage.getItem('guest_id');
          const retryIsGuest = localStorage.getItem('is_guest') === 'true';
          if (retryIsGuest && retryGuestId) {
            console.log('[Home] 🔄 Tentando carregar pontos novamente...');
            refreshProfile();
          }
        }, 2000);
        return;
      }
      
      try {
        // Aguardar um pouco para garantir que o GameContext está pronto
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const success = await refreshProfile();
        if (success) {
          console.log('[Home] ✅ Pontos atualizados do backend');
        } else {
          console.warn('[Home] ⚠️ Não foi possível atualizar pontos do backend, tentando novamente...');
          
          // Tentar novamente após 1 segundo
          setTimeout(async () => {
            const retrySuccess = await refreshProfile();
            if (retrySuccess) {
              console.log('[Home] ✅ Pontos atualizados na segunda tentativa');
            } else {
              console.error('[Home] ❌ Falha ao atualizar pontos após múltiplas tentativas');
            }
          }, 1000);
        }
      } catch (error) {
        console.error('[Home] ❌ Erro ao atualizar pontos:', error);
        
        // Log detalhado
        if (error instanceof Error) {
          console.error('[Home] Erro detalhado:', {
            message: error.message,
            guestId: guestId,
            isGuest: isGuest
          });
        }
      }
    };

    // Delay maior para garantir que o contexto e o guest foram inicializados
    const timer = setTimeout(() => {
      loadPointsOnMount();
    }, 1000);

    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Executa apenas uma vez quando componente monta

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (showAdPopup && adTimer > 0) {
        interval = setInterval(() => {
            setAdTimer((prev) => prev - 1);
        }, 1000);
    } else if (showAdPopup && adTimer === 0) {
        setCanCloseAd(true);
    }
    return () => clearInterval(interval);
  }, [showAdPopup, adTimer]);

  // Cooldown de 15 segundos após fechar o popup
  useEffect(() => {
    if (adCooldown > 0) {
      const interval = setInterval(() => {
        setAdCooldown((prev) => {
          if (prev <= 1) {
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [adCooldown]);

  // Pré-carregar próximo anúncio durante o cooldown
  useEffect(() => {
    if (adCooldown > 0 && adCooldown <= 15) {
      // Pré-carregar o próximo anúncio quando estiver próximo do fim do cooldown
      // ou durante todo o cooldown para garantir que esteja pronto
      console.log('[Home] 🔄 Pré-carregando próximo anúncio... Cooldown:', adCooldown);
      
      // Forçar preparação do próximo AdSense
      const preloadTimer = setTimeout(() => {
        // Incrementar key para forçar novo carregamento quando abrir
        setAdKey((prev) => prev + 1);
        console.log('[Home] ✅ Próximo anúncio pré-carregado e pronto');
      }, 1000);
      
      return () => clearTimeout(preloadTimer);
    }
  }, [adCooldown]);

  // Cleanup do cooldown quando componente desmontar
  useEffect(() => {
    return () => {
      if (adCooldownRef.current) {
        clearTimeout(adCooldownRef.current);
        adCooldownRef.current = null;
      }
    };
  }, []);

  // Ajustar scroll quando o modal de anúncio é fechado
  useEffect(() => {
    if (showAdPopup) {
      // Quando o modal abre, prevenir scroll do body e salvar posição atual
      const scrollY = window.scrollY || document.documentElement.scrollTop;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
      document.body.style.overflow = 'hidden';
      document.documentElement.style.overflow = 'hidden';
    } else {
      // Quando o modal fecha, restaurar scroll e ajustar para o topo
      const bodyTop = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
      
      // Ajustar scroll para remover espaços no topo - múltiplas tentativas para garantir
      const adjustScroll = () => {
        window.scrollTo({ top: 0, behavior: 'instant' });
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        
        // Forçar ajuste do layout
        const mainElement = document.querySelector('main');
        if (mainElement) {
          mainElement.scrollTop = 0;
        }
        
        // Se havia uma posição salva, restaurar para 0
        if (bodyTop) {
          window.scrollTo(0, 0);
        }
      };
      
      // Ajustar imediatamente e depois novamente para garantir
      adjustScroll();
      setTimeout(adjustScroll, 50);
      setTimeout(adjustScroll, 150);
    }
    
    return () => {
      // Cleanup: garantir que os estilos sejam restaurados
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    };
  }, [showAdPopup]);

  const handleOpenAd = () => {
    // Verificar se está em cooldown
    if (adCooldown > 0) {
      console.log('[Home] ⏳ Super Bônus em cooldown. Aguarde:', adCooldown, 'segundos');
      return;
    }
    
    setShowAdPopup(true);
    setAdTimer(35);
    setCanCloseAd(false);
    // Incrementar key para forçar novo carregamento do AdSense
    setAdKey((prev) => prev + 1);
    console.log('[Home] 🎬 Abrindo Super Bônus com novo anúncio (key:', adKey + 1, ')');
  };

  const handleCloseAd = async () => {
    if (!canCloseAd) return;
    
    // Contador de popups finalizados (1 ponto a cada 3 popups)
    const SUPER_BONUS_COUNTER_KEY = 'pix_super_bonus_counter';
    const currentCount = parseInt(localStorage.getItem(SUPER_BONUS_COUNTER_KEY) || '0', 10);
    const newCount = currentCount + 1;
    
    console.log('[Home] 🎯 Super Bônus: Popup finalizado', {
      currentCount,
      newCount,
      shouldAwardPoints: newCount >= 3
    });
    
    // Salvar novo contador
    localStorage.setItem(SUPER_BONUS_COUNTER_KEY, newCount.toString());
    
    // Atualizar progresso visual das bolinhas
    // Quando newCount = 3, mostrar todas as 3 bolinhas verdes antes de resetar
    if (newCount >= 3) {
      setBonusProgress(3); // Mostrar todas as 3 bolinhas verdes
    } else {
      setBonusProgress(newCount);
    }
    
    // Só adicionar pontos quando chegar a 3 popups
    if (newCount >= 3) {
      // Resetar contador após um pequeno delay para mostrar as 3 bolinhas verdes
      setTimeout(() => {
        localStorage.setItem(SUPER_BONUS_COUNTER_KEY, '0');
        setBonusProgress(0); // Resetar bolinhas após completar
      }, 500); // 500ms para o usuário ver todas as bolinhas verdes
      
      const guestId = localStorage.getItem('guest_id');
      const isGuest = localStorage.getItem('is_guest') === 'true';
      
      console.log('[Home] 🎯 Super Bônus: 3 popups completados! Adicionando 1 ponto...', {
        guestId,
        isGuest
      });
      
      if (!isGuest || !guestId) {
        console.error('[Home] ❌ Super Bônus: Guest não autenticado', {
          isGuest,
          guestId
        });
        setShowAdPopup(false);
        return;
      }
      
      const parsedGuestId = parseInt(guestId, 10);
      if (isNaN(parsedGuestId) || parsedGuestId <= 0) {
        console.error('[Home] ❌ Super Bônus: guest_id inválido', guestId);
        setShowAdPopup(false);
        return;
      }
      
      try {
        const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
        const payload = {
          guest_id: parsedGuestId,
          points: 1,
          source: 'react',
          description: 'Super Bônus - Complete 3 popups e ganhe +1 ponto'
        };
        
        console.log('[Home] 📤 Super Bônus: Enviando requisição...', {
          url: `${API_BASE_URL}add_super_bonus_points.php`,
          payload
        });
        
        const response = await fetch(`${API_BASE_URL}add_super_bonus_points.php`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify(payload)
        });
        
        console.log('[Home] 📥 Super Bônus: Resposta recebida', {
          status: response.status,
          statusText: response.statusText,
          ok: response.ok
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error('[Home] ❌ Super Bônus: Erro HTTP', {
            status: response.status,
            statusText: response.statusText,
            errorText
          });
          setShowAdPopup(false);
          return;
        }
        
        const data = await response.json();
        console.log('[Home] 📊 Super Bônus: Dados recebidos', data);
        
        if (data.status === 'success' && data.new_total !== undefined) {
          // Atualizar localStorage
          localStorage.setItem('pix_points', data.new_total.toString());
          
          console.log('[Home] 💾 Super Bônus: localStorage atualizado', {
            new_total: data.new_total
          });
          
          // Recarregar perfil para sincronizar todos os dados
          try {
            await refreshProfile();
            console.log('[Home] ✅ Super Bônus: Perfil recarregado com sucesso');
          } catch (refreshError) {
            console.error('[Home] ⚠️ Super Bônus: Erro ao recarregar perfil (mas pontos foram salvos)', refreshError);
          }
          
          console.log('[Home] ✅ Super Bônus: 1 ponto adicionado com sucesso. Novo total:', data.new_total);
        } else {
          console.error('[Home] ❌ Super Bônus: Resposta inválida do servidor', {
            status: data.status,
            new_total: data.new_total,
            message: data.message,
            fullResponse: data
          });
        }
      } catch (error) {
        console.error('[Home] ❌ Super Bônus: Erro ao salvar pontos', {
          error,
          message: error instanceof Error ? error.message : 'Erro desconhecido',
          stack: error instanceof Error ? error.stack : undefined
        });
      }
    } else {
      console.log('[Home] 📊 Super Bônus: Popup contado. Progresso:', `${newCount}/3`);
    }
    
    // Fechar o modal
    setShowAdPopup(false);
    
    // Iniciar cooldown de 15 segundos e pré-carregar próximo anúncio
    setAdCooldown(15);
    console.log('[Home] ⏰ Cooldown iniciado: 15 segundos. Pré-carregando próximo anúncio...');
    
    // Limpar timer anterior se existir
    if (adCooldownRef.current) {
      clearTimeout(adCooldownRef.current);
    }
    
    // Pré-carregar próximo anúncio após um pequeno delay
    adCooldownRef.current = setTimeout(() => {
      setAdKey((prev) => prev + 1);
      console.log('[Home] ✅ Próximo anúncio pré-carregado durante cooldown');
      adCooldownRef.current = null;
    }, 2000); // 2 segundos após fechar
    
    // O ajuste do scroll será feito pelo useEffect que monitora showAdPopup
  };

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 256; // Largura do card (240px) + gap (16px)
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="p-6 space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Olá, {userProfile.name ? userProfile.name.split(' ')[0] : 'Jogador'}! 👋</h1>
          <div className="flex items-center gap-2 mt-1">
             <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs font-bold rounded-full border border-yellow-200 flex items-center gap-1">
               <Crown size={12} /> Nível {userProfile.level}
             </span>
             <p className="text-xs text-gray-500">Total: {userProfile.lifetimePoints} pts</p>
          </div>
        </div>
        <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center text-green-700 shadow-sm border border-green-200">
          <Award size={20} />
        </div>
      </header>
      
       {/* MISSIONS SECTION */}
       <div>
         <div className="flex items-center justify-between mb-3 px-1">
            <h3 className="font-bold text-gray-800 flex items-center gap-2 text-sm">
                <Star size={16} className="text-yellow-500 fill-current" /> Missões Diárias
            </h3>
            <span className="text-[10px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-bold">
                {missions.filter(m => !m.isLocked).length} Disponível
            </span>
         </div>
         
         {/* Container do Slider com Navegação */}
         <div className="relative group">
            {/* Botão Esquerda */}
            <button 
              onClick={() => scroll('left')}
              className="absolute left-0 top-1/2 -translate-y-1/2 -ml-2 z-20 bg-white/80 backdrop-blur-sm p-2 rounded-full shadow-md border border-gray-100 text-gray-600 hover:text-blue-600 hover:scale-110 transition-all opacity-0 group-hover:opacity-100 disabled:opacity-0"
            >
              <ChevronLeft size={20} />
            </button>

            {/* Slider Centralizado */}
            <div 
              ref={scrollContainerRef}
              className="w-full overflow-x-auto scrollbar-hide pb-2 snap-x flex gap-4 px-1"
            >
                {missions.map(mission => (
                    <MissionCard key={mission.id} mission={mission} />
                ))}
            </div>

            {/* Botão Direita */}
            <button 
              onClick={() => scroll('right')}
              className="absolute right-0 top-1/2 -translate-y-1/2 -mr-2 z-20 bg-white/80 backdrop-blur-sm p-2 rounded-full shadow-md border border-gray-100 text-gray-600 hover:text-blue-600 hover:scale-110 transition-all opacity-0 group-hover:opacity-100"
            >
              <ChevronRight size={20} />
            </button>
         </div>
       </div>

      {/* Points Card */}
      <div className="bg-gradient-to-br from-green-600 to-emerald-800 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white opacity-10 rounded-full blur-3xl group-hover:scale-110 transition-transform duration-700"></div>
        <div className="absolute bottom-0 left-0 -mb-4 -ml-4 w-24 h-24 bg-yellow-400 opacity-10 rounded-full blur-2xl"></div>
        
        <div className="flex justify-between items-start relative z-10">
            <div>
                <p className="text-green-100 text-sm font-medium flex items-center gap-1">
                    <Target size={14} /> Meta Nível {currentLevelConfig.level}
                </p>
                <h2 className="text-4xl font-extrabold mt-1 tracking-tight">{points} <span className="text-lg opacity-80 font-normal">/ {currentLevelConfig.requiredPoints}</span></h2>
            </div>
            <div className="bg-white/20 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 text-center">
                <span className="text-[10px] uppercase font-bold text-green-100 block">Vale</span>
                <span className="font-bold text-lg">R$ {currentLevelConfig.rewardValue.toFixed(2)}</span>
            </div>
        </div>
        
        <div className="mt-6 relative z-10">
          <div className="flex justify-between text-xs mb-2 text-green-100 font-medium">
            <span>Progresso para Saque</span>
            <span>{Math.floor(progress)}%</span>
          </div>
          <div className="h-3 bg-black/20 rounded-full overflow-hidden border border-white/10">
            <div 
              className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-1000 ease-out shadow-[0_0_10px_rgba(251,191,36,0.6)]" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          {pointsNeeded > 0 ? (
              <p className="text-[10px] text-green-200 mt-2 text-right">
                Faltam {pointsNeeded} pontos para liberar R$ {currentLevelConfig.rewardValue.toFixed(2)}
              </p>
          ) : (
              <p className="text-[10px] text-yellow-300 mt-2 text-right font-bold animate-pulse">
                Saque disponível! 🎉
              </p>
          )}
        </div>
      </div>

      {/* SUPER BONUS BUTTON */}
      <button 
        onClick={handleOpenAd}
        disabled={adCooldown > 0}
        className={`w-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white p-4 rounded-xl shadow-lg relative overflow-hidden group transition-transform ${
          adCooldown > 0 
            ? 'opacity-60 cursor-not-allowed' 
            : 'hover:scale-[1.02] active:scale-95'
        }`}
      >
         <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 ease-in-out"></div>
         <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
               <div className="bg-white/20 p-2 rounded-lg">
                  <Tv size={24} className={adCooldown > 0 ? '' : 'animate-pulse'} />
               </div>
               <div className="text-left">
                  <h3 className="font-bold text-lg leading-none">Super Bônus</h3>
                  {adCooldown > 0 ? (
                    <p className="text-xs text-indigo-100">Próximo anúncio em {adCooldown}s</p>
                  ) : (
                    <div>
                      <p className="text-xs text-indigo-100">Assista 35s - Complete 3 para ganhar +1 ponto</p>
                      {/* Indicador de progresso com 3 bolinhas - centralizado abaixo do texto */}
                      <div className="flex items-center justify-center gap-1 mt-1">
                        {[0, 1, 2].map((index) => (
                          <div
                            key={index}
                            className={`w-1.5 h-1.5 rounded-full transition-colors duration-300 ${
                              index < bonusProgress ? 'bg-green-400' : 'bg-gray-400'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  )}
               </div>
            </div>
            {adCooldown > 0 ? (
              <div className="bg-white/30 text-white font-bold px-3 py-1 rounded-full text-sm shadow-sm flex items-center gap-1">
                <Clock size={14} />
                {adCooldown}s
              </div>
            ) : (
              <div className="bg-white text-purple-600 font-bold px-3 py-1 rounded-full text-sm shadow-sm">
                  +1 PTS
              </div>
            )}
         </div>
      </button>

      {/* Action CTA */}
      <Link to="/earn" className="block group">
        <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm flex items-center justify-between hover:shadow-md transition-all hover:border-purple-200">
          <div className="flex items-center space-x-4">
            <div className="bg-purple-100 p-3 rounded-lg text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
              <TrendingUp size={24} />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Ganhar Pontos</h3>
              <p className="text-xs text-gray-500">Avance para o próximo nível</p>
            </div>
          </div>
          <div className="text-gray-300 group-hover:text-purple-600 transition-colors transform group-hover:translate-x-1">
            <ArrowRight size={20} />
          </div>
        </div>
      </Link>

      {/* Recent History */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-gray-800 flex items-center gap-2">
            <History size={16} /> Histórico Recente
          </h3>
        </div>

        {transactions.length === 0 ? (
          <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-200">
            <p className="text-gray-400 text-sm">Nenhuma atividade ainda.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {transactions.slice(0, 5).map((tx) => (
              <div key={tx.id} className="bg-white p-3 rounded-xl border border-gray-100 shadow-sm flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${tx.type === 'EARN' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">{tx.details}</p>
                    <p className="text-[10px] text-gray-400">{new Date(tx.date).toLocaleDateString()} • {new Date(tx.date).toLocaleTimeString()}</p>
                  </div>
                </div>
                <span className={`font-bold text-sm ${tx.type === 'EARN' ? 'text-green-600' : 'text-gray-600'}`}>
                  {tx.type === 'EARN' ? '+' : '-'}{Math.abs(tx.amount)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* AD MODAL POPUP */}
      {showAdPopup && (
        <div className="fixed inset-0 z-[100] bg-black/90 flex flex-col items-center justify-center animate-in fade-in">
            {/* Overlay Click Block (User must wait) */}
            
            <div className="w-[90%] max-w-sm bg-white rounded-xl overflow-hidden relative shadow-2xl">
                 {/* Header com o Timer e o Título */}
                 <div className="bg-gray-100 px-4 py-2 flex justify-between items-center border-b border-gray-200">
                    <span className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Patrocinado</span>
                    
                    {canCloseAd ? (
                        <button 
                            onClick={handleCloseAd}
                            className="bg-red-500 hover:bg-red-600 text-white rounded-full p-1 transition-colors"
                        >
                            <X size={16} />
                        </button>
                    ) : (
                        <div className="text-gray-600 text-xs font-bold font-mono flex items-center gap-1">
                            <Clock size={12} className="animate-pulse text-blue-500" />
                            {adTimer}s
                        </div>
                    )}
                 </div>
                 
                 {/* Ad Container - Altura ajustada para o banner 350x90 */}
                 <div className="bg-gray-50 flex items-center justify-center p-4 min-h-[120px]">
                    {/* Key force re-render com contador para garantir novo anúncio a cada abertura */}
                    <AdSenseBlock key={`ad-${adKey}-${showAdPopup}`} />
                 </div>

                 {/* Footer Status */}
                 <div className="p-3 text-center bg-white">
                    {canCloseAd ? (
                        <p className="text-green-600 font-bold text-xs animate-pulse flex items-center justify-center gap-1">
                            <CheckCircle2 size={14}/> Recompensa disponível!
                        </p>
                    ) : (
                        <p className="text-gray-400 text-[10px]">
                            Aguarde o carregamento e o tempo acabar.
                        </p>
                    )}
                 </div>
            </div>
        </div>
      )}

    </div>
  );
};