import React, { useState, useEffect, useRef } from 'react';
import { useGame } from '../context/GameContext';
import { Gamepad2, Gift, Clock, Play, ChevronLeft, Circle, X, Target, Check, Coins, Sprout, Sparkles } from 'lucide-react';
import { showRewardedVideo, registerAdEventListener, unregisterAdEventListener, AdEventType, preloadNextRewardedVideo } from '../services/unityBridge';

const BONUS_TIME_SECONDS = 60; // Tempo em segundos para o bônus aparecer
const TIMER_TARGET_KEY = 'pix_game_target_time_v2'; // Chave para salvar o timestamp final

// Lista de Jogos (Filtrada)
const GAMES_LIST = [
  { 
    id: 'farm-family', 
    name: 'Farm Family', 
    category: 'Simulação', 
    url: 'https://games.crazygames.com/en_US/farm-family/index.html?v=1.347', 
    image: 'https://imgs.crazygames.com/farm-family/20230331124843/farm-family-cover?metadata=none&quality=85&width=196&dpr=1',
    color: 'from-green-400 to-yellow-400',
    icon: Sprout,
    orientation: 'landscape' // Propriedade mantida mas não usada visualmente
  },
  { 
    id: 'ragdoll-archers', 
    name: 'Ragdoll Archers', 
    category: 'Ação', 
    url: 'https://games.crazygames.com/en_US/ragdoll-archers/index.html?v=1.347', 
    image: 'https://imgs.crazygames.com/ragdoll-archers_16x9/20250926080758/ragdoll-archers_16x9-cover?metadata=none&quality=85&width=196&dpr=1',
    color: 'from-orange-600 to-red-600',
    icon: Target
  },
  { 
    id: 'arcade-center', 
    name: 'Arcade Center', 
    category: 'Aventura',
    url: 'https://html5.gamedistribution.com/1ae5b8b1590c4119bb5163d98b51be2c/?gd_sdk_referrer_url=https://gamedistribution.com/games/my-arcade-center-1/', 
    image: 'https://img.gamedistribution.com/1ae5b8b1590c4119bb5163d98b51be2c-512x384.jpg', 
    color: 'from-pink-600 to-rose-500',
    icon: Gamepad2
  },
  { 
    id: 'magic-sort', 
    name: 'Magic Sort', 
    category: 'Puzzle',
    url: 'https://html5.gamedistribution.com/a3889875d26547899d96b0364d6473f5/?gd_sdk_referrer_url=https://gamedistribution.com/games/magic-sort/', 
    image: 'https://img.gamedistribution.com/a3889875d26547899d96b0364d6473f5-512x384.jpg', 
    color: 'from-purple-500 to-indigo-600',
    icon: Sparkles
  },
  {
    id: 'bubble-shooter',
    name: 'Bubble Shooter',
    category: 'Clássico',
    url: 'https://html5.gamedistribution.com/0b18452cd7844e308b726bf05034fac2/?gd_sdk_referrer_url=https://gamedistribution.com/games/bubble-shooter-wild-west/', 
    image: 'https://img.gamedistribution.com/0b18452cd7844e308b726bf05034fac2-1280x550.jpg',
    color: 'from-red-500 to-orange-500',
    icon: Circle
  }
];

export const Earn: React.FC = () => {
  const { points } = useGame();
  
  // Estado de navegação
  const [activeGame, setActiveGame] = useState<typeof GAMES_LIST[0] | null>(null);
  const [isLoadingGame, setIsLoadingGame] = useState(false);
  
  // Lógica do Bônus Temporal
  const [showBonusBox, setShowBonusBox] = useState(false);
  const [isClaiming, setIsClaiming] = useState(false); // Novo estado para animação
  const [isLoadingVideo, setIsLoadingVideo] = useState(false); // Estado para carregamento do vídeo
  
  // Ref para armazenar o timer de pré-carregamento
  const preloadTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Inicializa o timestamp alvo.
  const [targetTime, setTargetTime] = useState<number>(() => {
    const savedTarget = localStorage.getItem(TIMER_TARGET_KEY);
    if (savedTarget) {
      return parseInt(savedTarget, 10);
    }
    const now = Date.now();
    const newTarget = now + (BONUS_TIME_SECONDS * 1000);
    localStorage.setItem(TIMER_TARGET_KEY, newTarget.toString());
    return newTarget;
  });

  const [secondsLeft, setSecondsLeft] = useState<number>(BONUS_TIME_SECONDS);

  // Efeito do Timer
  useEffect(() => {
    const updateTimer = () => {
      const now = Date.now();
      const diff = Math.ceil((targetTime - now) / 1000);
      
      if (diff <= 0) {
        setSecondsLeft(0);
        if (!showBonusBox && !isClaiming) {
            setShowBonusBox(true);
        }
      } else {
        setSecondsLeft(diff);
        if (showBonusBox && !isClaiming) {
            setShowBonusBox(false);
        }
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [targetTime, showBonusBox, isClaiming]);

  // Função auxiliar para resetar o timer
  const resetTimer = () => {
    const now = Date.now();
    const newTarget = now + (BONUS_TIME_SECONDS * 1000);
    setTargetTime(newTarget);
    setSecondsLeft(BONUS_TIME_SECONDS);
    localStorage.setItem(TIMER_TARGET_KEY, newTarget.toString());
  };

  const handleClaimBonus = () => {
    if (isClaiming || isLoadingVideo) return;
    
    setIsLoadingVideo(true);
    
    // Registrar listener para eventos do anúncio
    const adEventListener = (eventType: string, adType: string) => {
      if (eventType === AdEventType.REWARDED) {
        // Vídeo completado com sucesso
        console.log('[Earn] ✅ Rewarded video completado! Concedendo pontos...');
        
        // Unity já envia os pontos automaticamente ao servidor quando o vídeo é completado
        // Mas vamos mostrar a animação de confirmação
        setIsClaiming(true);
        setIsLoadingVideo(false);
        
        // Limpar timer anterior se existir
        if (preloadTimerRef.current) {
          clearTimeout(preloadTimerRef.current);
          preloadTimerRef.current = null;
        }
        
        // Pré-carregar o próximo vídeo após 60 segundos
        console.log('[Earn] ⏰ Agendando pré-carregamento do próximo vídeo em 60 segundos...');
        preloadTimerRef.current = setTimeout(() => {
          console.log('[Earn] 🔄 Pré-carregando próximo rewarded video...');
          preloadNextRewardedVideo();
          preloadTimerRef.current = null;
        }, 60000); // 60 segundos
        
        // Aguarda a animação terminar antes de fechar
        setTimeout(() => {
          setIsClaiming(false);
          setShowBonusBox(false);
          resetTimer();
        }, 1500);
        
        unregisterAdEventListener();
      } else if (eventType === AdEventType.FAILED || eventType === AdEventType.CANCELED) {
        // Vídeo falhou ou foi cancelado
        console.log('[Earn] ❌ Rewarded video falhou ou foi cancelado');
        setIsLoadingVideo(false);
        unregisterAdEventListener();
      } else if (eventType === AdEventType.CLOSED) {
        // Vídeo foi fechado sem completar
        console.log('[Earn] ⚠️ Rewarded video foi fechado sem completar');
        setIsLoadingVideo(false);
        unregisterAdEventListener();
      }
    };
    
    registerAdEventListener(adEventListener);
    
    // Solicitar rewarded video ao Unity
    const success = showRewardedVideo('max'); // Usar MAX por padrão
    
    if (!success) {
      console.warn('[Earn] ⚠️ Não foi possível enviar comando para Unity');
      setIsLoadingVideo(false);
      unregisterAdEventListener();
      
      // Fallback: se Unity não estiver disponível, simular sucesso (para desenvolvimento)
      // Em produção, você pode querer mostrar uma mensagem de erro
      if (typeof window !== 'undefined' && !window.navigator.userAgent.includes('wv')) {
        console.log('[Earn] ⚠️ Ambiente de desenvolvimento - simulando sucesso');
        setIsClaiming(true);
        setTimeout(() => {
          setIsClaiming(false);
          setShowBonusBox(false);
          resetTimer();
        }, 1500);
      }
    }
  };

  const handleCloseBonus = () => {
    if (isClaiming || isLoadingVideo) return;
    setShowBonusBox(false);
    resetTimer();
    // Limpar listener se estiver registrado
    unregisterAdEventListener();
  }
  
  // Cleanup: remover listener quando componente desmontar ou bonus box fechar
  useEffect(() => {
    return () => {
      if (!showBonusBox) {
        unregisterAdEventListener();
      }
    };
  }, [showBonusBox]);
  
  // Cleanup: limpar timer de pré-carregamento quando componente desmontar
  useEffect(() => {
    return () => {
      if (preloadTimerRef.current) {
        clearTimeout(preloadTimerRef.current);
        preloadTimerRef.current = null;
      }
    };
  }, []);

  const handleSelectGame = (game: typeof GAMES_LIST[0]) => {
    setIsLoadingGame(true);
    setActiveGame(game);
  };

  const handleBackToCatalog = () => {
    setActiveGame(null);
    setIsLoadingGame(false);
  };

  const progressPercent = Math.min(100, Math.max(0, ((BONUS_TIME_SECONDS - secondsLeft) / BONUS_TIME_SECONDS) * 100));

  // Estilos de animação inline
  const animationStyles = `
    @keyframes fly-to-wallet {
      0% { transform: translate(0, 0) scale(1) rotate(0deg); opacity: 1; }
      50% { opacity: 1; }
      100% { transform: translate(120px, -400px) scale(0.5) rotate(360deg); opacity: 0; }
    }
    @keyframes pop-in {
      0% { transform: scale(0); opacity: 0; }
      60% { transform: scale(1.2); opacity: 1; }
      100% { transform: scale(1); opacity: 1; }
    }
    .coin-particle {
      position: absolute;
      animation: fly-to-wallet 1s ease-in forwards;
      pointer-events: none;
      z-index: 100;
    }
  `;

  return (
    <div className="flex flex-col h-full w-full bg-slate-900 text-white overflow-hidden relative">
      <style>{animationStyles}</style>

      {/* Caixinha de Bônus (Overlay) - Z-INDEX aumentado para ficar acima do jogo rotacionado */}
      {showBonusBox && (
        <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md animate-in fade-in duration-300 px-4">
           
           <div className="relative bg-slate-800 p-6 rounded-2xl border border-slate-700 shadow-2xl flex flex-col items-center gap-4 max-w-xs w-full animate-in zoom-in-95 duration-300">
              
              {/* Partículas de Moedas */}
              {isClaiming && Array.from({ length: 12 }).map((_, i) => (
                <div 
                  key={i} 
                  className="coin-particle text-yellow-400"
                  style={{
                    left: '50%',
                    top: '60%',
                    animationDelay: `${i * 0.05}s`,
                    marginLeft: `${(Math.random() - 0.5) * 60}px`,
                    marginTop: `${(Math.random() - 0.5) * 60}px`,
                  }}
                >
                  <Coins size={24} fill="currentColor" />
                </div>
              ))}

              {!isClaiming && !isLoadingVideo && (
                <button 
                  onClick={handleCloseBonus}
                  className="absolute top-2 right-2 p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors"
                >
                  <X size={20} />
                </button>
              )}

              <div className={`bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full p-4 shadow-[0_0_20px_rgba(124,58,237,0.5)] transition-all duration-500 ${isClaiming ? 'scale-110 bg-green-500 from-green-500 to-emerald-600 shadow-[0_0_30px_rgba(34,197,94,0.6)]' : 'animate-pulse'}`}>
                {isClaiming ? (
                  <Check size={40} className="text-white animate-[pop-in_0.4s_ease-out]" />
                ) : (
                  <Gift size={40} className="text-white fill-white/20" />
                )}
              </div>
              
              <div className="text-center space-y-1">
                <h3 className="text-xl font-bold text-white">
                    {isClaiming ? 'Resgatado!' : 'Bônus Extra!'}
                </h3>
                <p className="text-sm text-gray-400">
                    {isClaiming 
                      ? 'Pontos adicionados à carteira.' 
                      : isLoadingVideo 
                      ? 'Aguarde o vídeo carregar...' 
                      : 'Assista um vídeo curto e ganhe'}
                </p>
              </div>

              <button
                onClick={handleClaimBonus}
                disabled={isClaiming || isLoadingVideo}
                className={`w-full font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg 
                  ${isClaiming 
                    ? 'bg-green-500 text-white scale-105 shadow-green-900/40 cursor-default' 
                    : isLoadingVideo
                    ? 'bg-blue-500 text-white cursor-wait opacity-75'
                    : 'bg-green-500 hover:bg-green-600 text-white active:scale-95 shadow-green-900/20'
                  }`}
              >
                {isClaiming ? (
                  <>
                    <span className="animate-pulse">+2 PONTOS</span>
                  </>
                ) : isLoadingVideo ? (
                  <>
                    <Clock size={20} className="animate-spin" />
                    <span>Carregando vídeo...</span>
                  </>
                ) : (
                  <>
                    <span>Assistir Vídeo e Ganhar +2 Pontos</span>
                  </>
                )}
              </button>
           </div>

        </div>
      )}

      {/* Header Fixo */}
      <header className="bg-slate-800 p-3 shadow-lg z-20 border-b border-slate-700 shrink-0 relative">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center gap-3">
            {activeGame ? (
                <button 
                    onClick={handleBackToCatalog}
                    className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded-lg text-white transition-colors"
                >
                    <ChevronLeft size={20} />
                </button>
            ) : (
                <div className="p-1.5 bg-green-500/20 rounded-lg">
                    <Gamepad2 size={20} className="text-green-400" />
                </div>
            )}
            
            <div>
                <h1 className="font-bold text-sm leading-tight text-white">
                    {activeGame ? activeGame.name : 'Catálogo de Jogos'}
                </h1>
                <p className="text-[10px] text-gray-400">
                    {activeGame ? 'Jogando agora' : 'Escolha e ganhe pontos'}
                </p>
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-2">
             <div className={`text-green-400 font-mono font-bold text-lg transition-transform duration-300 ${isClaiming ? 'scale-125 text-green-300' : ''}`}>
               {points} <span className="text-xs">pts</span>
             </div>
          </div>
        </div>

        {/* Timer Bar - Sempre visível */}
        <div className="bg-slate-900/50 rounded-lg p-1.5 border border-slate-700 relative overflow-hidden flex items-center gap-3">
          <div className="flex items-center gap-1.5 shrink-0">
            <Clock size={14} className="text-blue-400" />
            <span className="font-mono text-xs font-bold text-white w-10">
                {Math.floor(secondsLeft / 60)}:{(secondsLeft % 60).toString().padStart(2, '0')}
            </span>
          </div>
          <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden relative">
             <div 
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-1000 ease-linear shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                style={{ width: `${progressPercent}%` }}
             />
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <div className={`flex-1 overflow-hidden relative bg-slate-900 w-full ${activeGame ? 'pb-16' : ''}`}>
        
        {/* VIEW: CATÁLOGO DE JOGOS (Se nenhum jogo estiver ativo) */}
        {!activeGame && (
            <div className="h-full overflow-y-auto p-4 scrollbar-hide">
                <div className="grid grid-cols-2 gap-4 pb-20">
                    {GAMES_LIST.map((game) => {
                        const Icon = game.icon;
                        // @ts-ignore - Verificando propriedade opcional image
                        const hasImage = game.image; 
                        
                        return (
                            <button
                                key={game.id}
                                onClick={() => handleSelectGame(game)}
                                className="group relative bg-slate-800 rounded-2xl flex flex-col items-center justify-between aspect-square border border-slate-700 hover:border-slate-500 transition-all active:scale-95 shadow-lg overflow-hidden"
                            >
                                {/* Imagem de Fundo (Se existir) */}
                                {hasImage ? (
                                    <>
                                        {/* @ts-ignore */}
                                        <img src={game.image} alt={game.name} className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent z-0"></div>
                                    </>
                                ) : (
                                    /* Fundo Padrão (Sem imagem) */
                                    <div className={`absolute inset-0 bg-gradient-to-br ${game.color} opacity-10 group-hover:opacity-20 transition-opacity`}></div>
                                )}
                                
                                <div className="absolute top-2 right-2 bg-black/60 px-2 py-0.5 rounded-full text-[9px] uppercase font-bold text-gray-300 backdrop-blur-sm border border-white/10 z-10">
                                    {game.category}
                                </div>

                                {/* Se NÃO tem imagem, mostra o ícone central. Se tem, o ícone some para mostrar a arte. */}
                                {!hasImage && (
                                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${game.color} flex items-center justify-center shadow-lg mt-auto mb-2 group-hover:scale-110 transition-transform duration-300`}>
                                        <Icon size={28} className="text-white drop-shadow-sm" />
                                    </div>
                                )}
                                
                                <div className={`text-center w-full z-10 p-3 ${hasImage ? 'mt-auto' : ''}`}>
                                    <h3 className="font-bold text-white text-sm leading-tight truncate w-full mb-1 drop-shadow-md">
                                        {game.name}
                                    </h3>
                                    <div className="flex items-center justify-center gap-1 text-[10px] text-gray-300">
                                        <Play size={10} className="fill-current" /> Jogar
                                    </div>
                                </div>
                            </button>
                        );
                    })}
                </div>
            </div>
        )}

        {/* VIEW: JOGO ATIVO (IFRAME) */}
        {activeGame && (
            <div className="transition-all duration-300 bg-black z-10 flex flex-col overflow-hidden w-full h-full max-h-full animate-in slide-in-from-right duration-300">
                {isLoadingGame && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400 bg-slate-900 z-20">
                        <div className={`p-4 rounded-full bg-gradient-to-br ${activeGame.color} mb-4 animate-bounce`}>
                             <activeGame.icon size={32} className="text-white" />
                        </div>
                        <p className="text-sm font-bold text-white mb-1">Carregando {activeGame.name}...</p>
                        <p className="text-xs text-gray-500">Prepare-se para ganhar pontos!</p>
                    </div>
                )}
                
                {/* 
                   TÉCNICA DE MASKING:
                   Aumentamos a altura do iframe para 114% (h-[114%])
                   Isso faz com que o rodapé do site do jogo (onde fica o menu indesejado) 
                   seja empurrado para fora da área visível do container (que tem overflow-hidden).
                   O container agora respeita o footer (64px) usando h-full em vez de absolute inset-0.
                */}
                <iframe
                    src={activeGame.url}
                    title={activeGame.name}
                    className="w-full h-[114%] border-0 block bg-black"
                    allow="autoplay; fullscreen; gyroscope; accelerometer"
                    onLoad={() => setIsLoadingGame(false)}
                />
            </div>
        )}

      </div>
    </div>
  );
};