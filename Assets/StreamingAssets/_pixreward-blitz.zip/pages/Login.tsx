import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, LogIn, Loader2, AlertCircle, CheckCircle2, Sparkles } from 'lucide-react';
import { createOrGetGuest, GuestResponse } from '../services/guestService';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Verificar se já está autenticado
  useEffect(() => {
    const guestId = localStorage.getItem('guest_id');
    const isGuest = localStorage.getItem('is_guest') === 'true';
    
    if (guestId && isGuest) {
      // Já está autenticado, redirecionar para home
      navigate('/');
    }
  }, [navigate]);

  const handleGuestLogin = async () => {
    setIsLoading(true);
    setError(null);
    setSuccess(null);

    try {
      console.log('[Login] 🔄 Iniciando login como guest...');
      
      const response: GuestResponse = await createOrGetGuest();

      if (response.status === 'success' && response.guest_id) {
        setSuccess(response.was_created 
          ? 'Conta de visitante criada com sucesso!' 
          : 'Bem-vindo de volta!');
        
        console.log('[Login] ✅ Login como guest realizado:', response.guest_id);
        
        // Pequeno delay para mostrar mensagem de sucesso
        setTimeout(() => {
          navigate('/');
        }, 1000);
      } else {
        throw new Error(response.message || 'Erro ao fazer login como guest');
      }
    } catch (err) {
      console.error('[Login] ❌ Erro ao fazer login:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido ao fazer login');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Logo/Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl shadow-lg mb-4">
            <Sparkles className="text-white" size={40} />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">PixReward Blitz</h1>
          <p className="text-gray-600">Entre e comece a ganhar pontos!</p>
        </div>

        {/* Card de Login */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          {/* Mensagens de Status */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
              <AlertCircle className="text-red-600 shrink-0 mt-0.5" size={20} />
              <div className="flex-1">
                <p className="text-sm font-semibold text-red-800">Erro ao fazer login</p>
                <p className="text-xs text-red-600 mt-1">{error}</p>
              </div>
            </div>
          )}

          {success && (
            <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
              <CheckCircle2 className="text-green-600 shrink-0 mt-0.5" size={20} />
              <div className="flex-1">
                <p className="text-sm font-semibold text-green-800">Sucesso!</p>
                <p className="text-xs text-green-600 mt-1">{success}</p>
              </div>
            </div>
          )}

          {/* Botão de Login como Guest */}
          <button
            onClick={handleGuestLogin}
            disabled={isLoading}
            className={`
              w-full py-4 px-6 rounded-xl font-bold text-white shadow-lg
              transition-all duration-200 flex items-center justify-center gap-3
              ${isLoading
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 hover:shadow-xl active:scale-95'
              }
            `}
          >
            {isLoading ? (
              <>
                <Loader2 className="animate-spin" size={20} />
                <span>Entrando...</span>
              </>
            ) : (
              <>
                <User size={20} />
                <span>Entrar como Visitante</span>
                <LogIn size={18} />
              </>
            )}
          </button>

          {/* Informações sobre Login Guest */}
          <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-100">
            <p className="text-xs text-blue-800 text-center leading-relaxed">
              <strong>✨ Login Rápido</strong><br />
              Entre como visitante e comece a ganhar pontos imediatamente. 
              Seus dados serão salvos automaticamente no dispositivo.
            </p>
          </div>

          {/* Divider */}
          <div className="my-6 flex items-center gap-4">
            <div className="flex-1 h-px bg-gray-200"></div>
            <span className="text-xs text-gray-400 font-medium">OU</span>
            <div className="flex-1 h-px bg-gray-200"></div>
          </div>

          {/* Informação sobre Unity */}
          <div className="mt-4 p-3 bg-gray-50 rounded-lg border border-gray-100">
            <p className="text-[10px] text-gray-500 text-center">
              💡 Se você está usando o app dentro do Unity, o login será automático
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            Ao continuar, você concorda com nossos termos de uso
          </p>
        </div>
      </div>
    </div>
  );
};





