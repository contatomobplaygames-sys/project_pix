/**
 * Guest Service
 * Serviço para gerenciar guests com criação automática via device fingerprint
 * Similar ao sistema do mobpix2026
 */

import { deviceFingerprint } from './deviceFingerprint';

const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';

export interface GuestResponse {
  status: 'success' | 'error';
  message: string;
  guest_id?: number;
  device_id?: string;
  points?: number;
  level?: number;
  lifetime_points?: number;
  was_created?: boolean;
  guest_name?: string;
  email?: string;
}

/**
 * Gera ou obtém device_id único
 */
export const getOrCreateDeviceId = async (): Promise<string> => {
  let deviceId = localStorage.getItem('device_id');

  if (!deviceId) {
    // Gerar fingerprint do dispositivo
    try {
      deviceId = await deviceFingerprint.generate();
      localStorage.setItem('device_id', deviceId);
      console.log('[GuestService] ✅ Device ID gerado:', deviceId.substring(0, 16) + '...');
    } catch (error) {
      console.error('[GuestService] ❌ Erro ao gerar device ID:', error);
      // Fallback: usar timestamp + random
      deviceId = 'web_' + Date.now() + '_' + Math.random().toString(36).substring(2, 15);
      localStorage.setItem('device_id', deviceId);
    }
  }

  return deviceId;
};

/**
 * Cria ou recupera guest no servidor baseado no device fingerprint
 */
export const createOrGetGuest = async (): Promise<GuestResponse> => {
  try {
    // 1. Verificar se já temos guest_id no localStorage (dados do Unity ou sessão anterior)
    const existingGuestId = localStorage.getItem('guest_id');
    const existingDeviceId = localStorage.getItem('device_id');
    
    if (existingGuestId && existingDeviceId) {
      console.log('[GuestService] ✅ Guest existente encontrado no localStorage:', existingGuestId);
      
      // Verificar se ainda é válido no servidor
      try {
        const response = await fetch(`${API_BASE_URL}get_user_profile.php?guest_id=${existingGuestId}`);
        const profileData = await response.json();
        
        if (profileData.success && profileData.user) {
          return {
            status: 'success',
            message: 'Guest recuperado do servidor',
            guest_id: parseInt(existingGuestId, 10),
            device_id: existingDeviceId,
            points: profileData.user.points || 0,
            level: profileData.user.level || 1,
            lifetime_points: profileData.user.lifetime_points || 0,
            was_created: false
          };
        }
      } catch (e) {
        console.warn('[GuestService] ⚠️ Não foi possível verificar guest no servidor, usando dados locais');
      }
      
      // Se não conseguiu verificar no servidor, usar dados locais
      return {
        status: 'success',
        message: 'Guest carregado do localStorage',
        guest_id: parseInt(existingGuestId, 10),
        device_id: existingDeviceId,
        was_created: false
      };
    }

    // 2. Se não tem guest, criar/recuperar via API usando device fingerprint
    console.log('[GuestService] 🔄 Criando/recuperando guest via API...');
    
    const deviceId = await getOrCreateDeviceId();
    
    // Chamar API para criar ou recuperar guest
    const formData = new FormData();
    formData.append('action', 'create_or_get');
    formData.append('device_fingerprint', deviceId);
    formData.append('user_agent', navigator.userAgent || '');
    
    const response = await fetch(`${API_BASE_URL}guest_auth.php`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      throw new Error('Resposta do servidor não é JSON válida');
    }

    const data = await response.json();

    if (data.success && data.data) {
      const guestData = data.data;
      const guestId = guestData.guest_id || guestData.user_id;
      
      // Salvar dados no localStorage
      if (guestId) {
        localStorage.setItem('guest_id', guestId.toString());
        localStorage.setItem('device_id', deviceId);
        localStorage.setItem('is_guest', 'true');
        
        if (guestData.guest_name) {
          localStorage.setItem('guest_name', guestData.guest_name);
        }
      }

      // Salvar pontos no localStorage para uso imediato
      const points = parseInt(guestData.user_score || guestData.points || 0);
      const level = parseInt(guestData.level || 1);
      const lifetimePoints = parseInt(guestData.lifetime_points || 0);
      
      console.log('[GuestService] 📊 Pontos do guest criado/recuperado:', { points, level, lifetimePoints });
      
      localStorage.setItem('pix_points', points.toString());
      localStorage.setItem('pix_profile', JSON.stringify({
        name: guestData.guest_name || 'Visitante',
        email: guestData.email || '',
        pixKey: guestData.chavepix || '',
        level: level,
        lifetimePoints: lifetimePoints
      }));
      
      console.log('[GuestService] 💾 Pontos salvos no localStorage:', points);
      
      return {
        status: 'success',
        message: guestData.is_existing ? 'Guest recuperado' : 'Guest criado',
        guest_id: guestId,
        device_id: deviceId,
        points: points,
        level: level,
        lifetime_points: lifetimePoints,
        was_created: !guestData.is_existing,
        guest_name: guestData.guest_name || 'Visitante',
        email: guestData.email || 'convidado@mobplaypix.com'
      };
    } else {
      throw new Error(data.message || 'Erro ao criar/recuperar guest');
    }

  } catch (error) {
    console.error('[GuestService] ❌ Erro ao criar/recuperar guest:', error);
    
    // Em caso de erro, tentar usar dados locais se existirem
    const fallbackGuestId = localStorage.getItem('guest_id');
    const fallbackDeviceId = localStorage.getItem('device_id');
    
    if (fallbackGuestId && fallbackDeviceId) {
      console.log('[GuestService] ⚠️ Usando dados locais como fallback');
      return {
        status: 'success',
        message: 'Guest carregado (offline)',
        guest_id: parseInt(fallbackGuestId, 10),
        device_id: fallbackDeviceId,
        was_created: false
      };
    }
    
    return {
      status: 'error',
      message: error instanceof Error ? error.message : 'Erro desconhecido ao criar guest'
    };
  }
};

/**
 * Inicializa guest (cria ou recupera automaticamente)
 * Esta é a função principal que deve ser chamada ao iniciar o app
 */
export const initializeGuest = async (): Promise<GuestResponse> => {
  // Verificar se Unity já forneceu dados
  const unityGuestId = localStorage.getItem('guest_id');
  const unityDeviceId = localStorage.getItem('device_id');
  const isUnityGuest = localStorage.getItem('is_guest') === 'true';
  
  if (unityGuestId && unityDeviceId && isUnityGuest) {
    console.log('[GuestService] ✅ Usando dados de guest fornecidos pelo Unity:', unityGuestId);
    
    try {
      const response = await fetch(`${API_BASE_URL}get_user_profile.php?guest_id=${unityGuestId}`);
      const profileData = await response.json();
      
      console.log('[GuestService] 📥 Resposta do backend (Unity):', JSON.stringify(profileData, null, 2));
      
      // A API retorna: { success: true, message: "...", data: { user: {...} } }
      const userData = profileData.data?.user || profileData.user;
      
      // Salvar pontos no localStorage
      const points = parseInt(userData?.points) || 0;
      const level = parseInt(userData?.level) || 1;
      const lifetimePoints = parseInt(userData?.lifetime_points) || 0;
      
      console.log('[GuestService] 📊 Pontos extraídos (Unity):', { points, level, lifetimePoints });
      
      localStorage.setItem('pix_points', points.toString());
      localStorage.setItem('pix_profile', JSON.stringify({
        name: userData?.display_name || userData?.name || '',
        email: userData?.email || '',
        pixKey: userData?.pix_key || '',
        level: level,
        lifetimePoints: lifetimePoints
      }));
      
      return {
        status: 'success',
        message: 'Guest carregado do Unity',
        guest_id: parseInt(unityGuestId, 10),
        device_id: unityDeviceId,
        points: points,
        level: level,
        lifetime_points: lifetimePoints,
        was_created: false
      };
    } catch (e) {
      return {
        status: 'success',
        message: 'Guest carregado do Unity (offline)',
        guest_id: parseInt(unityGuestId, 10),
        device_id: unityDeviceId,
        was_created: false
      };
    }
  }
  
  // Se não tem dados do Unity, criar/recuperar via API
  return await createOrGetGuest();
};

/**
 * Obtém guest_id atual
 */
export const getCurrentGuestId = (): number | null => {
  const guestId = localStorage.getItem('guest_id');
  return guestId ? parseInt(guestId, 10) : null;
};

/**
 * Verifica se é guest
 */
export const isGuest = (): boolean => {
  return localStorage.getItem('is_guest') === 'true';
};

