/**
 * Unity Bridge Service
 * Serviço para comunicação entre React e Unity via UniWebView
 */

/**
 * Detecta se está rodando dentro de Unity WebView
 */
export const isUnityEnvironment = (): boolean => {
  if (typeof window === 'undefined') return false;
  
  const ua = (navigator.userAgent || '').toLowerCase();
  const isWebView = ua.includes('wv') || ua.includes('uniwebview');
  const isNotRegularBrowser = !ua.includes('chrome') || ua.includes('wv');
  const isAndroidUnity = isWebView && isNotRegularBrowser;
  const isIOSUnity = !!window.webkit?.messageHandlers;
  
  return isAndroidUnity || isIOSUnity;
};

/**
 * Envia comando para Unity via custom URL scheme
 * @param path - Caminho do comando (ex: 'showAd', 'getCurrentPoints')
 * @param params - Parâmetros do comando
 * @returns true se enviado com sucesso
 */
export const sendToUnity = (path: string, params: Record<string, string> = {}): boolean => {
  if (!isUnityEnvironment()) {
    console.log('[UnityBridge] ⚠️ Unity não disponível - simulando envio');
    console.log('[UnityBridge] 📋 URL que seria enviada:', `uniwebview://${path}?${new URLSearchParams(params).toString()}`);
    return false;
  }

  try {
    const paramsStr = Object.keys(params)
      .map(key => `${key}=${encodeURIComponent(params[key])}`)
      .join('&');
    
    const url = `uniwebview://${path}${paramsStr ? '?' + paramsStr : ''}`;
    console.log('[UnityBridge] 📤 Enviando para Unity:', url);
    
    window.location.href = url;
    return true;
  } catch (error) {
    console.error('[UnityBridge] ❌ Erro ao enviar para Unity:', error);
    return false;
  }
};

/**
 * Solicita exibição de anúncio rewarded video
 * @param network - Rede de anúncios ('max' ou 'admob')
 * @returns true se comando foi enviado
 */
export const showRewardedVideo = (network: string = 'max'): boolean => {
  return sendToUnity('showAd', {
    type: 'rewarded',
    network: network.toLowerCase()
  });
};

/**
 * Solicita exibição de anúncio interstitial
 * @param network - Rede de anúncios ('max' ou 'admob')
 * @returns true se comando foi enviado
 */
export const showInterstitial = (network: string = 'max'): boolean => {
  return sendToUnity('showAd', {
    type: 'interstitial',
    network: network.toLowerCase()
  });
};

/**
 * Solicita pré-carregamento do próximo rewarded video
 * @returns true se comando foi enviado
 */
export const preloadNextRewardedVideo = (): boolean => {
  return sendToUnity('loadNextRewarded', {});
};

/**
 * Callback para eventos de anúncios do Unity
 * Deve ser registrado globalmente no window
 */
export type AdEventCallback = (eventType: string, adType: string) => void;

/**
 * Registra callback para eventos de anúncios
 * @param callback - Função que será chamada quando houver eventos de anúncio
 */
export const registerAdEventListener = (callback: AdEventCallback): void => {
  if (typeof window === 'undefined') return;
  
  // @ts-ignore
  window.onAdEvent = (eventType: string, adType: string) => {
    console.log('[UnityBridge] 📨 Evento de anúncio recebido:', eventType, adType);
    callback(eventType, adType);
  };
};

/**
 * Remove o listener de eventos de anúncios
 */
export const unregisterAdEventListener = (): void => {
  if (typeof window === 'undefined') return;
  // @ts-ignore
  delete window.onAdEvent;
};

/**
 * Tipos de eventos de anúncio
 */
export enum AdEventType {
  LOADED = 'adLoaded',
  SHOWN = 'adShown',
  REWARDED = 'adRewarded',
  FAILED = 'adFailed',
  CLOSED = 'adClosed',
  CANCELED = 'adCanceled'
}

