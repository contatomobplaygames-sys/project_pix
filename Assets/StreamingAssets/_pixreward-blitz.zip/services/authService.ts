/**
 * Authentication Service
 * Serviço para autenticação de usuários (login e registro)
 */

const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  display_name?: string;
  referral_code?: string;
}

export interface AuthResponse {
  status: 'success' | 'error';
  message: string;
  user?: {
    user_id: number;
    username: string;
    email: string;
    display_name: string;
    points: number;
    balance: number;
    level: number;
    referral_code: string | null;
  };
  token?: string;
  user_type?: 'regular' | 'guest';
}

export interface AuthError {
  status: 'error';
  message: string;
}

/**
 * Realiza login do usuário
 */
export const login = async (credentials: LoginRequest): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}login.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials),
    });

    const data: AuthResponse = await response.json();

    if (data.status === 'success' && data.user && data.token) {
      // Salvar token e dados do usuário no localStorage
      localStorage.setItem('auth_token', data.token);
      localStorage.setItem('user_id', data.user.user_id.toString());
      localStorage.setItem('username', data.user.username);
      localStorage.setItem('user_email', data.user.email);
      localStorage.setItem('user_type', 'regular');

      console.log('[AuthService] ✅ Login realizado com sucesso');
      return data;
    } else {
      throw new Error(data.message || 'Erro ao fazer login');
    }
  } catch (error) {
    console.error('[AuthService] ❌ Erro no login:', error);
    throw error;
  }
};

/**
 * Registra novo usuário
 */
export const register = async (userData: RegisterRequest): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}register.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData),
    });

    const data: AuthResponse = await response.json();

    if (data.status === 'success' && data.user && data.token) {
      // Salvar token e dados do usuário no localStorage
      localStorage.setItem('auth_token', data.token);
      localStorage.setItem('user_id', data.user.user_id.toString());
      localStorage.setItem('username', data.user.username);
      localStorage.setItem('user_email', data.user.email);
      localStorage.setItem('user_type', 'regular');

      console.log('[AuthService] ✅ Registro realizado com sucesso');
      return data;
    } else {
      throw new Error(data.message || 'Erro ao registrar');
    }
  } catch (error) {
    console.error('[AuthService] ❌ Erro no registro:', error);
    throw error;
  }
};

/**
 * Faz logout do usuário
 */
export const logout = (): void => {
  localStorage.removeItem('auth_token');
  localStorage.removeItem('user_id');
  localStorage.removeItem('username');
  localStorage.removeItem('user_email');
  localStorage.removeItem('user_type');
  
  console.log('[AuthService] 🔒 Logout realizado');
};

/**
 * Verifica se o usuário está autenticado
 */
export const isAuthenticated = (): boolean => {
  const token = localStorage.getItem('auth_token');
  const userId = localStorage.getItem('user_id');
  return !!(token && userId);
};

/**
 * Obtém dados do usuário autenticado
 */
export const getCurrentUser = (): {
  user_id: number | null;
  username: string | null;
  email: string | null;
  user_type: string | null;
} => {
  const userId = localStorage.getItem('user_id');
  const username = localStorage.getItem('username');
  const email = localStorage.getItem('user_email');
  const userType = localStorage.getItem('user_type');

  return {
    user_id: userId ? parseInt(userId, 10) : null,
    username,
    email,
    user_type: userType,
  };
};

/**
 * Obtém token de autenticação
 */
export const getAuthToken = (): string | null => {
  return localStorage.getItem('auth_token');
};


