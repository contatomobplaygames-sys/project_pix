<?php
/**
 * Update Mission Progress API
 * Atualiza o progresso de uma missão do guest
 */

require_once __DIR__ . '/config.php';

// Headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');

// Tratar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    // Ler dados do POST
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (!$data) {
        jsonResponse(false, 'Dados inválidos', [], 400);
    }
    
    $guestId = isset($data['guest_id']) ? (int)$data['guest_id'] : 0;
    $missionId = isset($data['mission_id']) ? sanitizeInput($data['mission_id']) : '';
    $currentClicks = isset($data['current_clicks']) ? (int)$data['current_clicks'] : 0;
    $lastClickTimestamp = isset($data['last_click_timestamp']) ? (int)$data['last_click_timestamp'] : null;
    $isLocked = isset($data['is_locked']) ? (int)$data['is_locked'] : 0;
    $isCompleted = isset($data['is_completed']) ? (bool)$data['is_completed'] : false;
    
    if (!$guestId || !$missionId) {
        jsonResponse(false, 'guest_id e mission_id são obrigatórios', [], 400);
    }
    
    $conn = getDBConnection();
    
    // Verificar se a missão existe, se não, criar
    $checkStmt = $conn->prepare("
        SELECT id FROM " . DB_PREFIX . "guest_missions 
        WHERE guest_id = ? AND mission_id = ?
    ");
    $checkStmt->execute([$guestId, $missionId]);
    $exists = $checkStmt->fetch();
    
    if (!$exists) {
        // Buscar dados padrão da missão
        $defaultMissions = [
            'mission_1' => ['Missão Iniciante', 10, 23, 60, 0],
            'mission_2' => ['Missão Rápida', 5, 8, 60, 1],
            'mission_3' => ['Missão Elite', 30, 28, 60, 1]
        ];
        
        $default = $defaultMissions[$missionId] ?? ['Missão', 10, 10, 60, 1];
        
        // Criar missão
        $insertStmt = $conn->prepare("
            INSERT INTO " . DB_PREFIX . "guest_missions 
            (guest_id, mission_id, title, required_clicks, reward, cooldown_seconds, is_locked, current_clicks, last_click_timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $insertStmt->execute([
            $guestId,
            $missionId,
            $default[0], // title
            $default[2], // required_clicks
            $default[3], // reward
            $default[4], // cooldown_seconds
            $isLocked,
            $currentClicks,
            $lastClickTimestamp
        ]);
    } else {
        // Atualizar missão existente
        $updateFields = [];
        $updateValues = [];
        
        $updateFields[] = "current_clicks = ?";
        $updateValues[] = $currentClicks;
        
        if ($lastClickTimestamp !== null) {
            $updateFields[] = "last_click_timestamp = ?";
            $updateValues[] = $lastClickTimestamp;
        }
        
        $updateFields[] = "is_locked = ?";
        $updateValues[] = $isLocked;
        
        // Se completou, incrementar completed_count
        if ($isCompleted) {
            $updateFields[] = "completed_count = completed_count + 1";
            $updateFields[] = "last_completed_at = NOW()";
            // Resetar cliques quando completa
            $updateFields[] = "current_clicks = 0";
            $updateValues[0] = 0; // Reset current_clicks
        }
        
        $updateValues[] = $guestId;
        $updateValues[] = $missionId;
        
        $updateStmt = $conn->prepare("
            UPDATE " . DB_PREFIX . "guest_missions 
            SET " . implode(', ', $updateFields) . "
            WHERE guest_id = ? AND mission_id = ?
        ");
        
        $updateStmt->execute($updateValues);
    }
    
    // Buscar missão atualizada
    $selectStmt = $conn->prepare("
        SELECT 
            mission_id,
            title,
            current_clicks,
            required_clicks,
            reward,
            cooldown_seconds,
            is_locked,
            last_click_timestamp,
            completed_count
        FROM " . DB_PREFIX . "guest_missions
        WHERE guest_id = ? AND mission_id = ?
    ");
    
    $selectStmt->execute([$guestId, $missionId]);
    $mission = $selectStmt->fetch();
    
    if (!$mission) {
        jsonResponse(false, 'Erro ao atualizar missão', [], 500);
    }
    
    // Formatar resposta
    $formattedMission = [
        'id' => $mission['mission_id'],
        'title' => $mission['title'],
        'requiredClicks' => (int)$mission['required_clicks'],
        'currentClicks' => (int)$mission['current_clicks'],
        'reward' => (int)$mission['reward'],
        'cooldownSeconds' => (int)$mission['cooldown_seconds'],
        'lastClickTimestamp' => $mission['last_click_timestamp'] ? (int)$mission['last_click_timestamp'] : null,
        'isLocked' => (bool)$mission['is_locked'],
        'completedCount' => (int)$mission['completed_count']
    ];
    
    jsonResponse(true, 'Progresso da missão atualizado', [
        'mission' => $formattedMission
    ]);
    
} catch (PDOException $e) {
    error_log("Erro em update_mission_progress.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao atualizar missão: ' . $e->getMessage(), [], 500);
} catch (Exception $e) {
    error_log("Erro em update_mission_progress.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao atualizar missão', [], 500);
}




