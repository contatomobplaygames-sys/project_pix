<?php
/**
 * Get Guest Missions API
 * Retorna todas as missões do guest com seu progresso atual
 */

require_once __DIR__ . '/config.php';

// Headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');

// Tratar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    // Validar parâmetros
    $guestId = isset($_GET['guest_id']) ? (int)$_GET['guest_id'] : 0;
    
    if (!$guestId) {
        jsonResponse(false, 'guest_id é obrigatório', [], 400);
    }
    
    $conn = getDBConnection();
    
    // Verificar se o guest existe
    $stmt = $conn->prepare("SELECT guest_id FROM " . DB_PREFIX . "guest_users WHERE guest_id = ?");
    $stmt->execute([$guestId]);
    if (!$stmt->fetch()) {
        jsonResponse(false, 'Guest não encontrado', [], 404);
    }
    
    // Buscar missões do guest
    $stmt = $conn->prepare("
        SELECT 
            mission_id,
            title,
            current_clicks,
            required_clicks,
            reward,
            cooldown_seconds,
            is_locked,
            last_click_timestamp,
            completed_count
        FROM " . DB_PREFIX . "guest_missions
        WHERE guest_id = ?
        ORDER BY 
            CASE mission_id
                WHEN 'mission_1' THEN 1
                WHEN 'mission_2' THEN 2
                WHEN 'mission_3' THEN 3
                ELSE 4
            END
    ");
    
    $stmt->execute([$guestId]);
    $missions = $stmt->fetchAll();
    
    // Se não houver missões, criar as padrão
    if (empty($missions)) {
        $defaultMissions = [
            ['mission_1', 'Missão Iniciante', 10, 23, 60, 0],
            ['mission_2', 'Missão Rápida', 5, 8, 60, 1],
            ['mission_3', 'Missão Elite', 30, 28, 60, 1]
        ];
        
        $insertStmt = $conn->prepare("
            INSERT INTO " . DB_PREFIX . "guest_missions 
            (guest_id, mission_id, title, required_clicks, reward, cooldown_seconds, is_locked, current_clicks)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0)
        ");
        
        foreach ($defaultMissions as $mission) {
            $insertStmt->execute([
                $guestId,
                $mission[0], // mission_id
                $mission[1], // title
                $mission[2], // required_clicks
                $mission[3], // reward
                $mission[4], // cooldown_seconds
                $mission[5]  // is_locked
            ]);
        }
        
        // Buscar novamente após inserir
        $stmt->execute([$guestId]);
        $missions = $stmt->fetchAll();
    }
    
    // Formatar resposta
    $formattedMissions = array_map(function($mission) {
        return [
            'id' => $mission['mission_id'],
            'title' => $mission['title'],
            'requiredClicks' => (int)$mission['required_clicks'],
            'currentClicks' => (int)$mission['current_clicks'],
            'reward' => (int)$mission['reward'],
            'cooldownSeconds' => (int)$mission['cooldown_seconds'],
            'lastClickTimestamp' => $mission['last_click_timestamp'] ? (int)$mission['last_click_timestamp'] : null,
            'isLocked' => (bool)$mission['is_locked'],
            'completedCount' => (int)$mission['completed_count']
        ];
    }, $missions);
    
    jsonResponse(true, 'Missões carregadas com sucesso', [
        'missions' => $formattedMissions
    ]);
    
} catch (PDOException $e) {
    error_log("Erro em get_guest_missions.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao buscar missões: ' . $e->getMessage(), [], 500);
} catch (Exception $e) {
    error_log("Erro em get_guest_missions.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao buscar missões', [], 500);
}




