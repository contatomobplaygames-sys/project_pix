<?php
/**
 * Script para Verificar Estrutura do Banco de Dados
 * Use este arquivo para verificar quais tabelas existem e qual prefixo usar
 */

require_once __DIR__ . '/config.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h1>Verificação do Banco de Dados</h1>";
echo "<h2>Banco: " . DB_NAME . "</h2>";

try {
    $conn = getDBConnection();
    echo "<p style='color: green;'>✅ Conexão estabelecida com sucesso!</p>";
    
    // Verificar todas as tabelas do banco
    echo "<h2>Tabelas Existentes no Banco:</h2>";
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (count($tables) > 0) {
        echo "<ul>";
        foreach ($tables as $table) {
            echo "<li><strong>$table</strong></li>";
        }
        echo "</ul>";
        
        // Verificar se tem tabelas mobpix_ ou pixreward_
        $mobpixTables = array_filter($tables, function($table) {
            return strpos($table, 'mobpix_') === 0;
        });
        
        $pixrewardTables = array_filter($tables, function($table) {
            return strpos($table, 'pixreward_') === 0;
        });
        
        echo "<h2>Análise:</h2>";
        
        if (count($mobpixTables) > 0) {
            echo "<p style='color: orange;'>⚠️ Encontradas " . count($mobpixTables) . " tabelas com prefixo <strong>mobpix_</strong></p>";
            echo "<p>Se você quer usar essas tabelas existentes, altere <code>DB_PREFIX</code> em <code>config.php</code> para <code>'mobpix_'</code></p>";
            echo "<ul>";
            foreach ($mobpixTables as $table) {
                echo "<li>$table</li>";
            }
            echo "</ul>";
        }
        
        if (count($pixrewardTables) > 0) {
            echo "<p style='color: green;'>✅ Encontradas " . count($pixrewardTables) . " tabelas com prefixo <strong>pixreward_</strong></p>";
            echo "<ul>";
            foreach ($pixrewardTables as $table) {
                echo "<li>$table</li>";
            }
            echo "</ul>";
        }
        
        if (count($mobpixTables) == 0 && count($pixrewardTables) == 0) {
            echo "<p style='color: red;'>❌ Nenhuma tabela com prefixo mobpix_ ou pixreward_ encontrada.</p>";
            echo "<p>Você precisa executar o arquivo SQL para criar as tabelas.</p>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ Nenhuma tabela encontrada no banco.</p>";
        echo "<p>Execute o arquivo <code>database/pixreward_blitz_schema.sql</code> para criar as tabelas.</p>";
    }
    
    // Verificar estrutura de tabelas importantes
    echo "<h2>Verificação de Estrutura:</h2>";
    
    $importantTables = [
        'guest_users' => ['guest_id', 'device_fingerprint', 'guest_public_id'],
        'guest_scores' => ['guest_id', 'points', 'lifetime_points', 'level'],
        'guest_transactions' => ['transaction_id', 'guest_id', 'type', 'amount'],
        'guest_withdrawals' => ['withdrawal_id', 'guest_id', 'level', 'points_used', 'amount'],
        'level_configs' => ['config_id', 'level', 'required_points', 'reward_value']
    ];
    
    foreach ($importantTables as $tableName => $requiredFields) {
        $fullTableName = DB_PREFIX . $tableName;
        $stmt = $conn->query("SHOW TABLES LIKE '$fullTableName'");
        
        if ($stmt->rowCount() > 0) {
            echo "<p style='color: green;'>✅ Tabela <strong>$fullTableName</strong> existe</p>";
            
            // Verificar campos
            $stmt = $conn->query("DESCRIBE `$fullTableName`");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $missingFields = array_diff($requiredFields, $columns);
            if (count($missingFields) > 0) {
                echo "<p style='color: orange;'>⚠️ Campos faltando: " . implode(', ', $missingFields) . "</p>";
            } else {
                echo "<p style='color: green;'>✅ Todos os campos necessários existem</p>";
            }
        } else {
            echo "<p style='color: red;'>❌ Tabela <strong>$fullTableName</strong> NÃO existe</p>";
        }
    }
    
    echo "<hr>";
    echo "<h2>Recomendação:</h2>";
    
    if (count($mobpixTables) > 0 && count($pixrewardTables) == 0) {
        echo "<p><strong>Opção 1:</strong> Usar tabelas existentes (mobpix_)</p>";
        echo "<p>Altere <code>DB_PREFIX</code> em <code>config.php</code> para <code>'mobpix_'</code></p>";
        echo "<p><strong>Opção 2:</strong> Criar novas tabelas (pixreward_)</p>";
        echo "<p>Execute o arquivo SQL: <code>database/pixreward_blitz_schema.sql</code></p>";
    } elseif (count($pixrewardTables) > 0) {
        echo "<p style='color: green;'>✅ Tabelas pixreward_ já existem. Tudo pronto!</p>";
    } else {
        echo "<p style='color: red;'>❌ Execute o arquivo SQL para criar as tabelas.</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>Erro:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Verifique as credenciais em <code>config.php</code></p>";
} catch (Exception $e) {
    echo "<p style='color: red;'><strong>Erro:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
}

