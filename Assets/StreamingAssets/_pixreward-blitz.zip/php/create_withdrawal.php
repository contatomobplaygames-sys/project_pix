<?php
/**
 * Create Withdrawal API
 * Cria um novo saque para um guest
 */

require_once __DIR__ . '/config.php';

// Headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Tratar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Apenas aceitar POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Método não permitido', [], 405);
}

try {
    $conn = getDBConnection();
    
    // Obter dados do JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        jsonResponse(false, 'Dados inválidos', [], 400);
    }
    
    $guestId = isset($input['guest_id']) ? (int)$input['guest_id'] : 0;
    $pixKey = sanitizeInput($input['pix_key'] ?? '');
    $pixKeyType = sanitizeInput($input['pix_key_type'] ?? 'RANDOM');
    $beneficiaryName = sanitizeInput($input['beneficiary_name'] ?? '');
    $email = isset($input['email']) ? sanitizeInput($input['email']) : null;
    
    // Validações
    if ($guestId <= 0) {
        jsonResponse(false, 'guest_id inválido', [], 400);
    }
    
    if (empty($pixKey)) {
        jsonResponse(false, 'Chave PIX não fornecida', [], 400);
    }
    
    if (empty($beneficiaryName)) {
        jsonResponse(false, 'Nome do beneficiário não fornecido', [], 400);
    }
    
    // Buscar pontos e nível atual do guest
    $scoreStmt = $conn->prepare("
        SELECT points, level
        FROM " . DB_PREFIX . "guest_scores
        WHERE guest_id = ?
    ");
    $scoreStmt->execute([$guestId]);
    $score = $scoreStmt->fetch();
    
    if (!$score) {
        jsonResponse(false, 'Guest não encontrado', [], 404);
    }
    
    $currentPoints = (int)$score['points'];
    $currentLevel = (int)$score['level'];
    
    // Buscar configuração do nível atual
    $levelStmt = $conn->prepare("
        SELECT required_points, reward_value
        FROM " . DB_PREFIX . "level_configs
        WHERE level = ? AND is_active = 1
        LIMIT 1
    ");
    $levelStmt->execute([$currentLevel]);
    $levelConfig = $levelStmt->fetch();
    
    if (!$levelConfig) {
        jsonResponse(false, 'Nível não encontrado ou inativo', [], 404);
    }
    
    $requiredPoints = (int)$levelConfig['required_points'];
    $rewardValue = (float)$levelConfig['reward_value'];
    
    // Verificar se tem pontos suficientes
    if ($currentPoints < $requiredPoints) {
        jsonResponse(false, 'Pontos insuficientes para o saque', [
            'current_points' => $currentPoints,
            'required_points' => $requiredPoints
        ], 400);
    }
    
    // Usar stored procedure para processar saque
    try {
        $procStmt = $conn->prepare("
            CALL sp_process_withdrawal(?, ?, ?, ?, ?, ?)
        ");
        
        $procStmt->execute([
            $guestId,
            $currentLevel,
            $pixKey,
            $pixKeyType,
            $beneficiaryName,
            $email
        ]);
        
        $withdrawal = $procStmt->fetch();
        
        // Atualizar dados do guest (nome, email, PIX) se fornecidos
        $updateStmt = $conn->prepare("
            UPDATE " . DB_PREFIX . "guest_users
            SET guest_name = COALESCE(?, guest_name),
                email = COALESCE(?, email),
                chavepix = COALESCE(?, chavepix),
                pix_key_type = COALESCE(?, pix_key_type)
            WHERE guest_id = ?
        ");
        $updateStmt->execute([
            $beneficiaryName ?: null,
            $email ?: null,
            $pixKey ?: null,
            $pixKeyType ?: null,
            $guestId
        ]);
        
        // Buscar novo nível após processamento
        $newScoreStmt = $conn->prepare("
            SELECT level, points
            FROM " . DB_PREFIX . "guest_scores
            WHERE guest_id = ?
        ");
        $newScoreStmt->execute([$guestId]);
        $newScore = $newScoreStmt->fetch();
        
        jsonResponse(true, 'Saque criado com sucesso', [
            'status' => 'success',
            'withdrawal_id' => (int)$withdrawal['withdrawal_id'],
            'request_id' => $withdrawal['request_id'],
            'level' => (int)$withdrawal['level'],
            'points_used' => (int)$withdrawal['points_used'],
            'amount' => (float)$withdrawal['amount'],
            'new_level' => (int)($newScore['level'] ?? $currentLevel + 1),
            'remaining_points' => (int)($newScore['points'] ?? 0)
        ]);
        
    } catch (PDOException $e) {
        // Se a procedure falhar, fazer manualmente
        error_log("Erro ao chamar procedure: " . $e->getMessage());
        
        // Processar saque manualmente
        $requestId = uniqid('WD-', true);
        $pointsAfter = $currentPoints - $requiredPoints;
        
        // Criar saque
        $withdrawalStmt = $conn->prepare("
            INSERT INTO " . DB_PREFIX . "guest_withdrawals
            (guest_id, request_id, level, points_used, points_before, points_after, 
             amount, pix_key, pix_key_type, beneficiary_name, email, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING')
        ");
        $withdrawalStmt->execute([
            $guestId,
            $requestId,
            $currentLevel,
            $requiredPoints,
            $currentPoints,
            $pointsAfter,
            $rewardValue,
            $pixKey,
            $pixKeyType,
            $beneficiaryName,
            $email
        ]);
        
        // Subtrair pontos e incrementar nível
        $updateScoreStmt = $conn->prepare("
            UPDATE " . DB_PREFIX . "guest_scores
            SET points = points - ?,
                level = level + 1
            WHERE guest_id = ?
        ");
        $updateScoreStmt->execute([$requiredPoints, $guestId]);
        
        // Registrar transação
        $transStmt = $conn->prepare("
            INSERT INTO " . DB_PREFIX . "guest_transactions
            (guest_id, type, amount, points_before, points_after, description, source, status)
            VALUES (?, 'WITHDRAW', ?, ?, ?, ?, 'withdrawal', 'COMPLETED')
        ");
        $transStmt->execute([
            $guestId,
            -$requiredPoints,
            $currentPoints,
            $pointsAfter,
            "Saque Nível {$currentLevel} (R$ " . number_format($rewardValue, 2, ',', '.') . ")"
        ]);
        
        // Registrar nível completado
        $levelStmt = $conn->prepare("
            INSERT INTO " . DB_PREFIX . "guest_levels
            (guest_id, level, points_at_completion, reward_value)
            VALUES (?, ?, ?, ?)
        ");
        $levelStmt->execute([$guestId, $currentLevel, $currentPoints, $rewardValue]);
        
        jsonResponse(true, 'Saque criado com sucesso', [
            'status' => 'success',
            'request_id' => $requestId,
            'level' => $currentLevel,
            'points_used' => $requiredPoints,
            'amount' => $rewardValue,
            'new_level' => $currentLevel + 1,
            'remaining_points' => $pointsAfter
        ]);
    }
    
} catch (PDOException $e) {
    error_log("Erro em create_withdrawal.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao criar saque: ' . $e->getMessage(), [], 500);
} catch (Exception $e) {
    error_log("Erro em create_withdrawal.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao criar saque', [], 500);
}

