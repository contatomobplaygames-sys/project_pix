<?php
/**
 * Get User Profile API
 * Retorna o perfil completo de um guest
 */

require_once __DIR__ . '/config.php';

// Headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');
header('Access-Control-Max-Age: 3600');

// Tratar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $conn = getDBConnection();
    
    // Obter guest_id da query string
    $guestId = isset($_GET['guest_id']) ? (int)$_GET['guest_id'] : 0;
    
    if ($guestId <= 0) {
        jsonResponse(false, 'guest_id inválido', [], 400);
    }
    
    // Buscar dados do guest
    $stmt = $conn->prepare("
        SELECT 
            g.guest_id,
            g.guest_public_id,
            g.guest_name,
            g.email,
            g.chavepix,
            g.pix_key_type,
            g.status,
            g.created_at,
            g.last_access,
            s.points,
            s.lifetime_points,
            s.level
        FROM " . DB_PREFIX . "guest_users g
        LEFT JOIN " . DB_PREFIX . "guest_scores s ON g.guest_id = s.guest_id
        WHERE g.guest_id = ? AND g.status = 'active'
        LIMIT 1
    ");
    
    $stmt->execute([$guestId]);
    $user = $stmt->fetch();
    
    if (!$user) {
        jsonResponse(false, 'Guest não encontrado', [], 404);
    }
    
    // Retornar perfil formatado
    jsonResponse(true, 'Perfil carregado com sucesso', [
        'user' => [
            'guest_id' => (int)$user['guest_id'],
            'guest_public_id' => $user['guest_public_id'],
            'display_name' => $user['guest_name'],
            'name' => $user['guest_name'],
            'email' => $user['email'],
            'pix_key' => $user['chavepix'],
            'pix_key_type' => $user['pix_key_type'],
            'points' => (int)($user['points'] ?? 0),
            'lifetime_points' => (int)($user['lifetime_points'] ?? 0),
            'level' => (int)($user['level'] ?? 1),
            'status' => $user['status'],
            'created_at' => $user['created_at'],
            'last_access' => $user['last_access']
        ]
    ]);
    
} catch (PDOException $e) {
    error_log("Erro em get_user_profile.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao buscar perfil: ' . $e->getMessage(), [], 500);
} catch (Exception $e) {
    error_log("Erro em get_user_profile.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao buscar perfil', [], 500);
}

