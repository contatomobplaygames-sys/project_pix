<?php
/**
 * Add Super Bonus Points Endpoint
 * Endpoint simples para adicionar pontos do Super Bônus
 * 
 * @version 1.0
 * @date 2025-01-27
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/config.php';

// Incluir Database.php (verificar se existe)
if (file_exists(__DIR__ . '/Database.php')) {
    require_once __DIR__ . '/Database.php';
} else {
    // Se Database.php não existe, criar classe inline
    if (!class_exists('Database')) {
        class Database {
            private static $instance = null;
            private $connection = null;

            private function __construct() {
                try {
                    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
                    $options = [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                    ];
                    $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
                } catch (PDOException $e) {
                    error_log("Database connection failed: " . $e->getMessage());
                    throw new Exception("Database connection failed");
                }
            }

            public static function getInstance() {
                if (self::$instance === null) {
                    self::$instance = new self();
                }
                return self::$instance;
            }

            public function getConnection() {
                return $this->connection;
            }

            private function __clone() {}
            public function __wakeup() {
                throw new Exception("Cannot unserialize singleton");
            }
        }
    }
}

// Função de resposta JSON compatível com React
// Usar nome único para evitar conflito com jsonResponse do config.php
if (!function_exists('jsonResponseSuperBonus')) {
    function jsonResponseSuperBonus($status, $message, $data = [], $httpCode = 200) {
        http_response_code($httpCode);
        header('Content-Type: application/json; charset=utf-8');
        
        $response = [
            'status' => $status,
            'message' => $message,
            ...$data
        ];
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

try {
    // Verificar método HTTP
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponseSuperBonus('error', 'Method not allowed. Use POST.', [], 405);
    }
    
    // Obter dados JSON
    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true);
    
    if (!$input) {
        jsonResponseSuperBonus('error', 'Invalid JSON input', [], 400);
    }
    
    // Validar dados obrigatórios
    $guestId = isset($input['guest_id']) ? intval($input['guest_id']) : 0;
    $points = isset($input['points']) ? intval($input['points']) : 1; // Default 1 ponto
    
    if ($guestId <= 0) {
        jsonResponseSuperBonus('error', 'Invalid guest_id. Must be greater than 0.', [], 400);
    }
    
    if ($points <= 0) {
        jsonResponseSuperBonus('error', 'Invalid points amount. Must be greater than 0.', [], 400);
    }
    
    // Obter conexão do banco
    $db = Database::getInstance()->getConnection();
    
    // Iniciar transação
    $db->beginTransaction();
    
    try {
        // Verificar se guest existe e está ativo
        $stmt = $db->prepare("
            SELECT g.guest_id, g.status, 
                   COALESCE(s.points, 0) as points,
                   COALESCE(s.lifetime_points, 0) as lifetime_points
            FROM pixreward_guest_users g
            LEFT JOIN pixreward_guest_scores s ON g.guest_id = s.guest_id
            WHERE g.guest_id = :guest_id
        ");
        $stmt->execute([':guest_id' => $guestId]);
        $guest = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$guest) {
            throw new Exception("Guest not found: {$guestId}");
        }
        
        if ($guest['status'] !== 'active') {
            throw new Exception("Guest account is inactive");
        }
        
        $currentPoints = intval($guest['points']);
        $newTotal = $currentPoints + $points;
        $newLifetime = intval($guest['lifetime_points']) + $points;
        
        // Verificar se registro de scores existe
        $stmt = $db->prepare("SELECT row_id FROM pixreward_guest_scores WHERE guest_id = :guest_id");
        $stmt->execute([':guest_id' => $guestId]);
        $scoreExists = $stmt->fetch();
        
        if ($scoreExists) {
            // Atualizar registro existente
            $stmt = $db->prepare("
                UPDATE pixreward_guest_scores 
                SET points = :new_total,
                    lifetime_points = :new_lifetime,
                    updated_at = NOW()
                WHERE guest_id = :guest_id
            ");
            $stmt->execute([
                ':new_total' => $newTotal,
                ':new_lifetime' => $newLifetime,
                ':guest_id' => $guestId
            ]);
        } else {
            // Criar novo registro
            $stmt = $db->prepare("
                INSERT INTO pixreward_guest_scores 
                (guest_id, points, lifetime_points, level, updated_at)
                VALUES 
                (:guest_id, :new_total, :new_lifetime, 1, NOW())
            ");
            $stmt->execute([
                ':guest_id' => $guestId,
                ':new_total' => $newTotal,
                ':new_lifetime' => $newLifetime
            ]);
        }
        
        // Atualizar last_access na tabela de usuários
        $stmt = $db->prepare("
            UPDATE pixreward_guest_users 
            SET last_access = NOW()
            WHERE guest_id = :guest_id
        ");
        $stmt->execute([':guest_id' => $guestId]);
        
        // Criar registro de transação
        $description = isset($input['description']) ? trim($input['description']) : 'Super Bônus - Complete 3 popups e ganhe +1 ponto';
        $source = isset($input['source']) ? trim($input['source']) : 'react';
        
        $stmt = $db->prepare("
            INSERT INTO pixreward_guest_transactions 
            (guest_id, type, amount, points_before, points_after, description, source, status, created_at)
            VALUES 
            (:guest_id, 'EARN', :points, :points_before, :points_after, :description, :source, 'COMPLETED', NOW())
        ");
        
        $stmt->execute([
            ':guest_id' => $guestId,
            ':points' => $points,
            ':points_before' => $currentPoints,
            ':points_after' => $newTotal,
            ':description' => $description,
            ':source' => $source
        ]);
        
        $transactionId = $db->lastInsertId();
        
        // Commit transação
        $db->commit();
        
        // Preparar resposta
        jsonResponseSuperBonus('success', 'Points added successfully', [
            'transaction_id' => $transactionId,
            'points_added' => $points,
            'new_total' => $newTotal,
            'total_points' => $newTotal,
            'guest_id' => $guestId
        ], 200);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
    
} catch (PDOException $e) {
    jsonResponseSuperBonus('error', 'Database error: ' . $e->getMessage(), [], 500);
    
} catch (Exception $e) {
    jsonResponseSuperBonus('error', $e->getMessage(), [], 400);
}

