<?php
/**
 * Script para Criar Stored Procedures
 * Execute este arquivo uma vez para criar as procedures que estão faltando
 * 
 * INSTRUÇÕES:
 * 1. Acesse: http://seu-servidor/app_pix01/php/create_procedures.php
 * 2. Verifique se as procedures foram criadas
 * 3. Remova este arquivo após usar (por segurança)
 */

require_once __DIR__ . '/config.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h1>Criar Stored Procedures</h1>";

try {
    $conn = getDBConnection();
    echo "<p style='color: green;'>✅ Conexão estabelecida!</p>";
    
    // Ler arquivo SQL
    $sqlFile = __DIR__ . '/../database/create_procedures.sql';
    
    if (!file_exists($sqlFile)) {
        throw new Exception("Arquivo SQL não encontrado: $sqlFile");
    }
    
    $sql = file_get_contents($sqlFile);
    
    // Remover USE database (já estamos conectados)
    $sql = preg_replace('/USE\s+\w+;/i', '', $sql);
    
    // Dividir em comandos (separados por DELIMITER)
    // Como o SQL tem DELIMITER, precisamos executar manualmente
    
    echo "<h2>Executando criação das procedures...</h2>";
    
    // Remover procedures existentes
    try {
        $conn->exec("DROP PROCEDURE IF EXISTS `sp_add_points`");
        $conn->exec("DROP PROCEDURE IF EXISTS `sp_process_withdrawal`");
        echo "<p>✅ Procedures antigas removidas (se existiam)</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ Nenhuma procedure antiga para remover</p>";
    }
    
    // Criar sp_add_points
    echo "<h3>Criando sp_add_points...</h3>";
    $spAddPoints = "
    CREATE PROCEDURE `sp_add_points`(
      IN p_guest_id INT,
      IN p_points INT,
      IN p_description VARCHAR(255),
      IN p_source VARCHAR(50)
    )
    BEGIN
      DECLARE v_points_before INT DEFAULT 0;
      DECLARE v_lifetime_before INT DEFAULT 0;
      DECLARE v_points_after INT;
      DECLARE v_lifetime_after INT;
      DECLARE v_exists INT DEFAULT 0;
      
      SELECT COUNT(*) INTO v_exists
      FROM " . DB_PREFIX . "guest_scores
      WHERE guest_id = p_guest_id;
      
      IF v_exists > 0 THEN
        SELECT COALESCE(points, 0), COALESCE(lifetime_points, 0)
        INTO v_points_before, v_lifetime_before
        FROM " . DB_PREFIX . "guest_scores
        WHERE guest_id = p_guest_id;
      END IF;
      
      SET v_points_after = v_points_before + p_points;
      
      IF v_points_after < 0 THEN
        SET v_points_after = 0;
      END IF;
      
      IF p_points > 0 THEN
        SET v_lifetime_after = v_lifetime_before + p_points;
      ELSE
        SET v_lifetime_after = v_lifetime_before;
      END IF;
      
      INSERT INTO " . DB_PREFIX . "guest_scores (guest_id, points, lifetime_points, level)
      VALUES (p_guest_id, v_points_after, v_lifetime_after, 1)
      ON DUPLICATE KEY UPDATE
        points = v_points_after,
        lifetime_points = v_lifetime_after;
      
      INSERT INTO " . DB_PREFIX . "guest_transactions (
        guest_id, type, amount, points_before, points_after, description, source, status
      ) VALUES (
        p_guest_id,
        IF(p_points > 0, 'EARN', IF(p_points < 0, 'PENALTY', 'BONUS')),
        p_points,
        v_points_before,
        v_points_after,
        p_description,
        p_source,
        'COMPLETED'
      );
      
      SELECT 
        v_points_after as new_points,
        v_lifetime_after as new_lifetime_points,
        v_points_before as points_before;
    END";
    
    $conn->exec($spAddPoints);
    echo "<p style='color: green;'>✅ Procedure sp_add_points criada com sucesso!</p>";
    
    // Criar sp_process_withdrawal
    echo "<h3>Criando sp_process_withdrawal...</h3>";
    $spProcessWithdrawal = "
    CREATE PROCEDURE `sp_process_withdrawal`(
      IN p_guest_id INT,
      IN p_level INT,
      IN p_pix_key VARCHAR(255),
      IN p_pix_key_type VARCHAR(20),
      IN p_beneficiary_name VARCHAR(255),
      IN p_email VARCHAR(255)
    )
    BEGIN
      DECLARE v_points_used INT;
      DECLARE v_reward_value DECIMAL(10,2);
      DECLARE v_points_before INT;
      DECLARE v_points_after INT;
      DECLARE v_request_id VARCHAR(36);
      
      SELECT required_points, reward_value INTO v_points_used, v_reward_value
      FROM " . DB_PREFIX . "level_configs
      WHERE level = p_level AND is_active = 1;
      
      SELECT COALESCE(points, 0) INTO v_points_before
      FROM " . DB_PREFIX . "guest_scores
      WHERE guest_id = p_guest_id;
      
      IF v_points_before < v_points_used THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Pontos insuficientes para o saque';
      END IF;
      
      SET v_request_id = UUID();
      SET v_points_after = v_points_before - v_points_used;
      
      INSERT INTO " . DB_PREFIX . "guest_withdrawals (
        guest_id, request_id, level, points_used, points_before, points_after,
        amount, pix_key, pix_key_type, beneficiary_name, email, status
      ) VALUES (
        p_guest_id, v_request_id, p_level, v_points_used, v_points_before, v_points_after,
        v_reward_value, p_pix_key, p_pix_key_type, p_beneficiary_name, p_email, 'PENDING'
      );
      
      UPDATE " . DB_PREFIX . "guest_scores
      SET points = v_points_after, level = level + 1
      WHERE guest_id = p_guest_id;
      
      INSERT INTO " . DB_PREFIX . "guest_transactions (
        guest_id, type, amount, points_before, points_after, description, source, status
      ) VALUES (
        p_guest_id, 'WITHDRAW', -v_points_used, v_points_before, v_points_after,
        CONCAT('Saque Nível ', p_level, ' (R$ ', v_reward_value, ')'), 'withdrawal', 'COMPLETED'
      );
      
      INSERT INTO " . DB_PREFIX . "guest_levels (guest_id, level, points_at_completion, reward_value)
      VALUES (p_guest_id, p_level, v_points_before, v_reward_value);
      
      SELECT 
        withdrawal_id, request_id, level, points_used, amount, status
      FROM " . DB_PREFIX . "guest_withdrawals
      WHERE request_id = v_request_id;
    END";
    
    $conn->exec($spProcessWithdrawal);
    echo "<p style='color: green;'>✅ Procedure sp_process_withdrawal criada com sucesso!</p>";
    
    // Verificar se foram criadas
    echo "<h2>Verificação Final:</h2>";
    $stmt = $conn->query("SHOW PROCEDURE STATUS WHERE Db = '" . DB_NAME . "' AND Name IN ('sp_add_points', 'sp_process_withdrawal')");
    $procedures = $stmt->fetchAll();
    
    if (count($procedures) == 2) {
        echo "<p style='color: green; font-size: 18px;'><strong>✅ SUCESSO! Ambas as procedures foram criadas!</strong></p>";
        echo "<ul>";
        foreach ($procedures as $proc) {
            echo "<li><strong>{$proc['Name']}</strong> - Criada em: {$proc['Created']}</li>";
        }
        echo "</ul>";
        echo "<p><a href='test_connection.php'>← Voltar para teste de conexão</a></p>";
    } else {
        echo "<p style='color: orange;'>⚠️ Apenas " . count($procedures) . " procedure(s) encontrada(s). Verifique os erros acima.</p>";
    }
    
    echo "<hr>";
    echo "<p><strong>⚠️ IMPORTANTE:</strong> Remova este arquivo após usar por segurança!</p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ Erro:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><strong>Código:</strong> " . $e->getCode() . "</p>";
    echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
} catch (Exception $e) {
    echo "<p style='color: red;'><strong>❌ Erro:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
}

