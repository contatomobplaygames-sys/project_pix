<?php
/**
 * Script de Debug para Carregamento de Pontos
 * Use este arquivo para testar se a API está retornando pontos corretamente
 */

require_once __DIR__ . '/config.php';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Debug - Carregamento de Pontos</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        .success { color: #4CAF50; font-weight: bold; }
        .error { color: #f44336; font-weight: bold; }
        .info { color: #2196F3; }
        pre { background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        table th, table td { padding: 10px; text-align: left; border: 1px solid #ddd; }
        table th { background: #4CAF50; color: white; }
    </style>
</head>
<body>
<div class='container'>
<h1>🔍 Debug - Carregamento de Pontos</h1>";

try {
    $conn = getDBConnection();
    echo "<p class='success'>✅ Conexão estabelecida!</p>";
    
    // Obter guest_id da query string ou mostrar todos
    $testGuestId = isset($_GET['guest_id']) ? (int)$_GET['guest_id'] : null;
    
    if ($testGuestId) {
        echo "<h2>Testando Guest ID: $testGuestId</h2>";
        
        // Testar query exata que a API usa
        $stmt = $conn->prepare("
            SELECT 
                g.guest_id,
                g.guest_public_id,
                g.guest_name,
                g.email,
                g.chavepix,
                g.pix_key_type,
                g.status,
                g.created_at,
                g.last_access,
                s.points,
                s.lifetime_points,
                s.level
            FROM " . DB_PREFIX . "guest_users g
            LEFT JOIN " . DB_PREFIX . "guest_scores s ON g.guest_id = s.guest_id
            WHERE g.guest_id = ? AND g.status = 'active'
            LIMIT 1
        ");
        
        $stmt->execute([$testGuestId]);
        $user = $stmt->fetch();
        
        if ($user) {
            echo "<p class='success'>✅ Guest encontrado!</p>";
            echo "<table>";
            echo "<tr><th>Campo</th><th>Valor</th></tr>";
            foreach ($user as $key => $value) {
                echo "<tr><td><strong>$key</strong></td><td>" . htmlspecialchars($value ?? 'NULL') . "</td></tr>";
            }
            echo "</table>";
            
            // Simular resposta da API
            echo "<h3>Resposta que a API retornaria:</h3>";
            $apiResponse = [
                'success' => true,
                'message' => 'Perfil carregado com sucesso',
                'data' => [
                    'user' => [
                        'guest_id' => (int)$user['guest_id'],
                        'guest_public_id' => $user['guest_public_id'],
                        'display_name' => $user['guest_name'],
                        'name' => $user['guest_name'],
                        'email' => $user['email'],
                        'pix_key' => $user['chavepix'],
                        'pix_key_type' => $user['pix_key_type'],
                        'points' => (int)($user['points'] ?? 0),
                        'lifetime_points' => (int)($user['lifetime_points'] ?? 0),
                        'level' => (int)($user['level'] ?? 1),
                        'status' => $user['status'],
                        'created_at' => $user['created_at'],
                        'last_access' => $user['last_access']
                    ]
                ]
            ];
            
            echo "<pre>" . json_encode($apiResponse, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
            
            // Testar URL da API
            $apiUrl = "https://serveapp.mobplaygames.com.br/app_pix01/php/get_user_profile.php?guest_id=$testGuestId";
            echo "<h3>Testar URL da API:</h3>";
            echo "<p><a href='$apiUrl' target='_blank'>$apiUrl</a></p>";
            
        } else {
            echo "<p class='error'>❌ Guest não encontrado ou inativo!</p>";
        }
    } else {
        // Mostrar todos os guests
        echo "<h2>Lista de Guests no Banco</h2>";
        
        $stmt = $conn->query("
            SELECT 
                g.guest_id,
                g.guest_public_id,
                g.guest_name,
                g.status,
                s.points,
                s.level,
                s.lifetime_points,
                g.created_at
            FROM " . DB_PREFIX . "guest_users g
            LEFT JOIN " . DB_PREFIX . "guest_scores s ON g.guest_id = s.guest_id
            ORDER BY g.created_at DESC
            LIMIT 20
        ");
        
        $guests = $stmt->fetchAll();
        
        if (count($guests) > 0) {
            echo "<p class='info'>ℹ️ Encontrados " . count($guests) . " guests. Clique em um ID para testar:</p>";
            echo "<table>";
            echo "<tr><th>Guest ID</th><th>Public ID</th><th>Nome</th><th>Pontos</th><th>Nível</th><th>Status</th><th>Ação</th></tr>";
            foreach ($guests as $guest) {
                $guestId = $guest['guest_id'];
                echo "<tr>";
                echo "<td><strong>$guestId</strong></td>";
                echo "<td>{$guest['guest_public_id']}</td>";
                echo "<td>{$guest['guest_name']}</td>";
                echo "<td><strong style='color: #4CAF50;'>{$guest['points']}</strong></td>";
                echo "<td>{$guest['level']}</td>";
                echo "<td>{$guest['status']}</td>";
                echo "<td><a href='?guest_id=$guestId'>🔍 Testar</a></td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='error'>❌ Nenhum guest encontrado no banco!</p>";
        }
    }
    
    // Verificar se há guests sem registro de pontos
    echo "<h2>Verificação de Integridade</h2>";
    $stmt = $conn->query("
        SELECT g.guest_id, g.guest_public_id
        FROM " . DB_PREFIX . "guest_users g
        LEFT JOIN " . DB_PREFIX . "guest_scores s ON g.guest_id = s.guest_id
        WHERE s.guest_id IS NULL AND g.status = 'active'
    ");
    $orphans = $stmt->fetchAll();
    
    if (count($orphans) > 0) {
        echo "<p class='error'>⚠️ Encontrados " . count($orphans) . " guests sem registro de pontos:</p>";
        echo "<ul>";
        foreach ($orphans as $orphan) {
            echo "<li>Guest ID: {$orphan['guest_id']} - {$orphan['guest_public_id']}</li>";
        }
        echo "</ul>";
        echo "<p>Execute este SQL para corrigir:</p>";
        echo "<pre>INSERT INTO " . DB_PREFIX . "guest_scores (guest_id, points, lifetime_points, level) VALUES (guest_id, 0, 0, 1);</pre>";
    } else {
        echo "<p class='success'>✅ Todos os guests têm registro de pontos!</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Erro: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "</div></body></html>";

