<?php
/**
 * Unified Score Submission Endpoint
 * Endpoint unificado para envio de pontos de usuários regulares e guests
 * Suporta recuperação de guests usando device_id
 * 
 * @version 2.1
 * @date 2025-01-27
 */

// Headers CORS
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Incluir configuração do banco de dados
require_once __DIR__ . '/config.php';

// Incluir Database.php (verificar se existe)
if (file_exists(__DIR__ . '/Database.php')) {
require_once __DIR__ . '/Database.php';
} else {
    // Se Database.php não existe, criar classe inline
    if (!class_exists('Database')) {
        class Database {
            private static $instance = null;
            private $connection = null;

            private function __construct() {
                try {
                    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
                    $options = [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                    ];
                    $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
                } catch (PDOException $e) {
                    error_log("Database connection failed: " . $e->getMessage());
                    throw new Exception("Database connection failed");
                }
            }

            public static function getInstance() {
                if (self::$instance === null) {
                    self::$instance = new self();
                }
                return self::$instance;
            }

            public function getConnection() {
                return $this->connection;
            }

            private function __clone() {}
            public function __wakeup() {
                throw new Exception("Cannot unserialize singleton");
            }
        }
    }
}

// Timezone
date_default_timezone_set('America/Sao_Paulo');

// Configuração de logs
$enableRequestLog = true;
$logFile = __DIR__ . '/logs/score_submissions.log';

/**
 * Função de log
 * Verifica se função já existe antes de declarar
 */
if (!function_exists('logRequest')) {
function logRequest($message, $data = null) {
    global $logFile, $enableRequestLog;
    if (!$enableRequestLog) return;
    
    $logDir = dirname($logFile);
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[{$timestamp}] {$message}";
    if ($data !== null) {
        $logMessage .= " | Data: " . json_encode($data, JSON_UNESCAPED_UNICODE);
    }
    $logMessage .= "\n";
    
    @file_put_contents($logFile, $logMessage, FILE_APPEND);
    }
}

/**
 * Resposta JSON padronizada
 * NOTA: Se config.php já define jsonResponse(), não redeclarar
 * A função jsonResponse() deve estar definida no config.php
 */
if (!function_exists('jsonResponse')) {
    // Fallback: definir apenas se não existir (não deve acontecer se config.php está correto)
function jsonResponse($status, $message, $data = [], $httpCode = 200) {
    http_response_code($httpCode);
    echo json_encode([
        'status' => $status,
        'message' => $message,
        ...$data
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
    }
}

try {
    // Verificar método HTTP
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse('error', 'Method not allowed. Use POST.', [], 405);
    }
    
    // Obter dados JSON
    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true);
    
    if (!$input) {
        logRequest('Invalid JSON input', ['raw' => substr($rawInput, 0, 500)]);
        jsonResponse('error', 'Invalid JSON input', [], 400);
    }
    
    logRequest('Score submission request', $input);
    
    // Validar dados obrigatórios
    $points = isset($input['points']) ? intval($input['points']) : 0;
    $type = isset($input['type']) ? trim($input['type']) : '';
    $source = isset($input['source']) ? trim($input['source']) : '';
    
    if ($points <= 0) {
        logRequest('Invalid points', ['points' => $points]);
        jsonResponse('error', 'Invalid points amount. Must be greater than 0.', [], 400);
    }
    
    if (empty($type)) {
        logRequest('Missing type', $input);
        jsonResponse('error', 'Type is required', [], 400);
    }
    
    if (empty($source)) {
        logRequest('Missing source', $input);
        jsonResponse('error', 'Source is required', [], 400);
    }
    
    // Obter dados do usuário
    $userId = isset($input['user_id']) && $input['user_id'] > 0 ? intval($input['user_id']) : null;
    $guestId = isset($input['guest_id']) && $input['guest_id'] > 0 ? intval($input['guest_id']) : null;
    $deviceId = isset($input['device_id']) ? trim($input['device_id']) : null;
    $email = isset($input['email']) ? trim($input['email']) : null;
    
    logRequest('User identification', [
        'user_id' => $userId,
        'guest_id' => $guestId,
        'device_id' => $deviceId ? substr($deviceId, 0, 20) . '...' : null,
        'has_email' => !empty($email)
    ]);
    
    // Validar device_id se fornecido
    if ($deviceId !== null && strlen($deviceId) < 10) {
        logRequest('Invalid device_id length', ['device_id' => $deviceId, 'length' => strlen($deviceId)]);
        jsonResponse('error', 'Invalid device_id. Must be at least 10 characters.', [], 400);
    }
    
    // Obter conexão do banco
    $db = Database::getInstance()->getConnection();
    
    // Iniciar transação
    $db->beginTransaction();
    
    try {
        $isGuest = false;
        $accountId = null;
        $wasCreated = false;
        $currentPoints = 0;
        $newTotal = 0;
        
        // CASO 1: Usuário Regular
        if ($userId && $userId > 0) {
            logRequest("Processing regular user", ['user_id' => $userId]);
            
            // Verificar se usuário existe e está ativo
            $stmt = $db->prepare("
                SELECT user_id, points, is_active 
                FROM users 
                WHERE user_id = :user_id
            ");
            $stmt->execute([':user_id' => $userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                throw new Exception("User not found: {$userId}");
            }
            
            if (!$user['is_active']) {
                throw new Exception("User account is inactive");
            }
            
            $accountId = $userId;
            $currentPoints = intval($user['points']);
            $isGuest = false;
            
            // Atualizar pontos do usuário
            $newTotal = $currentPoints + $points;
            $stmt = $db->prepare("
                UPDATE users 
                SET points = :new_total,
                    lifetime_points = lifetime_points + :points,
                    updated_at = NOW(),
                    last_login = NOW()
                WHERE user_id = :user_id
            ");
            $stmt->execute([
                ':new_total' => $newTotal,
                ':points' => $points,
                ':user_id' => $userId
            ]);
            
            logRequest("Regular user points updated", [
                'user_id' => $userId,
                'points_added' => $points,
                'old_total' => $currentPoints,
                'new_total' => $newTotal
            ]);
        }
        // CASO 2: Guest Existente
        else if ($guestId && $guestId > 0) {
            logRequest("Processing existing guest", ['guest_id' => $guestId]);
            
            // Verificar se guest existe e está ativo (usando estrutura pixreward_)
            $stmt = $db->prepare("
                SELECT g.guest_id, g.status, 
                       COALESCE(s.points, 0) as points,
                       COALESCE(s.lifetime_points, 0) as lifetime_points
                FROM pixreward_guest_users g
                LEFT JOIN pixreward_guest_scores s ON g.guest_id = s.guest_id
                WHERE g.guest_id = :guest_id
            ");
            $stmt->execute([':guest_id' => $guestId]);
            $guest = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$guest) {
                logRequest("Guest not found", ['guest_id' => $guestId]);
                throw new Exception("Guest not found: {$guestId}");
            }
            
            if ($guest['status'] !== 'active') {
                logRequest("Guest inactive", ['guest_id' => $guestId, 'status' => $guest['status']]);
                throw new Exception("Guest account is inactive");
            }
            
            $accountId = $guestId;
            $currentPoints = intval($guest['points']);
            $isGuest = true;
            
            // Atualizar pontos do guest (usando pixreward_guest_scores)
            $newTotal = $currentPoints + $points;
            $newLifetime = intval($guest['lifetime_points']) + $points;
            
            // Verificar se registro de scores existe
            $stmt = $db->prepare("SELECT row_id FROM pixreward_guest_scores WHERE guest_id = :guest_id");
            $stmt->execute([':guest_id' => $guestId]);
            $scoreExists = $stmt->fetch();
            
            if ($scoreExists) {
                // Atualizar registro existente
            $stmt = $db->prepare("
                    UPDATE pixreward_guest_scores 
                SET points = :new_total,
                        lifetime_points = :new_lifetime,
                        updated_at = NOW()
                WHERE guest_id = :guest_id
            ");
            $stmt->execute([
                ':new_total' => $newTotal,
                    ':new_lifetime' => $newLifetime,
                ':guest_id' => $guestId
            ]);
            } else {
                // Criar novo registro
                $stmt = $db->prepare("
                    INSERT INTO pixreward_guest_scores 
                    (guest_id, points, lifetime_points, level, updated_at)
                    VALUES 
                    (:guest_id, :new_total, :new_lifetime, 1, NOW())
                ");
                $stmt->execute([
                    ':guest_id' => $guestId,
                    ':new_total' => $newTotal,
                    ':new_lifetime' => $newLifetime
                ]);
            }
            
            // Atualizar last_access na tabela de usuários
            $stmt = $db->prepare("
                UPDATE pixreward_guest_users 
                SET last_access = NOW()
                WHERE guest_id = :guest_id
            ");
            $stmt->execute([':guest_id' => $guestId]);
            
            logRequest("Guest points updated", [
                'guest_id' => $guestId,
                'points_added' => $points,
                'old_total' => $currentPoints,
                'new_total' => $newTotal
            ]);
        }
        // CASO 3: Recuperar Guest existente usando device_fingerprint (NÃO CRIAR NOVO)
        else if ($deviceId && strlen($deviceId) >= 10) {
            logRequest("Retrieving guest by device_fingerprint", ['device_id' => substr($deviceId, 0, 20) . '...']);
            
            // Verificar se já existe guest com este device_fingerprint (estrutura pixreward_)
            $stmt = $db->prepare("
                SELECT g.guest_id, g.status,
                       COALESCE(s.points, 0) as points,
                       COALESCE(s.lifetime_points, 0) as lifetime_points
                FROM pixreward_guest_users g
                LEFT JOIN pixreward_guest_scores s ON g.guest_id = s.guest_id
                WHERE g.device_fingerprint = :device_id AND g.status = 'active'
                ORDER BY g.created_at DESC
                LIMIT 1
            ");
            $stmt->execute([':device_id' => $deviceId]);
            $existingGuest = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existingGuest) {
                $guestId = intval($existingGuest['guest_id']);
                $currentPoints = intval($existingGuest['points']);
                $accountId = $guestId;
                $isGuest = true;
                
                // Atualizar pontos (usando pixreward_guest_scores)
                $newTotal = $currentPoints + $points;
                $newLifetime = intval($existingGuest['lifetime_points']) + $points;
                
                // Verificar se registro de scores existe
                $stmt = $db->prepare("SELECT row_id FROM pixreward_guest_scores WHERE guest_id = :guest_id");
                $stmt->execute([':guest_id' => $guestId]);
                $scoreExists = $stmt->fetch();
                
                if ($scoreExists) {
                    // Atualizar registro existente
                $stmt = $db->prepare("
                        UPDATE pixreward_guest_scores 
                    SET points = :new_total,
                            lifetime_points = :new_lifetime,
                            updated_at = NOW()
                    WHERE guest_id = :guest_id
                ");
                $stmt->execute([
                    ':new_total' => $newTotal,
                        ':new_lifetime' => $newLifetime,
                    ':guest_id' => $guestId
                ]);
                } else {
                    // Criar novo registro
                    $stmt = $db->prepare("
                        INSERT INTO pixreward_guest_scores 
                        (guest_id, points, lifetime_points, level, updated_at)
                        VALUES 
                        (:guest_id, :new_total, :new_lifetime, 1, NOW())
                    ");
                    $stmt->execute([
                        ':guest_id' => $guestId,
                        ':new_total' => $newTotal,
                        ':new_lifetime' => $newLifetime
                    ]);
                }
                
                // Atualizar last_access
                $stmt = $db->prepare("
                    UPDATE pixreward_guest_users 
                    SET last_access = NOW()
                    WHERE guest_id = :guest_id
                ");
                $stmt->execute([':guest_id' => $guestId]);
                
                logRequest("Existing guest found and points updated", [
                    'guest_id' => $guestId,
                    'new_total' => $newTotal
                ]);
            } else {
                // ERRO CRÍTICO: Não criar conta durante envio de pontos
                logRequest("❌ Error: No guest found for device_fingerprint and auto-creation is disabled for scores", ['device_id' => $deviceId]);
                throw new Exception("No account found. Please open the app home screen first.");
            }
        }
        // CASO 4: Erro - nenhum identificador válido
        else {
            logRequest("No valid identifier", [
                'user_id' => $userId,
                'guest_id' => $guestId,
                'device_id' => $deviceId ? substr($deviceId, 0, 20) . '...' : null
            ]);
            throw new Exception("Must provide user_id, guest_id, or valid device_id (min 10 chars)");
        }
        
        // Criar registro de transação (usando pixreward_guest_transactions)
        $description = isset($input['description']) ? trim($input['description']) : "Pontos de {$source}";
            $adNetwork = isset($input['ad_network']) ? trim($input['ad_network']) : null;
        
        if ($isGuest) {
            // Transação para guest (usando estrutura pixreward_guest_transactions)
            $stmt = $db->prepare("
                INSERT INTO pixreward_guest_transactions 
                (guest_id, type, amount, points_before, points_after, description, source, status, created_at)
                VALUES 
                (:guest_id, 'EARN', :points, :points_before, :points_after, :description, :source, 'COMPLETED', NOW())
            ");
            
            $stmt->execute([
                ':guest_id' => $accountId,
                ':points' => $points,
                ':points_before' => $currentPoints,
                ':points_after' => $newTotal,
                ':description' => $description,
                ':source' => $source
            ]);
        } else {
            // Para usuários regulares, verificar se existe tabela transactions ou criar em pixreward_guest_transactions
            // Por enquanto, vamos usar uma abordagem que funciona para ambos
            try {
                // Tentar inserir em transactions (se existir)
            $stmt = $db->prepare("
                INSERT INTO transactions 
                    (user_id, transaction_type, points_amount, source, description, status, created_at)
                VALUES 
                    (:user_id, 'EARN', :points, :source, :description, 'COMPLETED', NOW())
            ");
            $stmt->execute([
                    ':user_id' => $accountId,
                ':points' => $points,
                ':source' => $source,
                ':description' => $description
            ]);
            } catch (Exception $e) {
                // Se tabela transactions não existir, apenas logar (não é crítico)
                logRequest("⚠️ Tabela transactions não encontrada para usuário regular, pulando registro", ['user_id' => $accountId]);
            }
        }
        
        $transactionId = $db->lastInsertId();
        
        logRequest("Transaction created", [
            'transaction_id' => $transactionId,
            'user_id' => $isGuest ? null : $accountId,
            'guest_id' => $isGuest ? $accountId : null,
            'points' => $points,
            'table' => $isGuest ? 'pixreward_guest_transactions' : 'transactions'
        ]);
        
        // Commit transação
        $db->commit();
        
        // Preparar resposta
        $responseData = [
            'transaction_id' => $transactionId,
            'points_added' => $points,
            'new_total' => $newTotal,
            'total_points' => $newTotal,
            'user_type' => $isGuest ? 'guest' : 'regular'
        ];
        
        if ($isGuest) {
            $responseData['guest_id'] = $guestId;
            if ($wasCreated && $deviceId) {
                $responseData['device_id'] = $deviceId;
                $responseData['message'] = 'Guest created automatically';
            }
        } else {
            $responseData['user_id'] = $userId;
        }
        
        logRequest("✅ Score submitted successfully", $responseData);
        
        jsonResponse('success', 'Points submitted successfully', $responseData, 200);
        
    } catch (Exception $e) {
        $db->rollBack();
        logRequest("❌ Error processing score submission", [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
} catch (PDOException $e) {
    logRequest("❌ Database error", [
        'error' => $e->getMessage(),
        'code' => $e->getCode()
    ]);
    jsonResponse('error', 'Database error: ' . $e->getMessage(), [], 500);
    
} catch (Exception $e) {
    logRequest("❌ General error", [
        'error' => $e->getMessage()
    ]);
    jsonResponse('error', $e->getMessage(), [], 400);
}
