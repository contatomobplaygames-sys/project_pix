<?php
/**
 * Get Withdrawals API
 * Retorna o histórico de saques de um guest
 */

require_once __DIR__ . '/config.php';

// Headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');
header('Access-Control-Max-Age: 3600');

// Tratar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $conn = getDBConnection();
    
    // Obter guest_id da query string
    $guestId = isset($_GET['guest_id']) ? (int)$_GET['guest_id'] : 0;
    
    if ($guestId <= 0) {
        jsonResponse(false, 'guest_id inválido', [], 400);
    }
    
    // Buscar saques do guest ordenados por data de criação (mais recentes primeiro)
    $stmt = $conn->prepare("
        SELECT 
            withdrawal_id,
            request_id,
            level,
            points_used,
            points_before,
            points_after,
            amount,
            pix_key,
            pix_key_type,
            beneficiary_name,
            email,
            status,
            processed_at,
            rejection_reason,
            created_at,
            updated_at
        FROM " . DB_PREFIX . "guest_withdrawals
        WHERE guest_id = ?
        ORDER BY created_at DESC
    ");
    
    $stmt->execute([$guestId]);
    $withdrawals = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatar saques para o formato esperado pelo frontend
    $formattedWithdrawals = array_map(function($w) {
        // Determinar o status para o frontend
        $status = 'PENDING';
        if ($w['status'] === 'COMPLETED') {
            $status = 'COMPLETED';
        } else if ($w['status'] === 'APPROVED') {
            $status = 'COMPLETED'; // APPROVED também é considerado completo
        } else if (in_array($w['status'], ['REJECTED', 'FAILED'])) {
            $status = 'PENDING'; // Manter como PENDING para não confundir
        } else {
            $status = 'PENDING';
        }
        
        // Formatar valor em reais
        $amountFormatted = 'R$ ' . number_format((float)$w['amount'], 2, ',', '.');
        
        // Criar detalhes do saque
        $details = "Saque Nível {$w['level']} ({$amountFormatted})";
        
        return [
            'id' => $w['request_id'],
            'type' => 'WITHDRAW',
            'amount' => (int)$w['points_used'],
            'date' => $w['created_at'],
            'details' => $details,
            'status' => $status,
            'raw_status' => $w['status'], // Status original do banco
            'amount_currency' => $amountFormatted,
            'pix_key' => $w['pix_key'],
            'pix_key_type' => $w['pix_key_type'],
            'beneficiary_name' => $w['beneficiary_name'],
            'processed_at' => $w['processed_at'],
            'rejection_reason' => $w['rejection_reason']
        ];
    }, $withdrawals);
    
    // Retornar saques formatados
    jsonResponse(true, 'Saques carregados com sucesso', [
        'withdrawals' => $formattedWithdrawals
    ]);
    
} catch (PDOException $e) {
    error_log("Erro em get_withdrawals.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao buscar saques: ' . $e->getMessage(), [], 500);
} catch (Exception $e) {
    error_log("Erro em get_withdrawals.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao buscar saques', [], 500);
}

