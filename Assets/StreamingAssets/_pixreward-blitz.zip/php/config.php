<?php
/**
 * Configuração de Conexão com Banco de Dados
 * PixReward Blitz
 * 
 * INSTRUÇÕES:
 * 1. Preencha as credenciais do seu banco de dados abaixo
 * 2. NUNCA commite este arquivo no Git se contiver credenciais reais
 */

// Configurações do Banco de Dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'xperia22_apppixreact');
define('DB_USER', 'xperia22_pixapprect');
define('DB_PASS', 'd15n02M03$%');
define('DB_CHARSET', 'utf8mb4');

// Configurações de Timezone
date_default_timezone_set('America/Sao_Paulo');

// Configurações de Segurança
// IMPORTANTE: Se o banco já tem tabelas com prefixo 'mobpix_', altere para 'mobpix_'
// Se for criar novas tabelas, use 'pixreward_'
define('DB_PREFIX', 'pixreward_');  // Prefixo das tabelas (altere se necessário)

// Função de Conexão PDO
function getDBConnection() {
    static $conn = null;
    
    if ($conn === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_PERSISTENT         => false,
            ];
            
            $conn = new PDO($dsn, DB_USER, DB_PASS, $options);
            
        } catch (PDOException $e) {
            error_log("Erro de conexão com banco de dados: " . $e->getMessage());
            throw new Exception("Erro ao conectar com o banco de dados");
        }
    }
    
    return $conn;
}

// Função para retornar resposta JSON padronizada
function jsonResponse($success, $message, $data = [], $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    
    $response = [
        'success' => $success,
        'message' => $message,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// Função para validar entrada
function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

// Função para gerar guest_public_id único
function generateGuestPublicId() {
    return 'GUEST-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8)) . '-' . strtoupper(substr(md5(time()), 0, 4));
}

