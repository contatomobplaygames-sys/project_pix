<?php
/**
 * Get Level Configs API
 * Retorna todas as configurações de níveis ativas
 */

require_once __DIR__ . '/config.php';

// Headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');

// Tratar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $conn = getDBConnection();
    
    // Buscar todos os níveis ativos
    $stmt = $conn->prepare("
        SELECT 
            level,
            required_points as requiredPoints,
            reward_value as rewardValue,
            is_active
        FROM " . DB_PREFIX . "level_configs
        WHERE is_active = 1
        ORDER BY level ASC
    ");
    
    $stmt->execute();
    $levels = $stmt->fetchAll();
    
    // Formatar resposta
    $formattedLevels = array_map(function($level) {
        return [
            'level' => (int)$level['level'],
            'requiredPoints' => (int)$level['requiredPoints'],
            'rewardValue' => (float)$level['rewardValue']
        ];
    }, $levels);
    
    jsonResponse(true, 'Níveis carregados com sucesso', [
        'levels' => $formattedLevels
    ]);
    
} catch (PDOException $e) {
    error_log("Erro em get_level_configs.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao buscar níveis: ' . $e->getMessage(), [], 500);
} catch (Exception $e) {
    error_log("Erro em get_level_configs.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao buscar níveis', [], 500);
}

