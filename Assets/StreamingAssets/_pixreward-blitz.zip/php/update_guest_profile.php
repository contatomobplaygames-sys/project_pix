<?php
/**
 * Update Guest Profile API
 * Atualiza o perfil de um guest (nome e email)
 */

require_once __DIR__ . '/config.php';

// Headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');
header('Access-Control-Max-Age: 3600');

// Tratar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Apenas aceitar POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Método não permitido. Use POST.', [], 405);
}

try {
    $conn = getDBConnection();
    
    // Obter dados do corpo da requisição
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validar guest_id
    $guestId = isset($input['guest_id']) ? (int)$input['guest_id'] : 0;
    
    if ($guestId <= 0) {
        jsonResponse(false, 'guest_id inválido', [], 400);
    }
    
    // Validar que pelo menos um campo foi fornecido
    $displayName = isset($input['display_name']) ? sanitizeInput($input['display_name']) : null;
    $name = isset($input['name']) ? sanitizeInput($input['name']) : null;
    $email = isset($input['email']) ? sanitizeInput($input['email']) : null;
    
    // Usar display_name ou name (prioridade para display_name)
    $finalName = $displayName ?? $name;
    
    if ($finalName === null && $email === null) {
        jsonResponse(false, 'Nenhum campo para atualizar fornecido', [], 400);
    }
    
    // Verificar se o guest existe
    $checkStmt = $conn->prepare("
        SELECT guest_id, guest_name, email 
        FROM " . DB_PREFIX . "guest_users 
        WHERE guest_id = ? AND status = 'active'
        LIMIT 1
    ");
    
    $checkStmt->execute([$guestId]);
    $guest = $checkStmt->fetch();
    
    if (!$guest) {
        jsonResponse(false, 'Guest não encontrado ou inativo', [], 404);
    }
    
    // Preparar query de atualização
    $updateFields = [];
    $updateValues = [];
    
    if ($finalName !== null && $finalName !== '') {
        $updateFields[] = "guest_name = ?";
        $updateValues[] = $finalName;
    }
    
    if ($email !== null && $email !== '') {
        // Validar formato de email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(false, 'Email inválido', [], 400);
        }
        $updateFields[] = "email = ?";
        $updateValues[] = $email;
    }
    
    if (empty($updateFields)) {
        jsonResponse(false, 'Nenhum campo válido para atualizar', [], 400);
    }
    
    // Adicionar updated_at
    $updateFields[] = "last_access = NOW()";
    
    // Adicionar guest_id aos valores para o WHERE
    $updateValues[] = $guestId;
    
    // Montar e executar query
    $updateQuery = "
        UPDATE " . DB_PREFIX . "guest_users 
        SET " . implode(', ', $updateFields) . "
        WHERE guest_id = ? AND status = 'active'
    ";
    
    $updateStmt = $conn->prepare($updateQuery);
    $updateStmt->execute($updateValues);
    
    if ($updateStmt->rowCount() === 0) {
        jsonResponse(false, 'Nenhuma alteração realizada', [], 400);
    }
    
    // Buscar dados atualizados
    $fetchStmt = $conn->prepare("
        SELECT 
            g.guest_id,
            g.guest_public_id,
            g.guest_name,
            g.email,
            g.chavepix,
            g.pix_key_type,
            s.points,
            s.lifetime_points,
            s.level
        FROM " . DB_PREFIX . "guest_users g
        LEFT JOIN " . DB_PREFIX . "guest_scores s ON g.guest_id = s.guest_id
        WHERE g.guest_id = ? AND g.status = 'active'
        LIMIT 1
    ");
    
    $fetchStmt->execute([$guestId]);
    $updatedGuest = $fetchStmt->fetch();
    
    if (!$updatedGuest) {
        jsonResponse(false, 'Erro ao buscar dados atualizados', [], 500);
    }
    
    // Retornar sucesso com dados atualizados
    jsonResponse(true, 'Perfil atualizado com sucesso', [
        'user' => [
            'guest_id' => (int)$updatedGuest['guest_id'],
            'guest_public_id' => $updatedGuest['guest_public_id'],
            'display_name' => $updatedGuest['guest_name'],
            'name' => $updatedGuest['guest_name'],
            'email' => $updatedGuest['email'],
            'pix_key' => $updatedGuest['chavepix'],
            'pix_key_type' => $updatedGuest['pix_key_type'],
            'points' => (int)($updatedGuest['points'] ?? 0),
            'lifetime_points' => (int)($updatedGuest['lifetime_points'] ?? 0),
            'level' => (int)($updatedGuest['level'] ?? 1)
        ]
    ]);
    
} catch (PDOException $e) {
    error_log("Erro em update_guest_profile.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao atualizar perfil: ' . $e->getMessage(), [], 500);
} catch (Exception $e) {
    error_log("Erro em update_guest_profile.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao atualizar perfil', [], 500);
}

