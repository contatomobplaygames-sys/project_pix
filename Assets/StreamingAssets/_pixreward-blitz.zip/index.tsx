import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { initializeGuest, isGuest, getCurrentGuestId } from './services/guestService';
// Importar deviceFingerprint para garantir que está disponível globalmente
import './services/deviceFingerprint';

type WindowWithGuestData = Window &
  typeof globalThis & {
    setGuestData?: (data: { guest_id?: number; device_id?: string }) => void;
  };

// Componente wrapper para inicialização
const AppWrapper: React.FC = () => {
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    // Registrar função global para Unity injetar identidade
    const w = window as WindowWithGuestData;
    w.setGuestData = (data) => {
      if (data.guest_id) {
        localStorage.setItem('guest_id', data.guest_id.toString());
        localStorage.setItem('is_guest', 'true');
      }
      if (data.device_id) {
        localStorage.setItem('device_id', data.device_id);
      }
      console.log('[App] 🆔 setGuestData recebido do Unity', data);
      setIsInitializing(false);
    };

    // Inicializar guest automaticamente e carregar pontos
    const init = async () => {
      try {
        // Verificar se já está autenticado
        const guestId = getCurrentGuestId();
        const authenticated = isGuest() && guestId !== null;

        if (authenticated) {
          console.log('[App] ✅ Guest já autenticado:', guestId);
          // Carregar pontos do backend mesmo se já estiver autenticado
          await loadPointsFromBackend(guestId);
          setIsInitializing(false);
          return;
        }

        // Tentar inicializar guest (criar ou recuperar)
        console.log('[App] 🔄 Inicializando guest...');
        const result = await initializeGuest();

        if (result.status === 'success' && result.guest_id) {
          console.log('[App] ✅ Guest inicializado com sucesso:', result.guest_id);
          // Carregar pontos do backend após inicializar guest
          await loadPointsFromBackend(result.guest_id);
        } else {
          console.log('[App] ⚠️ Não foi possível inicializar guest automaticamente');
          console.log('[App] ℹ️ Usuário será redirecionado para página de login');
        }
      } catch (error) {
        console.error('[App] ❌ Erro ao inicializar guest:', error);
      } finally {
        setIsInitializing(false);
      }
    };

    // Função para carregar pontos do backend
    const loadPointsFromBackend = async (guestId: number) => {
      try {
        console.log('[App] 🔄 Carregando pontos do backend para guest_id:', guestId);
        const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
        const url = `${API_BASE_URL}get_user_profile.php?guest_id=${guestId}`;
        
        console.log('[App] 📡 URL da requisição:', url);
        
        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'Accept': 'application/json'
          }
        });
        
        console.log('[App] 📥 Status da resposta:', response.status, response.statusText);
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error('[App] ❌ Resposta de erro:', errorText);
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
          const text = await response.text();
          console.error('[App] ❌ Resposta não é JSON:', text.substring(0, 200));
          throw new Error('Resposta do servidor não é JSON válida');
        }
        
        const data = await response.json();
        console.log('[App] 📦 Dados recebidos do backend:', JSON.stringify(data, null, 2));
        
        // A API retorna: { success: true, message: "...", data: { user: {...} } }
        const userData = data.data?.user || data.user;
        
        if (data.success && userData) {
          const points = parseInt(userData.points) || 0;
          const level = parseInt(userData.level) || 1;
          const lifetimePoints = parseInt(userData.lifetime_points) || 0;
          
          console.log('[App] 📊 Pontos extraídos:', {
            points: points,
            level: level,
            lifetimePoints: lifetimePoints,
            rawData: userData
          });
          
          // Salvar pontos no localStorage para o GameContext usar
          localStorage.setItem('pix_points', points.toString());
          localStorage.setItem('pix_profile', JSON.stringify({
            name: userData.display_name || userData.name || '',
            email: userData.email || '',
            pixKey: userData.pix_key || '',
            level: level,
            lifetimePoints: lifetimePoints
          }));
          
          console.log('[App] 💾 Dados salvos no localStorage:', {
            points: points,
            level: level,
            lifetimePoints: lifetimePoints
          });
          
          console.log('[App] ✅ Pontos carregados e salvos no localStorage:', {
            points: points,
            level: level,
            lifetimePoints: lifetimePoints
          });
        } else {
          console.warn('[App] ⚠️ Resposta não contém dados válidos:', data);
        }
      } catch (error) {
        console.error('[App] ❌ Erro ao carregar pontos do backend:', error);
        
        // Log detalhado
        if (error instanceof Error) {
          console.error('[App] Erro detalhado:', {
            message: error.message,
            stack: error.stack,
            guestId: guestId
          });
        }
        // Continuar mesmo se falhar - GameContext tentará novamente
      }
    };

    // Executar inicialização
    init();
  }, []);

  // Mostrar loading enquanto inicializa
  if (isInitializing) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Carregando...</p>
        </div>
      </div>
    );
  }

  return <App />;
};

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <AppWrapper />
  </React.StrictMode>
);