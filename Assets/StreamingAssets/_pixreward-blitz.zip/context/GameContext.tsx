import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Transaction, UserProfile, WithdrawalRequest, LevelConfig, Mission } from '../types';
import { sendToUnity } from '../services/unityBridge';

interface GameContextType {
  points: number;
  transactions: Transaction[];
  userProfile: UserProfile;
  currentLevelConfig: LevelConfig;
  nextLevelConfig: LevelConfig | null;
  missions: Mission[];
  levelConfigs: LevelConfig[]; // Expor níveis carregados do backend
  updateUserProfile: (profile: UserProfile) => Promise<void>;
  addPoints: (amount: number, reason: string) => void;
  processWithdrawal: (overrideProfile?: UserProfile) => Promise<WithdrawalRequest | null>;
  executeMissionClick: (missionId: string) => { success: boolean; message?: string };
  refreshProfile: () => Promise<boolean>; // Função para atualizar perfil do backend
  refreshLevelConfigs: () => Promise<void>; // Função para recarregar níveis do backend
  refreshMissions: () => Promise<boolean>; // Função para recarregar missões do backend
  refreshWithdrawals: () => Promise<boolean>; // Função para recarregar saques do backend
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const WITHDRAWAL_LEVELS: LevelConfig[] = [
  { level: 1, requiredPoints: 150, rewardValue: 1.00 },
  { level: 2, requiredPoints: 290, rewardValue: 2.00 },
  { level: 3, requiredPoints: 380, rewardValue: 2.50 },
  { level: 4, requiredPoints: 500, rewardValue: 5.00 }
];

const DEFAULT_MISSIONS: Mission[] = [
  {
    id: 'mission_1',
    title: 'Missão Iniciante',
    requiredClicks: 10,
    currentClicks: 0,
    reward: 23,
    cooldownSeconds: 60,
    lastClickTimestamp: null,
    isLocked: false // Começa desbloqueada
  },
  {
    id: 'mission_2',
    title: 'Missão Rápida',
    requiredClicks: 5,
    currentClicks: 0,
    reward: 8,
    cooldownSeconds: 60,
    lastClickTimestamp: null,
    isLocked: true // Bloqueada inicialmente
  },
  {
    id: 'mission_3',
    title: 'Missão Elite',
    requiredClicks: 30,
    currentClicks: 0,
    reward: 28, // Atualizado para 28 pontos conforme solicitado
    cooldownSeconds: 60,
    lastClickTimestamp: null,
    isLocked: true // Bloqueada inicialmente
  }
];

export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [points, setPoints] = useState<number>(() => {
    const saved = localStorage.getItem('pix_points');
    const initialPoints = saved ? parseInt(saved, 10) : 0;
    console.log('[GameContext] 🎯 Pontos iniciais do localStorage:', initialPoints);
    // Os pontos serão atualizados do backend quando loadGuestProfile() executar
    return initialPoints; 
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('pix_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('pix_profile');
    const parsed = saved ? JSON.parse(saved) : {};
    return {
      name: parsed.name || '',
      email: parsed.email || '',
      pixKey: parsed.pixKey || '',
      level: parsed.level || 1,
      lifetimePoints: parsed.lifetimePoints || 0,
      guestPublicId: parsed.guestPublicId || localStorage.getItem('guest_public_id') || ''
    };
  });

  // Estado para níveis carregados do backend
  const [levelConfigs, setLevelConfigs] = useState<LevelConfig[]>(WITHDRAWAL_LEVELS);

  const [missions, setMissions] = useState<Mission[]>(() => {
    // Inicializar com valores padrão, serão carregados do banco depois
    return DEFAULT_MISSIONS;
  });

  const getLevelConfig = (lvl: number): LevelConfig => {
    // Tentar encontrar no array de níveis do backend
    const backendLevel = levelConfigs.find(l => l.level === lvl);
    if (backendLevel) {
      return backendLevel;
    }
    // Fallback para valores fixos se não encontrar
    const index = (lvl - 1) % WITHDRAWAL_LEVELS.length;
    return WITHDRAWAL_LEVELS[index];
  };

  const currentLevelConfig = getLevelConfig(userProfile.level);
  const nextLevelConfig = getLevelConfig(userProfile.level + 1);

  useEffect(() => {
    localStorage.setItem('pix_points', points.toString());
    console.log('[GameContext] 💾 Pontos salvos no localStorage:', points);
  }, [points]);

  useEffect(() => {
    localStorage.setItem('pix_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('pix_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  // Função para carregar missões do backend
  const loadGuestMissions = async () => {
    const guestId = localStorage.getItem('guest_id');
    const isGuest = localStorage.getItem('is_guest') === 'true';
    
    if (!isGuest || !guestId) {
      console.log('[GameContext] ℹ️ Não é guest ou guest_id não encontrado, usando missões padrão');
      return false;
    }
    
    try {
      console.log('[GameContext] 🔄 Carregando missões do backend para guest_id:', guestId);
      const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
      const url = `${API_BASE_URL}get_guest_missions.php?guest_id=${guestId}`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        },
        cache: 'no-cache'
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      console.log('[GameContext] 📥 Resposta de missões do backend:', JSON.stringify(data, null, 2));
      
      // A API retorna: { success: true, data: { missions: [...] } }
      const backendMissions = data.data?.missions || data.missions || [];
      
      if (data.success && backendMissions.length > 0) {
        // Converter para formato Mission
        const formattedMissions: Mission[] = backendMissions.map((m: any) => ({
          id: m.id,
          title: m.title,
          requiredClicks: m.requiredClicks || m.required_clicks,
          currentClicks: m.currentClicks || m.current_clicks || 0,
          reward: m.reward,
          cooldownSeconds: m.cooldownSeconds || m.cooldown_seconds || 60,
          lastClickTimestamp: m.lastClickTimestamp || m.last_click_timestamp || null,
          isLocked: m.isLocked !== undefined ? m.isLocked : (m.is_locked !== undefined ? m.is_locked : true)
        }));
        
        // Garantir ordem correta (mission_1, mission_2, mission_3)
        formattedMissions.sort((a, b) => {
          const aNum = parseInt(a.id.replace('mission_', ''));
          const bNum = parseInt(b.id.replace('mission_', ''));
          return aNum - bNum;
        });
        
        setMissions(formattedMissions);
        console.log('[GameContext] ✅ Missões carregadas do backend:', formattedMissions);
        
        // Salvar no localStorage como backup
        localStorage.setItem('pix_missions', JSON.stringify(formattedMissions));
        
        return true;
      } else {
        console.warn('[GameContext] ⚠️ Nenhuma missão encontrada no backend, usando valores padrão');
        return false;
      }
    } catch (error) {
      console.error('[GameContext] ❌ Erro ao carregar missões do backend:', error);
      
      // Tentar usar localStorage como fallback
      const saved = localStorage.getItem('pix_missions');
      if (saved) {
        try {
          const parsedMissions = JSON.parse(saved);
          setMissions(parsedMissions);
          console.log('[GameContext] 🔄 Usando missões do localStorage como fallback');
        } catch (e) {
          console.error('[GameContext] ❌ Erro ao parsear missões do localStorage:', e);
        }
      }
      
      return false;
    }
  };

  // Salvar missões no localStorage quando mudarem (backup)
  useEffect(() => {
    localStorage.setItem('pix_missions', JSON.stringify(missions));
  }, [missions]);

  // Função para carregar níveis do backend (reutilizável)
  const loadLevelConfigs = async () => {
    try {
      const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
      const response = await fetch(`${API_BASE_URL}get_level_configs.php`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        cache: 'no-cache'
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      console.log('[GameContext] 📥 Resposta completa da API de níveis:', JSON.stringify(data, null, 2));
      
      // A API retorna: { success: true, message: "...", data: { levels: [...] } }
      const levels = data.data?.levels || data.levels || [];
      
      if (data.success && levels && levels.length > 0) {
        // Converter para formato LevelConfig
        const backendLevels: LevelConfig[] = levels.map((l: any) => ({
          level: parseInt(l.level) || l.level,
          requiredPoints: parseInt(l.requiredPoints) || l.requiredPoints,
          rewardValue: parseFloat(l.rewardValue) || l.rewardValue
        }));
        
        // Ordenar por nível para garantir ordem correta
        backendLevels.sort((a, b) => a.level - b.level);
        
        setLevelConfigs(backendLevels);
        console.log('[GameContext] ✅ Níveis carregados do backend:', backendLevels);
      } else {
        console.warn('[GameContext] ⚠️ Nenhum nível encontrado no backend, usando valores padrão');
        console.warn('[GameContext] Estrutura recebida:', {
          success: data.success,
          hasData: !!data.data,
          hasLevels: !!(data.data && data.data.levels),
          hasLevelsDirect: !!data.levels,
          message: data.message
        });
      }
    } catch (error) {
      console.error('[GameContext] ❌ Erro ao carregar níveis do backend:', error);
      if (error instanceof Error) {
        console.error('[GameContext] Detalhes do erro:', error.message);
      }
      console.log('[GameContext] Usando valores padrão dos níveis');
    }
  };

  // Carregar níveis do backend ao inicializar
  useEffect(() => {
    loadLevelConfigs();
  }, []); // Executa apenas uma vez ao montar

  // Carregar saques do backend ao inicializar
  useEffect(() => {
    loadWithdrawals();
  }, []); // Executa apenas uma vez ao montar

  // Função para enviar dados do perfil para Unity
  const sendProfileToUnity = (profileData: {
    guest_id: string;
    guest_public_id: string;
    display_name: string;
    email: string;
    points: number;
    level: number;
    lifetime_points: number;
  }) => {
    try {
      const params: Record<string, string> = {
        guest_id: profileData.guest_id,
        guest_public_id: profileData.guest_public_id,
        is_guest: 'true',
        display_name: profileData.display_name || '',
        email: profileData.email || '',
        points: profileData.points.toString(),
        level: profileData.level.toString(),
        lifetime_points: profileData.lifetime_points.toString()
      };
      
      // Enviar via setUserData para atualizar dados do guest
      const success = sendToUnity('setUserData', params);
      
      if (success) {
        console.log('[GameContext] ✅ Dados do perfil enviados para Unity:', {
          name: profileData.display_name,
          email: profileData.email,
          points: profileData.points
        });
      } else {
        console.log('[GameContext] ⚠️ Unity não disponível - dados não enviados');
      }
    } catch (error) {
      console.error('[GameContext] ❌ Erro ao enviar perfil para Unity:', error);
    }
  };

  // Função para carregar saques do backend
  const loadWithdrawals = async () => {
    const guestId = localStorage.getItem('guest_id');
    const isGuest = localStorage.getItem('is_guest') === 'true';
    
    if (!isGuest || !guestId) {
      console.log('[GameContext] ℹ️ Não é guest ou guest_id não encontrado, não é possível carregar saques');
      return false;
    }
    
    try {
      console.log('[GameContext] 🔄 Carregando saques do backend para guest_id:', guestId);
      const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
      const url = `${API_BASE_URL}get_withdrawals.php?guest_id=${guestId}`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        },
        cache: 'no-cache'
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      console.log('[GameContext] 📥 Resposta de saques do backend:', JSON.stringify(data, null, 2));
      
      if (data.success && data.data?.withdrawals) {
        const withdrawals = data.data.withdrawals;
        
        // Converter saques do backend para formato Transaction
        const transactions: Transaction[] = withdrawals.map((w: any) => ({
          id: w.id,
          type: 'WITHDRAW' as const,
          amount: w.amount,
          date: w.date,
          details: w.details,
          status: w.status,
          raw_status: w.raw_status,
          amount_currency: w.amount_currency,
          pix_key: w.pix_key,
          pix_key_type: w.pix_key_type,
          beneficiary_name: w.beneficiary_name,
          processed_at: w.processed_at,
          rejection_reason: w.rejection_reason
        }));
        
        // Atualizar transações, mantendo apenas saques do backend (substituir saques antigos)
        setTransactions(prev => {
          // Manter apenas transações que não são saques (EARN)
          const nonWithdrawals = prev.filter(tx => tx.type !== 'WITHDRAW');
          // Adicionar saques do backend
          return [...transactions, ...nonWithdrawals];
        });
        
        console.log('[GameContext] ✅ Saques carregados do backend:', transactions.length);
        return true;
      } else {
        console.warn('[GameContext] ⚠️ Nenhum saque encontrado no backend');
        return false;
      }
    } catch (error) {
      console.error('[GameContext] ❌ Erro ao carregar saques do backend:', error);
      return false;
    }
  };

  // Função para carregar perfil do guest do backend
  const loadGuestProfile = async () => {
    const guestId = localStorage.getItem('guest_id');
    const isGuest = localStorage.getItem('is_guest') === 'true';
    
    if (!isGuest || !guestId) {
      console.log('[GameContext] ℹ️ Não é guest ou guest_id não encontrado');
      return false;
    }
    
    try {
      console.log('[GameContext] 🔄 Carregando perfil do backend para guest_id:', guestId);
      const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
      const url = `${API_BASE_URL}get_user_profile.php?guest_id=${guestId}`;
      console.log('[GameContext] 📡 URL da requisição:', url);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        },
        cache: 'no-cache' // Forçar buscar dados atualizados
      });
      
      console.log('[GameContext] 📥 Status da resposta:', response.status, response.statusText);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('[GameContext] ❌ Resposta de erro HTTP:', response.status, errorText.substring(0, 200));
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text();
        console.error('[GameContext] ❌ Resposta não é JSON:', text.substring(0, 500));
        throw new Error('Resposta do servidor não é JSON válida');
      }
      
      const data = await response.json();
      
      // Debug: Log da resposta completa
      console.log('[GameContext] 📥 Resposta completa do backend:', JSON.stringify(data, null, 2));
      
      // A API retorna: { success: true, message: "...", data: { user: {...} } }
      const userData = data.data?.user || data.user;
      
      if (data.success && userData) {
        const backendPoints = parseInt(userData.points) || 0;
        const backendLevel = parseInt(userData.level) || 1;
        const backendLifetimePoints = parseInt(userData.lifetime_points) || 0;
        
        console.log('[GameContext] 📊 Dados extraídos do backend:', {
          points: backendPoints,
          level: backendLevel,
          lifetimePoints: backendLifetimePoints,
          rawPoints: userData.points,
          rawLevel: userData.level,
          rawLifetimePoints: userData.lifetime_points
        });
        
        // Verificar se os pontos mudaram antes de atualizar
        const currentPoints = points;
        const pointsChanged = currentPoints !== backendPoints;
        
        if (pointsChanged || backendPoints > 0) {
          // Atualizar pontos IMEDIATAMENTE do backend
          setPoints(backendPoints);
          console.log('[GameContext] ✅ Pontos atualizados no estado:', currentPoints, '->', backendPoints);
        } else {
          console.log('[GameContext] ℹ️ Pontos não mudaram, mantendo:', backendPoints);
        }
        
        // Atualizar perfil completo
        setUserProfile(prev => {
          const updated = {
            ...prev,
            name: userData.display_name || userData.name || prev.name,
            email: userData.email || prev.email,
            pixKey: userData.pix_key || prev.pixKey,
            level: backendLevel,
            lifetimePoints: backendLifetimePoints,
            guestPublicId: userData.guest_public_id || prev.guestPublicId
          };
          console.log('[GameContext] 📝 Perfil atualizado:', {
            level: `${prev.level} -> ${backendLevel}`,
            lifetimePoints: `${prev.lifetimePoints} -> ${backendLifetimePoints}`
          });
          return updated;
        });
        
        // Atualizar localStorage para sincronização
        localStorage.setItem('pix_points', backendPoints.toString());
        localStorage.setItem('pix_profile', JSON.stringify({
          name: userData.display_name || userData.name || '',
          email: userData.email || '',
          pixKey: userData.pix_key || '',
          level: backendLevel,
          lifetimePoints: backendLifetimePoints,
          guestPublicId: userData.guest_public_id || ''
        }));
        
        if (userData.guest_public_id) {
          localStorage.setItem('guest_public_id', userData.guest_public_id);
        }
        
        console.log('[GameContext] ✅ Perfil do guest carregado do backend com sucesso:', {
          points: backendPoints,
          level: backendLevel,
          lifetimePoints: backendLifetimePoints,
          name: userData.display_name || userData.name,
          publicId: userData.guest_public_id
        });
        
        // IMPORTANTE: Enviar dados do perfil para Unity quando carregado
        sendProfileToUnity({
          guest_id: guestId,
          guest_public_id: userData.guest_public_id || '',
          display_name: userData.display_name || userData.name || '',
          email: userData.email || '',
          points: backendPoints,
          level: backendLevel,
          lifetime_points: backendLifetimePoints
        });
        
        return true;
      } else {
        console.warn('[GameContext] ⚠️ Resposta do backend não contém dados válidos');
        console.warn('[GameContext] Estrutura recebida:', {
          success: data.success,
          hasData: !!data.data,
          hasUser: !!data.user,
          hasDataUser: !!(data.data && data.data.user),
          message: data.message,
          fullResponse: JSON.stringify(data, null, 2)
        });
        
        // Tentar usar dados do localStorage como fallback
        const localPoints = localStorage.getItem('pix_points');
        if (localPoints) {
          const parsedPoints = parseInt(localPoints, 10);
          if (parsedPoints > 0) {
            console.log('[GameContext] 🔄 Usando pontos do localStorage como fallback:', parsedPoints);
            setPoints(parsedPoints);
          }
        }
        
        return false;
      }
    } catch (error) {
      console.error('[GameContext] ❌ Erro ao carregar perfil do guest:', error);
      
      // Log detalhado do erro para debug
      if (error instanceof Error) {
        console.error('[GameContext] Erro detalhado:', {
          message: error.message,
          stack: error.stack,
          guestId: guestId,
          isGuest: isGuest
        });
      }
      
      // Tentar usar dados do localStorage como fallback em caso de erro
      const localPoints = localStorage.getItem('pix_points');
      if (localPoints) {
        const parsedPoints = parseInt(localPoints, 10);
        console.log('[GameContext] 🔄 Usando pontos do localStorage após erro:', parsedPoints);
        setPoints(parsedPoints);
      }
      
      return false;
    }
  };

  // Carregar perfil do guest do backend ao inicializar
  // IMPORTANTE: Executa imediatamente quando o contexto é criado
  useEffect(() => {
    let retryCount = 0;
    const MAX_RETRIES = 5;
    const RETRY_DELAY = 1000; // 1 segundo
    
    const loadProfileOnMount = async () => {
      console.log('[GameContext] 🔄 Iniciando carregamento de perfil... (tentativa', retryCount + 1, ')');
      
      // Verificar se temos guest_id antes de tentar carregar
      const guestId = localStorage.getItem('guest_id');
      const isGuest = localStorage.getItem('is_guest') === 'true';
      
      console.log('[GameContext] 📋 Estado atual:', {
        guestId: guestId,
        isGuest: isGuest,
        hasGuestId: !!guestId,
        retryCount: retryCount
      });
      
      if (!isGuest || !guestId) {
        retryCount++;
        if (retryCount < MAX_RETRIES) {
          console.log('[GameContext] ℹ️ Guest ainda não inicializado, aguardando... (tentativa', retryCount, '/', MAX_RETRIES, ')');
          setTimeout(loadProfileOnMount, RETRY_DELAY);
        } else {
          console.warn('[GameContext] ⚠️ Guest não inicializado após', MAX_RETRIES, 'tentativas');
        }
        return;
      }
      
      // Pequeno delay para garantir que o guest foi inicializado no index.tsx
      await new Promise(resolve => setTimeout(resolve, 500));
      
      console.log('[GameContext] 🔄 Executando loadGuestProfile para guest_id:', guestId);
      const success = await loadGuestProfile();
      
      if (success) {
        console.log('[GameContext] ✅ Perfil e pontos carregados do backend com sucesso');
        
        // Carregar missões após carregar perfil
        await loadGuestMissions();
      } else {
        retryCount++;
        if (retryCount < MAX_RETRIES) {
          console.warn('[GameContext] ⚠️ Não foi possível carregar perfil, tentando novamente... (tentativa', retryCount, '/', MAX_RETRIES, ')');
          setTimeout(loadProfileOnMount, RETRY_DELAY);
        } else {
          console.error('[GameContext] ❌ Falha ao carregar perfil após', MAX_RETRIES, 'tentativas');
        }
      }
    };
    
    // Aguardar um pouco antes de começar para dar tempo do index.tsx inicializar
    const initialDelay = setTimeout(() => {
      loadProfileOnMount();
    }, 800);
    
    return () => {
      clearTimeout(initialDelay);
    };
  }, []); // Executa apenas uma vez ao montar

  // Listener para quando guest_id é definido (pelo Unity ou index.tsx)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'guest_id' && e.newValue) {
        const guestId = e.newValue;
        const isGuest = localStorage.getItem('is_guest') === 'true';
        
        if (isGuest && guestId) {
          console.log('[GameContext] 🔔 guest_id detectado no localStorage, carregando perfil...');
          // Aguardar um pouco para garantir que todos os dados foram salvos
          setTimeout(() => {
            loadGuestProfile().then((success) => {
              if (success) {
                console.log('[GameContext] ✅ Perfil carregado após detecção de guest_id');
                // Carregar missões também
                loadGuestMissions();
              } else {
                console.warn('[GameContext] ⚠️ Falha ao carregar perfil após detecção de guest_id');
              }
            });
          }, 500);
        }
      }
    };
    
    // Escutar mudanças no localStorage (de outras abas/janelas)
    window.addEventListener('storage', handleStorageChange);
    
    // Também verificar periodicamente se guest_id foi definido (para mesma janela)
    const checkInterval = setInterval(() => {
      const guestId = localStorage.getItem('guest_id');
      const isGuest = localStorage.getItem('is_guest') === 'true';
      const currentPoints = localStorage.getItem('pix_points');
      
      // Se temos guest_id mas pontos ainda são 0 ou não foram carregados
      if (isGuest && guestId && (!currentPoints || currentPoints === '0')) {
        console.log('[GameContext] 🔍 Verificando se precisa carregar pontos...');
        loadGuestProfile().then((success) => {
          if (success) {
            console.log('[GameContext] ✅ Pontos carregados na verificação periódica');
            // Recarregar missões também
            loadGuestMissions();
            clearInterval(checkInterval); // Parar verificação se carregou com sucesso
          }
        });
      } else if (isGuest && guestId && currentPoints && currentPoints !== '0') {
        // Se já temos pontos, parar verificação
        clearInterval(checkInterval);
      }
    }, 2000); // Verificar a cada 2 segundos
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(checkInterval);
    };
  }, []); // Executa apenas uma vez ao montar

  // Escutar quando Unity envia pontos e recarregar perfil
  useEffect(() => {
    // Função global que Unity chama quando pontos são enviados
    const handlePointsSent = (points: number, newTotal: number) => {
      console.log('[GameContext] ✅ Unity confirmou envio de pontos:', points, 'Novo total:', newTotal);
      
      // Atualizar pontos IMEDIATAMENTE com o valor do servidor
      if (newTotal > 0) {
        setPoints(newTotal);
        console.log('[GameContext] ✅ Pontos atualizados imediatamente:', newTotal);
      }
      
      // Recarregar perfil do backend para sincronizar todos os dados
      loadGuestProfile().then((success) => {
        if (success) {
          console.log('[GameContext] ✅ Perfil recarregado após envio de pontos');
          // Recarregar missões também para garantir sincronização
          loadGuestMissions();
        }
      });
    };
    
    // Função global que Unity chama quando pontos são carregados do servidor
    const handlePointsLoaded = (points: number) => {
      console.log('[GameContext] ✅ Unity carregou pontos do servidor:', points);
      
      // Atualizar pontos imediatamente
      if (points > 0) {
        setPoints(points);
        console.log('[GameContext] ✅ Pontos atualizados do servidor:', points);
      }
      
      // Recarregar perfil completo
      loadGuestProfile().then((success) => {
        if (success) {
          // Recarregar missões também para garantir sincronização
          loadGuestMissions();
        }
      });
    };

    // Registrar funções globais para Unity chamar
    if (typeof window !== 'undefined') {
      // @ts-ignore
      window.onPointsSentSuccessfully = handlePointsSent;
      // @ts-ignore
      window.onPointsLoadedFromServer = handlePointsLoaded;
      console.log('[GameContext] ✅ Listeners de pontos do Unity registrados');
    }

    // Cleanup
    return () => {
      if (typeof window !== 'undefined') {
        // @ts-ignore
        delete window.onPointsSentSuccessfully;
        // @ts-ignore
        delete window.onPointsLoadedFromServer;
      }
    };
  }, []); // Executa apenas uma vez ao montar

  const updateUserProfile = async (profile: UserProfile) => {
    // Atualizar estado local primeiro para feedback imediato
    setUserProfile(profile);
    
    // Se for guest, salvar no backend
    const guestId = localStorage.getItem('guest_id');
    const isGuest = localStorage.getItem('is_guest') === 'true';
    
    if (isGuest && guestId) {
      try {
        const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
        const response = await fetch(`${API_BASE_URL}update_guest_profile.php`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            guest_id: parseInt(guestId, 10),
            display_name: profile.name,
            email: profile.email || ''
          })
        });
        
        const data = await response.json();
        
        if (data.success && data.data?.user) {
          // Atualizar com dados do servidor para garantir sincronização
          const userData = data.data.user;
          setUserProfile(prev => ({
            ...prev,
            name: userData.display_name || userData.name || prev.name,
            email: userData.email || prev.email,
            guestPublicId: userData.guest_public_id || prev.guestPublicId
          }));
          
          // Atualizar localStorage
          localStorage.setItem('pix_profile', JSON.stringify({
            name: userData.display_name || userData.name || '',
            email: userData.email || '',
            pixKey: profile.pixKey || '',
            level: userData.level || profile.level,
            lifetimePoints: userData.lifetime_points || profile.lifetimePoints,
            guestPublicId: userData.guest_public_id || profile.guestPublicId
          }));
          
          // Salvar nome no PlayerPrefs do Unity (via localStorage para sincronização)
          if (userData.display_name || userData.name) {
            localStorage.setItem('guest_name', userData.display_name || userData.name);
          }
          
          // Obter pontos atuais do estado
          const currentPoints = points;
          
          // Enviar dados atualizados para Unity
          sendProfileToUnity({
            guest_id: guestId,
            guest_public_id: userData.guest_public_id || profile.guestPublicId || '',
            display_name: userData.display_name || userData.name || '',
            email: userData.email || '',
            points: userData.points || currentPoints || 0,
            level: userData.level || profile.level || 1,
            lifetime_points: userData.lifetime_points || profile.lifetimePoints || 0
          });
          
          console.log('[GameContext] ✅ Perfil atualizado no backend:', {
            name: userData.display_name || userData.name,
            email: userData.email
          });
        } else {
          console.error('[GameContext] ❌ Erro ao atualizar perfil no backend:', data.message);
        }
      } catch (error) {
        console.error('[GameContext] ❌ Erro ao atualizar perfil no backend:', error);
        // Manter o estado local mesmo se o backend falhar
      }
    }
  };

  // REMOVIDO: React não deve gerar pontos localmente
  // Todos os pontos devem ser enviados via Unity
  const addPoints = (amount: number, reason: string) => {
    console.warn('[GameContext] ⚠️ addPoints() foi chamado, mas React não deve gerar pontos. Use sendPointsToUnity() para enviar via Unity.');
    // Não fazer nada - pontos devem vir do Unity/backend
  };

  // Função para enviar pontos via Unity
  const sendPointsToUnity = (points: number, type: string = 'mission', source: string = 'react') => {
    if (typeof window === 'undefined') {
      console.warn('[GameContext] ⚠️ window não disponível');
      return;
    }

    try {
      // Enviar comando para Unity processar pontos
      const url = `uniwebview://submitPoints?points=${points}&type=${type}&source=${source}`;
      console.log('[GameContext] 📤 Enviando pontos para Unity:', url);
      window.location.href = url;
    } catch (error) {
      console.error('[GameContext] ❌ Erro ao enviar pontos para Unity:', error);
    }
  };

  // Função para salvar progresso da missão no backend
  const saveMissionProgress = async (mission: Mission, isCompleted: boolean = false) => {
    const guestId = localStorage.getItem('guest_id');
    const isGuest = localStorage.getItem('is_guest') === 'true';
    
    if (!isGuest || !guestId) {
      return; // Não é guest, não salvar
    }
    
    try {
      const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
      const response = await fetch(`${API_BASE_URL}update_mission_progress.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          guest_id: parseInt(guestId, 10),
          mission_id: mission.id,
          current_clicks: mission.currentClicks,
          last_click_timestamp: mission.lastClickTimestamp,
          is_locked: mission.isLocked ? 1 : 0,
          is_completed: isCompleted
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.data?.mission) {
          const updatedMission = data.data.mission;
          console.log('[GameContext] ✅ Progresso da missão salvo no backend:', mission.id);
          
          // Atualizar estado com dados do backend para garantir sincronização
          setMissions(prevMissions => {
            return prevMissions.map(m => {
              if (m.id === updatedMission.id) {
                return {
                  ...m,
                  currentClicks: updatedMission.currentClicks,
                  lastClickTimestamp: updatedMission.lastClickTimestamp,
                  isLocked: updatedMission.isLocked,
                  // Manter outros campos que não vêm do backend
                  title: updatedMission.title || m.title,
                  requiredClicks: updatedMission.requiredClicks || m.requiredClicks,
                  reward: updatedMission.reward || m.reward,
                  cooldownSeconds: updatedMission.cooldownSeconds || m.cooldownSeconds
                };
              }
              return m;
            });
          });
          
          // Se a missão foi completada, recarregar todas as missões para garantir sincronização
          // (especialmente importante para desbloquear a próxima missão)
          if (isCompleted) {
            console.log('[GameContext] 🔄 Missão completada, recarregando todas as missões...');
            setTimeout(() => {
              loadGuestMissions();
            }, 300);
          }
        }
      }
    } catch (error) {
      console.error('[GameContext] ❌ Erro ao salvar progresso da missão:', error);
      // Não bloquear o fluxo se o backend falhar
    }
  };

  const executeMissionClick = (missionId: string): { success: boolean; message?: string } => {
    let result = { success: false, message: '' };
    let updatedMission: Mission | null = null;
    let isCompleted = false;

    setMissions(prevMissions => {
      const currentMissionIndex = prevMissions.findIndex(m => m.id === missionId);
      if (currentMissionIndex === -1) return prevMissions;

      const mission = prevMissions[currentMissionIndex];

      if (mission.isLocked) {
        result = { success: false, message: 'Missão bloqueada' };
        return prevMissions;
      }

      const now = Date.now();
      
      if (mission.lastClickTimestamp) {
        const elapsed = (now - mission.lastClickTimestamp) / 1000;
        if (elapsed < mission.cooldownSeconds) {
          result = { success: false, message: `Aguarde ${Math.ceil(mission.cooldownSeconds - elapsed)}s` };
          return prevMissions;
        }
      }

      const newClickCount = mission.currentClicks + 1;

      if (newClickCount >= mission.requiredClicks) {
        // Missão completada
        result = { success: true, message: `Missão Completa! +${mission.reward} pts` };
        isCompleted = true;
        
        const nextMissionIndex = (currentMissionIndex + 1) % prevMissions.length;

        const updated = prevMissions.map((m, index) => {
          if (index === currentMissionIndex) {
            const completedMission = {
              ...m,
              currentClicks: 0,
              lastClickTimestamp: null,
              isLocked: true 
            };
            updatedMission = completedMission;
            return completedMission;
          }
          if (index === nextMissionIndex) {
            const unlockedMission = {
              ...m,
              isLocked: false
            };
            // Salvar próxima missão desbloqueada também
            setTimeout(() => saveMissionProgress(unlockedMission, false), 100);
            return unlockedMission;
          }
          return m;
        });
        
        // Salvar missão completada no backend
        if (updatedMission) {
          setTimeout(() => saveMissionProgress(updatedMission!, true), 100);
        }
        
        return updated;
      }

      // Missão ainda em progresso
      result = { success: true, message: 'Clique registrado!' };
      
      const updated = prevMissions.map(m => {
        if (m.id === missionId) {
          const inProgressMission = {
            ...m,
            currentClicks: newClickCount,
            lastClickTimestamp: now
          };
          updatedMission = inProgressMission;
          return inProgressMission;
        }
        return m;
      });
      
      // Salvar progresso no backend
      if (updatedMission) {
        setTimeout(() => saveMissionProgress(updatedMission!, false), 100);
      }
      
      return updated;
    });

    return result;
  };

  const processWithdrawal = async (overrideProfile?: UserProfile): Promise<WithdrawalRequest | null> => {
    // Usa o perfil passado como argumento se existir, caso contrário usa o estado
    const profileToUse = overrideProfile || userProfile;

    if (points < currentLevelConfig.requiredPoints) return null;
    if (!profileToUse.pixKey || !profileToUse.name) return null;

    const withdrawAmount = points;
    const currencyValue = currentLevelConfig.rewardValue;
    
    // Verificar se é guest
    const guestId = localStorage.getItem('guest_id');
    const isGuest = localStorage.getItem('is_guest') === 'true';
    
    // Enviar saque para o backend
    try {
      const API_BASE_URL = 'https://serveapp.mobplaygames.com.br/app_pix01/php/';
      const pixKeyType = profileToUse.pixKey.includes('@') ? 'EMAIL' : 
                        /^\d{11}$/.test(profileToUse.pixKey.replace(/\D/g, '')) ? 'CPF' :
                        /^\d{10,11}$/.test(profileToUse.pixKey.replace(/\D/g, '')) ? 'PHONE' : 'RANDOM';
      
      const response = await fetch(`${API_BASE_URL}create_withdrawal.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          guest_id: isGuest && guestId ? parseInt(guestId, 10) : undefined,
          user_id: !isGuest ? parseInt(localStorage.getItem('user_id') || '0', 10) : undefined,
          pix_key: profileToUse.pixKey,
          pix_key_type: pixKeyType,
          beneficiary_name: profileToUse.name
        }),
      });
      
      const data = await response.json();
      
      if (data.status !== 'success') {
        throw new Error(data.message || 'Erro ao criar saque');
      }
      
      console.log('[GameContext] ✅ Saque criado no backend:', data);
      
      // Atualizar pontos E NÍVEL do backend após sucesso
      if (isGuest && guestId) {
        const profileResponse = await fetch(`${API_BASE_URL}get_user_profile.php?guest_id=${guestId}`);
        const profileData = await profileResponse.json();
        if (profileData.success && profileData.user) {
          setPoints(profileData.user.points || 0);
          // IMPORTANTE: Atualizar nível do backend (que foi incrementado)
          setUserProfile(prev => ({
            ...prev,
            level: profileData.user.level || prev.level,
            ...(overrideProfile || {})
          }));
          console.log('[GameContext] ✅ Nível atualizado do backend:', profileData.user.level);
        }
      } else if (data.new_level) {
        // Se backend retornou novo nível diretamente, usar ele
        setUserProfile(prev => ({
          ...prev,
          level: data.new_level,
          ...(overrideProfile || {})
        }));
        console.log('[GameContext] ✅ Nível atualizado da resposta:', data.new_level);
      }
      
    } catch (error) {
      console.error('[GameContext] ❌ Erro ao criar saque no backend:', error);
      // Continuar com o fluxo local mesmo se o backend falhar
    }
    
    const requestData: WithdrawalRequest = {
      requestId: crypto.randomUUID(),
      user: profileToUse,
      amountPoints: withdrawAmount,
      amountCurrency: `R$ ${currencyValue.toFixed(2).replace('.', ',')}`,
      timestamp: new Date().toISOString()
    };

    // NÃO zerar pontos aqui - o backend já subtraiu
    // NÃO incrementar nível aqui - o backend já incrementou
    // Apenas atualizar se o backend não retornou os dados atualizados
    if (!isGuest || !guestId) {
      // Se não é guest ou não conseguiu atualizar do backend, fazer localmente
      setPoints(0);
      setUserProfile(prev => ({
        ...prev,
        ...(overrideProfile || {}),
        level: prev.level + 1
      }));
    }

    // Não criar transação local aqui - será carregada do backend
    // Recarregar saques do backend para obter o status correto
    await loadWithdrawals();

    return requestData;
  };

  return (
    <GameContext.Provider value={{ 
      points, 
      transactions, 
      userProfile, 
      currentLevelConfig,
      nextLevelConfig,
      missions,
      levelConfigs, // Expor níveis carregados do backend
      updateUserProfile, 
      addPoints, 
      processWithdrawal,
      executeMissionClick,
      refreshProfile: loadGuestProfile, // Expor função para atualizar perfil
      refreshLevelConfigs: loadLevelConfigs, // Expor função para recarregar níveis
      refreshMissions: loadGuestMissions, // Expor função para recarregar missões
      refreshWithdrawals: loadWithdrawals // Expor função para recarregar saques
    }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) throw new Error("useGame must be used within a GameProvider");
  return context;
};