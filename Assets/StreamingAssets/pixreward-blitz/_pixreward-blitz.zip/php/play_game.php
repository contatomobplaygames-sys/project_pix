<?php
/**
 * play_game.php — PixReward Blitz · Reprodutor de Jogos HTML5 v2
 *
 * Página PHP/JS standalone para reprodução segura de jogos HTML5.
 * Independente do React — resolve limitações de iframe dentro de SPA.
 *
 * Arquitetura de iframe único com proxy inteligente integrado.
 * Usa state-machine em JS para controle de lifecycle do carregamento.
 *
 * Estratégias de carregamento:
 *   auto   — detecta automaticamente com base nas listas de domínio (padrão)
 *   direct — carrega URL do jogo direto no iframe (para jogos embed-friendly)
 *   proxy  — carrega via game_proxy.php (para jogos com frame-busting)
 *
 * Parâmetros GET:
 *   url   (obrigatório) — URL original do jogo
 *   mode  (opcional)    — auto | direct | proxy  (padrão: auto)
 *   title (opcional)    — Nome do jogo para exibição
 *
 * Protocolo postMessage (envia para window.parent):
 *   { type: 'pixreward:game_ready',  url }  — jogo carregou com sucesso
 *   { type: 'pixreward:game_error',  url }  — falha ao carregar
 *   { type: 'pixreward:game_closed', url }  — confirmação de fechamento
 *
 * Escuta de window.parent:
 *   { type: 'pixreward:close_game' }        — pedido para fechar o jogo
 */

declare(strict_types=1);

// ═══════════════════════════════════════════════════════════════════════════
// Configuração de Domínios
// ═══════════════════════════════════════════════════════════════════════════

/** Domínios que suportam embed direto — sem necessidade de proxy */
$directDomains = [
    'play.famobi.com',
    'html5.gamedistribution.com',
    'www.crazygames.com',
    'itch.io',
    'itch.zone',
    'html-classic.itch.zone',
];

/** Domínios com frame-busting ativo — requerem proxy */
$proxyDomains = [
    'cdn-factory.marketjs.com',
    'cdn.wanted5games.com',
    'storage.y8.com',
    'games.cdn.famobi.com',
];

// ═══════════════════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════════════════

function halt(string $msg): never
{
    http_response_code(400);
    header('Content-Type: text/html; charset=utf-8');
    $safe = htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');
    echo <<<HTML
<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:100%;height:100%;background:#0f172a;color:#f87171;font-family:system-ui,-apple-system,sans-serif;
display:flex;align-items:center;justify-content:center;text-align:center;padding:24px}
.card{max-width:320px}
h2{font-size:16px;font-weight:700;margin-bottom:8px}
p{font-size:13px;line-height:1.5;color:#94a3b8;margin-bottom:20px}
.btn{display:inline-block;padding:12px 28px;background:#3b82f6;color:#fff;border:none;
border-radius:12px;font:600 13px/1 system-ui,sans-serif;cursor:pointer;transition:all .15s}
.btn:active{transform:scale(.95);opacity:.8}
</style></head>
<body><div class="card">
<h2>{$safe}</h2>
<p>Não foi possível iniciar o jogo. Verifique sua conexão e tente novamente.</p>
<button class="btn" onclick="location.reload()">Tentar novamente</button>
</div></body></html>
HTML;
    exit;
}

function domainMatch(string $host, array $list): bool
{
    $host = strtolower($host);
    foreach ($list as $d) {
        if ($host === strtolower($d) || str_ends_with($host, '.' . strtolower($d))) {
            return true;
        }
    }
    return false;
}

// ═══════════════════════════════════════════════════════════════════════════
// Validação de Entrada
// ═══════════════════════════════════════════════════════════════════════════

$gameUrl   = trim((string) ($_GET['url']   ?? ''));
$mode      = strtolower(trim((string) ($_GET['mode']  ?? 'auto')));
$gameTitle = trim((string) ($_GET['title'] ?? 'Jogo'));

if ($gameUrl === '' || !filter_var($gameUrl, FILTER_VALIDATE_URL)) {
    halt('URL do jogo inválida ou ausente');
}

$parts  = parse_url($gameUrl);
$host   = strtolower((string) ($parts['host']   ?? ''));
$scheme = strtolower((string) ($parts['scheme'] ?? 'https'));

if (!in_array($scheme, ['http', 'https'], true)) {
    halt('Apenas URLs http/https são permitidas');
}

// ═══════════════════════════════════════════════════════════════════════════
// Estratégia de Carregamento
// ═══════════════════════════════════════════════════════════════════════════

$useProxy = match ($mode) {
    'proxy'  => true,
    'direct' => false,
    default  => domainMatch($host, $proxyDomains),
};

$embedUrl = $useProxy
    ? 'game_proxy.php?url=' . urlencode($gameUrl) . '&v=7'
    : $gameUrl;

// ═══════════════════════════════════════════════════════════════════════════
// Headers HTTP
// ═══════════════════════════════════════════════════════════════════════════

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header_remove('X-Frame-Options');

// ═══════════════════════════════════════════════════════════════════════════
// Variáveis PHP → JS (seguras via json_encode)
// ═══════════════════════════════════════════════════════════════════════════

$jsEmbedUrl = json_encode($embedUrl, JSON_UNESCAPED_SLASHES);
$jsRawUrl   = json_encode($gameUrl,  JSON_UNESCAPED_SLASHES);
$jsTitle    = json_encode($gameTitle, JSON_UNESCAPED_SLASHES);
$jsProxied  = $useProxy ? 'true' : 'false';
$safeTitle  = htmlspecialchars($gameTitle, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>PixReward — <?= $safeTitle ?></title>
<style>
/* ── Reset ──────────────────────────────────────────────────────────── */
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}

/* ── Viewport ───────────────────────────────────────────────────────── */
/* IMPORTANTE: Usar position:relative + absolute (NÃO fixed!)
   Em WebViews Android/iOS, position:fixed dentro de iframes pode
   referenciar o viewport do dispositivo inteiro em vez do iframe,
   fazendo o jogo "vazar" para fora da área designada. */
html{
  width:100%;height:100%;overflow:hidden;
  position:relative;
}
body{
  position:relative;
  width:100%;height:100%;overflow:hidden;
  background:#000;color:#fff;
  font-family:system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  touch-action:none;
  -webkit-user-select:none;user-select:none;
  overscroll-behavior:none;
  -webkit-tap-highlight-color:transparent;
}

/* ── Iframe do Jogo ─────────────────────────────────────────────────── */
#game{
  position:absolute;top:0;left:0;
  width:100%;height:100%;
  border:none;display:block;
  background:#000;
  touch-action:auto;
  z-index:1;
}

/* ── Overlay ────────────────────────────────────────────────────────── */
#overlay{
  position:absolute;top:0;left:0;
  width:100%;height:100%;
  display:flex;flex-direction:column;
  align-items:center;justify-content:center;
  background:#0f172a;
  z-index:10;
  transition:opacity .5s ease;
}
#overlay.fade-out{opacity:0;pointer-events:none}
#overlay.removed{display:none}

/* ── Spinner ────────────────────────────────────────────────────────── */
.spinner{
  position:relative;
  width:52px;height:52px;
  margin-bottom:24px;
}
.spinner-ring{
  position:absolute;inset:0;
  border:3px solid transparent;
  border-radius:50%;
}
.spinner-ring:nth-child(1){
  border-top-color:#3b82f6;
  animation:spin .9s linear infinite;
}
.spinner-ring:nth-child(2){
  inset:6px;
  border-bottom-color:#8b5cf6;
  animation:spin 1.4s linear infinite reverse;
}
.spinner-dot{
  position:absolute;
  top:50%;left:50%;
  width:8px;height:8px;
  margin:-4px 0 0 -4px;
  background:#3b82f6;
  border-radius:50%;
  animation:pulse 1.2s ease-in-out infinite;
}

/* ── Textos ─────────────────────────────────────────────────────────── */
.title{font-size:15px;font-weight:700;color:#e2e8f0;margin-bottom:6px;transition:all .3s}
.subtitle{font-size:11px;color:#64748b;transition:all .3s}

/* ── Progress Steps ─────────────────────────────────────────────────── */
.steps{display:flex;align-items:center;gap:4px;margin-top:20px}
.step{
  width:32px;height:3px;
  border-radius:2px;
  background:rgba(255,255,255,.08);
  transition:background .4s,box-shadow .4s;
}
.step.active{background:#3b82f6;box-shadow:0 0 8px rgba(59,130,246,.4)}
.step.done{background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.3)}

/* ── Error State ────────────────────────────────────────────────────── */
.error-icon{
  width:52px;height:52px;
  border-radius:50%;
  background:rgba(239,68,68,.15);
  display:flex;align-items:center;justify-content:center;
  margin-bottom:16px;
}
.error-icon svg{width:24px;height:24px;color:#ef4444}
.error-title{font-size:15px;font-weight:700;color:#f87171;margin-bottom:8px}
.error-msg{font-size:12px;color:#94a3b8;line-height:1.5;max-width:260px;text-align:center;margin-bottom:20px}
.retry-btn{
  padding:12px 32px;
  background:#3b82f6;color:#fff;border:none;
  border-radius:12px;font:600 13px/1 system-ui,sans-serif;
  cursor:pointer;transition:all .15s;
}
.retry-btn:active{transform:scale(.95);opacity:.8}

/* ── Animations ─────────────────────────────────────────────────────── */
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes pulse{0%,100%{opacity:.4;transform:scale(.8)}50%{opacity:1;transform:scale(1.2)}}
</style>
</head>
<body>

<!-- ══ Overlay de Carregamento ═══════════════════════════════════════════ -->
<div id="overlay">
  <div class="spinner" id="spinner">
    <div class="spinner-ring"></div>
    <div class="spinner-ring"></div>
    <div class="spinner-dot"></div>
  </div>
  <div class="title" id="title">Preparando jogo…</div>
  <div class="subtitle" id="subtitle"><?= $safeTitle ?></div>
  <div class="steps" id="steps">
    <div class="step" id="s0"></div>
    <div class="step" id="s1"></div>
    <div class="step" id="s2"></div>
    <div class="step" id="s3"></div>
  </div>
</div>

<!-- ══ Iframe do Jogo ════════════════════════════════════════════════════ -->
<iframe
  id="game"
  src="about:blank"
  allow="autoplay; gyroscope; accelerometer; pointer-lock; gamepad; clipboard-write; web-share; screen-wake-lock"
  referrerpolicy="no-referrer-when-downgrade"
></iframe>

<!-- ══ JavaScript — Engine do Game Player ════════════════════════════════ -->
<script>
(function(){
  'use strict';

  // ── Config (injetado pelo PHP) ────────────────────────────────────────
  var CFG = {
    embedUrl:  <?= $jsEmbedUrl ?>,
    rawUrl:    <?= $jsRawUrl ?>,
    title:     <?= $jsTitle ?>,
    proxied:   <?= $jsProxied ?>,
    timeout:   18000,
    loadDelay: 700
  };

  // ══════════════════════════════════════════════════════════════════════
  // CAMADA 1: Bloqueio Total da Fullscreen API
  // ══════════════════════════════════════════════════════════════════════
  (function blockFullscreen(){
    var reject = function(){
      return Promise.reject(new DOMException('Fullscreen is disabled','NotAllowedError'));
    };
    var targets = [
      [Element.prototype, 'requestFullscreen'],
      [Element.prototype, 'webkitRequestFullscreen'],
      [Element.prototype, 'webkitRequestFullScreen'],
      [Element.prototype, 'mozRequestFullScreen'],
      [Element.prototype, 'msRequestFullscreen'],
      [HTMLElement.prototype, 'webkitRequestFullScreen']
    ];
    for (var i = 0; i < targets.length; i++){
      try { if (targets[i][0][targets[i][1]]) targets[i][0][targets[i][1]] = reject; } catch(e){}
    }
    var props = [
      [document, 'fullscreenEnabled'],
      [document, 'webkitFullscreenEnabled'],
      [document, 'mozFullScreenEnabled'],
      [document, 'msFullscreenEnabled']
    ];
    for (var j = 0; j < props.length; j++){
      try { Object.defineProperty(props[j][0], props[j][1], {value:false,writable:false,configurable:true}); } catch(e){}
    }
  })();

  // ══════════════════════════════════════════════════════════════════════
  // CAMADA 2: Interceptar Screen Orientation Lock (alguns jogos usam)
  // ══════════════════════════════════════════════════════════════════════
  try {
    if (screen.orientation && screen.orientation.lock) {
      screen.orientation.lock = function(){ return Promise.resolve(); };
    }
  } catch(e){}

  // ══════════════════════════════════════════════════════════════════════
  // DOM References
  // ══════════════════════════════════════════════════════════════════════
  var frame    = document.getElementById('game');
  var overlay  = document.getElementById('overlay');
  var elTitle  = document.getElementById('title');
  var elSub    = document.getElementById('subtitle');
  var elSpin   = document.getElementById('spinner');
  var steps    = [
    document.getElementById('s0'),
    document.getElementById('s1'),
    document.getElementById('s2'),
    document.getElementById('s3')
  ];

  // ══════════════════════════════════════════════════════════════════════
  // State Machine
  // ══════════════════════════════════════════════════════════════════════
  var STATE = {
    INIT:         0,
    CONNECTING:   1,
    DOWNLOADING:  2,
    INITIALIZING: 3,
    READY:        4,
    ERROR:        5
  };

  var current = STATE.INIT;

  function setStep(n){
    for (var i = 0; i < steps.length; i++){
      steps[i].className = i < n ? 'step done' : (i === n ? 'step active' : 'step');
    }
  }

  function transition(state, opts){
    if (current === STATE.READY || current === STATE.ERROR) return;
    current = state;
    opts = opts || {};

    switch(state){
      case STATE.CONNECTING:
        setStep(0);
        elTitle.textContent = 'Conectando…';
        elSub.textContent   = CFG.title;
        break;

      case STATE.DOWNLOADING:
        setStep(1);
        elTitle.textContent = 'Carregando jogo…';
        elSub.textContent   = 'Baixando recursos';
        break;

      case STATE.INITIALIZING:
        setStep(2);
        elTitle.textContent = 'Quase lá…';
        elSub.textContent   = 'Inicializando engine';
        break;

      case STATE.READY:
        setStep(3);
        hideOverlay();
        notify('pixreward:game_ready');
        break;

      case STATE.ERROR:
        showError(opts.message || 'Não foi possível carregar o jogo.');
        notify('pixreward:game_error', {error: opts.message || 'load_failed'});
        break;
    }
  }

  // ══════════════════════════════════════════════════════════════════════
  // Overlay Control
  // ══════════════════════════════════════════════════════════════════════
  function hideOverlay(){
    overlay.classList.add('fade-out');
    setTimeout(function(){ overlay.classList.add('removed'); }, 600);
  }

  function showError(msg){
    elSpin.style.display = 'none';
    document.getElementById('steps').style.display = 'none';

    var errorHtml =
      '<div class="error-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' +
      '<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>' +
      '</svg></div>' +
      '<div class="error-title">Falha no carregamento</div>' +
      '<div class="error-msg">' + msg + '</div>' +
      '<button class="retry-btn" onclick="location.reload()">Tentar novamente</button>';

    elTitle.style.display = 'none';
    elSub.style.display   = 'none';

    var container = document.createElement('div');
    container.style.cssText = 'display:flex;flex-direction:column;align-items:center';
    container.innerHTML = errorHtml;
    overlay.appendChild(container);
  }

  // ══════════════════════════════════════════════════════════════════════
  // postMessage — Comunicação com React (parent)
  // ══════════════════════════════════════════════════════════════════════
  function notify(type, extra){
    if (window.parent === window) return;
    var msg = {type: type, url: CFG.rawUrl, title: CFG.title, proxied: CFG.proxied};
    if (extra) for (var k in extra) msg[k] = extra[k];
    try { window.parent.postMessage(msg, '*'); } catch(e){}
  }

  window.addEventListener('message', function(ev){
    try {
      var d = (typeof ev.data === 'string') ? JSON.parse(ev.data) : ev.data;
      if (d && d.type === 'pixreward:close_game'){
        notify('pixreward:game_closed');
      }
    } catch(e){}
  });

  // ══════════════════════════════════════════════════════════════════════
  // Iframe Lifecycle
  // ══════════════════════════════════════════════════════════════════════
  var loadFired = false;

  frame.addEventListener('load', function(){
    if (loadFired) return;
    loadFired = true;

    transition(STATE.INITIALIZING);

    setTimeout(function(){
      transition(STATE.READY);
    }, CFG.loadDelay);
  });

  frame.addEventListener('error', function(){
    transition(STATE.ERROR, {message: 'O servidor do jogo não respondeu. Verifique sua conexão.'});
  });

  // Timeout de segurança — se iframe não carrega em N segundos, forçar exibição
  setTimeout(function(){
    if (current !== STATE.READY && current !== STATE.ERROR){
      console.warn('[GamePlayer] Timeout de ' + (CFG.timeout/1000) + 's — forçando exibição');
      transition(STATE.READY);
    }
  }, CFG.timeout);

  // ══════════════════════════════════════════════════════════════════════
  // Iniciar Carregamento
  // ══════════════════════════════════════════════════════════════════════
  transition(STATE.CONNECTING);

  setTimeout(function(){
    transition(STATE.DOWNLOADING);
    frame.src = CFG.embedUrl;
  }, 150);

})();
</script>
</body>
</html>
