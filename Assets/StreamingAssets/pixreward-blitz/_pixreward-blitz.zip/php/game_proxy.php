<?php
/**
 * Game Proxy v6 — PixReward Blitz
 *
 * Busca HTML de jogos remotos (whitelist), injeta proteo anti-frame-busting
 * em 3 camadas (eval intercept + location override + error handler),
 * e serve o contedo limpo a partir do nosso domnio.
 *
 * Uso:
 *   game_proxy.php?url=https://cdn-factory.marketjs.com/en/escape-from-aztec-responsive/index.html
 */

declare(strict_types=1);

// =====================================================================
// Configurao
// =====================================================================

$allowedDomains = [
    'cdn-factory.marketjs.com',
    'games.cdn.famobi.com',
    'play.famobi.com',
    'html5.gamedistribution.com',
    'cdn.wanted5games.com',
    'storage.y8.com',
];

$cacheTtlSeconds = 900;
$cacheDir        = __DIR__ . '/game_cache';
$cacheVersion    = 'v7';

// =====================================================================
// Helpers
// =====================================================================

function fail(int $code, string $msg): void
{
    http_response_code($code);
    header('Content-Type: text/plain; charset=utf-8');
    echo $msg;
    exit;
}

function isDomainAllowed(string $host, array $list): bool
{
    $host = strtolower($host);
    foreach ($list as $d) {
        $d = strtolower($d);
        if ($host === $d || str_ends_with($host, '.' . $d)) {
            return true;
        }
    }
    return false;
}

// =====================================================================
// Validao de entrada
// =====================================================================

$gameUrl = trim((string) ($_GET['url'] ?? ''));
if ($gameUrl === '')                           fail(400, 'Parmetro "url"  obrigatrio.');
if (!filter_var($gameUrl, FILTER_VALIDATE_URL)) fail(400, 'URL invlida.');

$parts = parse_url($gameUrl);
if (!$parts || empty($parts['scheme']) || empty($parts['host'])) fail(400, 'URL malformada.');

$scheme = strtolower((string) $parts['scheme']);
if (!in_array($scheme, ['http', 'https'], true)) fail(400, 'Apenas http/https permitidos.');

$host = (string) $parts['host'];
if (!isDomainAllowed($host, $allowedDomains)) fail(403, 'Domnio no permitido: ' . $host);

// =====================================================================
// Cache
// =====================================================================

$useCache = !isset($_GET['nocache']);
$cacheKey  = md5($cacheVersion . '|' . $gameUrl);
$cacheFile = $cacheDir . '/' . $cacheKey . '.html';

if ($useCache && is_file($cacheFile) && (time() - (int) filemtime($cacheFile) < $cacheTtlSeconds)) {
    header('Content-Type: text/html; charset=utf-8');
    header('X-Game-Proxy: cached');
    header('Cache-Control: no-store');
    readfile($cacheFile);
    exit;
}

// =====================================================================
// Fetch remoto
// =====================================================================

$ctx = stream_context_create([
    'http' => [
        'method'          => 'GET',
        'timeout'         => 20,
        'follow_location' => true,
        'max_redirects'   => 5,
        'header'          => implode("\r\n", [
            'User-Agent: Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: pt-BR,pt;q=0.9,en;q=0.8',
        ]),
    ],
    'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
]);

$html = @file_get_contents($gameUrl, false, $ctx);
if ($html === false || trim($html) === '') {
    fail(502, 'Falha ao carregar jogo remoto.');
}

// =====================================================================
// Construir URL base para recursos relativos
// =====================================================================

$origin  = $scheme . '://' . $host . (isset($parts['port']) ? ':' . $parts['port'] : '');
$dirPath = rtrim(str_replace('\\', '/', dirname((string) ($parts['path'] ?? '/'))), '/');
$baseHref = $origin . ($dirPath !== '' ? $dirPath . '/' : '/');

// =====================================================================
// Injetar <base href> + script anti-frame-busting (3 camadas)
// =====================================================================

if (stripos($html, '<head') === false) {
    $html = '<html><head></head><body>' . $html . '</body></html>';
}

$safeOriginJs = json_encode($origin, JSON_UNESCAPED_SLASHES);

// O script usa 3 estratgias complementares:
//
// CAMADA 1 — eval() intercept
//   O MarketJS (e outros) executam frame-busting dentro de eval().
//   Interceptamos eval() e removemos padres de top.location / parent.location
//   do cdigo ANTES de execut-lo. Substitumos por (void 0) que  sintaticamente
//   vlido e no faz nada.
//
// CAMADA 2 — Override de location.replace/assign no top e parent
//   Se o frame-busting no for via eval (script inline direto), tentamos
//   sobrescrever os mtodos de navegao no top/parent. Funciona quando
//   proxy  same-origin com o app pai.
//
// CAMADA 3 — Global error handler
//   Captura SecurityError residuais para impedir que matem o runtime do jogo.

$script = <<<'JSBLOCK'
<script>
(function(){
  // ---- CAMADA 0: Bloquear Fullscreen API ----
  try {
    var noFs = function() { return Promise.reject(new DOMException('Fullscreen blocked','NotAllowedError')); };
    Element.prototype.requestFullscreen = noFs;
    if (Element.prototype.webkitRequestFullscreen) Element.prototype.webkitRequestFullscreen = noFs;
    if (Element.prototype.webkitRequestFullScreen) Element.prototype.webkitRequestFullScreen = noFs;
    if (Element.prototype.mozRequestFullScreen) Element.prototype.mozRequestFullScreen = noFs;
    if (Element.prototype.msRequestFullscreen) Element.prototype.msRequestFullscreen = noFs;
    if (HTMLElement.prototype.webkitRequestFullScreen) HTMLElement.prototype.webkitRequestFullScreen = noFs;
    try { Object.defineProperty(document, 'fullscreenEnabled', { value: false, writable: false }); } catch(e){}
    try { Object.defineProperty(document, 'webkitFullscreenEnabled', { value: false, writable: false }); } catch(e){}
  } catch(e){}

  // ---- CAMADA 1: Interceptar eval() ----
  var _eval = window.eval;
  try {
    window.eval = function(code) {
      if (typeof code === 'string') {
        // Remover top.location.replace(...), top.location.assign(...), top.location.href = ..., top.location = ...
        code = code.replace(/top\s*\.\s*location\s*\.\s*replace\s*\([^)]*\)/g, '(void 0)');
        code = code.replace(/top\s*\.\s*location\s*\.\s*assign\s*\([^)]*\)/g, '(void 0)');
        code = code.replace(/top\s*\.\s*location\s*\.\s*href\s*=[^;,}\)\]]+/g, '(void 0)');
        code = code.replace(/top\s*\.\s*location\s*=[^;,}\)\]]+/g, '(void 0)');
        // Mesmo para parent.location
        code = code.replace(/parent\s*\.\s*location\s*\.\s*replace\s*\([^)]*\)/g, '(void 0)');
        code = code.replace(/parent\s*\.\s*location\s*\.\s*assign\s*\([^)]*\)/g, '(void 0)');
        code = code.replace(/parent\s*\.\s*location\s*\.\s*href\s*=[^;,}\)\]]+/g, '(void 0)');
        code = code.replace(/parent\s*\.\s*location\s*=[^;,}\)\]]+/g, '(void 0)');
        // window.top.location
        code = code.replace(/window\s*\.\s*top\s*\.\s*location\s*\.\s*replace\s*\([^)]*\)/g, '(void 0)');
        code = code.replace(/window\s*\.\s*top\s*\.\s*location\s*\.\s*assign\s*\([^)]*\)/g, '(void 0)');
      }
      return _eval.call(window, code);
    };
  } catch(e){}

  // Interceptar new Function() tambem (outra forma de codigo dinamico)
  try {
    var _Function = window.Function;
    window.Function = function() {
      var args = Array.prototype.slice.call(arguments);
      var body = args.length > 0 ? args[args.length - 1] : '';
      if (typeof body === 'string' && (body.indexOf('top.location') !== -1 || body.indexOf('parent.location') !== -1)) {
        body = body.replace(/top\s*\.\s*location\s*\.\s*replace\s*\([^)]*\)/g, '(void 0)');
        body = body.replace(/top\s*\.\s*location\s*\.\s*assign\s*\([^)]*\)/g, '(void 0)');
        body = body.replace(/parent\s*\.\s*location\s*\.\s*replace\s*\([^)]*\)/g, '(void 0)');
        body = body.replace(/parent\s*\.\s*location\s*\.\s*assign\s*\([^)]*\)/g, '(void 0)');
        args[args.length - 1] = body;
      }
      return _Function.apply(this, args);
    };
    window.Function.prototype = _Function.prototype;
  } catch(e){}

  // ---- CAMADA 2: Override de location methods no top/parent ----
  function noop() {}
  try {
    if (window.top && window.top !== window.self) {
      try { window.top.location.replace = noop; } catch(e){}
      try { window.top.location.assign  = noop; } catch(e){}
    }
  } catch(e){}
  try {
    if (window.parent && window.parent !== window.self) {
      try { window.parent.location.replace = noop; } catch(e){}
      try { window.parent.location.assign  = noop; } catch(e){}
    }
  } catch(e){}

  // Override tambem no proprio window (caso o jogo use self.location)
  try {
    var _selfReplace = window.location.replace.bind(window.location);
    var _selfAssign  = window.location.assign.bind(window.location);
    var GAME_ORIGIN  = %GAME_ORIGIN%;
    window.location.replace = function(url) {
      try {
        var p = new URL(url, window.location.href);
        if (p.origin === window.location.origin || p.origin === GAME_ORIGIN) return _selfReplace(url);
      } catch(e){}
    };
    window.location.assign = function(url) {
      try {
        var p = new URL(url, window.location.href);
        if (p.origin === window.location.origin || p.origin === GAME_ORIGIN) return _selfAssign(url);
      } catch(e){}
    };
  } catch(e){}

  // ---- CAMADA 3: Error handler global ----
  window.addEventListener('error', function(ev) {
    var m = String(ev && ev.message || '');
    if (m.indexOf('SecurityError') !== -1 ||
        m.indexOf('cross-origin') !== -1 ||
        (m.indexOf('Location') !== -1 && (m.indexOf('permission') !== -1 || m.indexOf('Failed') !== -1)) ||
        (m.indexOf('Blocked') !== -1 && m.indexOf('frame') !== -1)) {
      ev.preventDefault();
      ev.stopImmediatePropagation();
      return true;
    }
  }, true);

  // Unhandled promise rejections relacionadas a navegacao
  window.addEventListener('unhandledrejection', function(ev) {
    var m = String(ev && ev.reason || '');
    if (m.indexOf('SecurityError') !== -1 || m.indexOf('Location') !== -1) {
      ev.preventDefault();
    }
  });
})();
</script>
JSBLOCK;

// Substituir placeholder pela origin real do jogo
$script = str_replace('%GAME_ORIGIN%', $safeOriginJs, $script);

$baseTag    = '<base href="' . htmlspecialchars($baseHref, ENT_QUOTES, 'UTF-8') . '">';
$injections = $baseTag . $script;
$html = preg_replace('/<head([^>]*)>/i', '<head$1>' . $injections, $html, 1) ?? $html;

// =====================================================================
// Persistir cache
// =====================================================================

if (!is_dir($cacheDir)) {
    @mkdir($cacheDir, 0755, true);
}
@file_put_contents($cacheFile, $html);

// =====================================================================
// Resposta
// =====================================================================

header('Content-Type: text/html; charset=utf-8');
header('X-Game-Proxy: live-v7');
header('Cache-Control: no-store');
echo $html;
